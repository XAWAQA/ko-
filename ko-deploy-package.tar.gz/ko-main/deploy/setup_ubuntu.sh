#!/usr/bin/env bash
# ==============================================================================
# ko-main Ubuntu 24.04 LTS Production Deployment Script
# Target: Contabo VPS / Dedicated Ubuntu Server 24.04 LTS
# ==============================================================================

set -euo pipefail

APP_DIR="/opt/ko-bot"
APP_USER="kobot"
APP_GROUP="kobot"
CONFIG_DIR="/etc/ko-bot"
ENV_FILE="${CONFIG_DIR}/ko-bot.env"
SERVICE_FILE="/etc/systemd/system/ko-bot.service"

echo "=========================================================="
echo "🚀 Starting ko-main deployment setup on Ubuntu 24.04 LTS..."
echo "=========================================================="

# 1. Verify root execution
if [ "$EUID" -ne 0 ]; then
    echo "❌ Error: This script must be run as root (use sudo)." >&2
    exit 1
fi

# 2. Update apt repositories and install essential packages
echo "📦 Installing prerequisites (Python 3.12, venv, build tools)..."
apt-get update -y
apt-get install -y --no-install-recommends \
    python3 \
    python3-venv \
    python3-pip \
    python3-dev \
    build-essential \
    curl \
    git \
    rsync \
    ca-certificates

# 3. Create unprivileged system user for security isolation
if ! id -u "${APP_USER}" >/dev/null 2>&1; then
    echo "👤 Creating system service user: ${APP_USER}..."
    useradd --system --shell /usr/sbin/nologin --home-dir "${APP_DIR}" "${APP_USER}"
else
    echo "👤 Service user ${APP_USER} already exists."
fi

# 4. Prepare directories and permissions (data directory managed separately)
echo "📁 Setting up application, data, and config directories..."
DATA_DIR="${APP_DIR}/data"
mkdir -p "${APP_DIR}"
mkdir -p "${DATA_DIR}/ff_checker/runs"
mkdir -p "${CONFIG_DIR}"

# 5. Create Python Virtual Environment (enforces PEP 668 compliance)
echo "🐍 Initializing Python 3.12 virtual environment at ${APP_DIR}/venv..."
if [ ! -d "${APP_DIR}/venv" ]; then
    python3 -m venv "${APP_DIR}/venv"
fi

"${APP_DIR}/venv/bin/pip" install --upgrade pip setuptools wheel

# 6. Copy/Sync application code (Preserving database & runtime data)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ -f "${SCRIPT_DIR}/app.py" ] && [ "${SCRIPT_DIR}" != "${APP_DIR}" ]; then
    echo "📋 Syncing application code to ${APP_DIR} (preserving existing data & DB)..."
    if command -v rsync >/dev/null 2>&1; then
        rsync -av \
            --exclude='data/' \
            --exclude='__pycache__/' \
            --exclude='.pytest_cache/' \
            --exclude='*.pyc' \
            --exclude='.git/' \
            --exclude='venv/' \
            --exclude='.env' \
            "${SCRIPT_DIR}/" "${APP_DIR}/"
    else
        find "${SCRIPT_DIR}" -mindepth 1 -maxdepth 1 \
            ! -name 'data' \
            ! -name '__pycache__' \
            ! -name '.pytest_cache' \
            ! -name 'venv' \
            ! -name '.git' \
            ! -name '.env' \
            -exec cp -r {} "${APP_DIR}/" \;
    fi
fi

# Ensure data directories exist independently with proper permissions
mkdir -p "${DATA_DIR}/ff_checker/runs"

# 7. Install dependencies
echo "📥 Installing Python requirements..."
"${APP_DIR}/venv/bin/pip" install -r "${APP_DIR}/requirements.txt"

# 8. Setup secure configuration file
if [ ! -f "${ENV_FILE}" ]; then
    echo "⚙️ Creating secure environment file at ${ENV_FILE}..."
    cat << 'EOF' > "${ENV_FILE}"
# ko-bot production secrets
# Replace with your actual Telegram bot token from @BotFather
TELEGRAM_BOT_TOKEN="REPLACE_WITH_YOUR_TELEGRAM_BOT_TOKEN"
OWNER_ID=1167798421
MAX_RAM_MB=8192
REQUEST_TIMEOUT=12.0
RETRY_ATTEMPTS=3
PROGRESS_UPDATE_INTERVAL=1.5
EOF
    echo "⚠️ NOTE: Please edit ${ENV_FILE} and set your TELEGRAM_BOT_TOKEN before starting the service!"
fi

# Ensure strictly restricted permissions on secrets (chmod 600)
chown "${APP_USER}:${APP_GROUP}" "${ENV_FILE}"
chmod 600 "${ENV_FILE}"
chmod 700 "${CONFIG_DIR}"

# 9. Set proper ownership on application files and data directories
echo "🔒 Restricting file permissions..."
chown -R "${APP_USER}:${APP_GROUP}" "${APP_DIR}"
chmod -R 750 "${APP_DIR}"
chmod -R 770 "${DATA_DIR}"

# If database already exists, preserve and lock down file permissions
if [ -f "${DATA_DIR}/access_control.db" ]; then
    chmod 660 "${DATA_DIR}/access_control.db"
    echo "💾 Existing database preserved: ${DATA_DIR}/access_control.db"
fi

# 10. Install systemd service unit
echo "⚙️ Configuring systemd service at ${SERVICE_FILE}..."
cp "${APP_DIR}/deploy/ko-bot.service" "${SERVICE_FILE}"
chmod 644 "${SERVICE_FILE}"

systemctl daemon-reload
systemctl enable ko-bot.service

echo "=========================================================="
echo "✅ Deployment setup completed successfully!"
echo "=========================================================="
echo ""
echo "Next Steps to Launch:"
echo "1. Edit secrets file:"
echo "   sudo nano ${ENV_FILE}"
echo "2. Start the service:"
echo "   sudo systemctl start ko-bot"
echo "3. Check service status:"
echo "   sudo systemctl status ko-bot"
echo "4. Monitor live logs:"
echo "   sudo journalctl -u ko-bot -f"
echo "=========================================================="

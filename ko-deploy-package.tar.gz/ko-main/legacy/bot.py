import telebot
from telebot import types
import asyncio
import httpx
import json
import time
import random
import os
import signal
import sys
import threading

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🚀 UVLOOP
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
try:
    import uvloop
    uvloop.install()
    print("✅ uvloop active")
except ImportError:
    print("⚠️ uvloop not found")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ⚙️ Configuration
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
bot = telebot.TeleBot(TOKEN, threaded=False)

CPU_CORES = os.cpu_count() or 4
MAX_RAM_MB = 8192
REQUEST_TIMEOUT = 12.0
RETRY_ATTEMPTS = 3
RETRY_BACKOFF = [0.3, 0.7, 1.5]

# 💾 Database
users_db = {}
user_state = {}
user_data = {}
stop_flags = {}

S_AUTH, S_MENU, S_INPUT_JOIN, S_INPUT_APP_GROUPS, S_INPUT_APP_MEMBERS, S_INPUT_MOD_GROUPS = range(6)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🎨 Visual Toolkit
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def make_premium_progress(current, total, start_time, stats):
    if total == 0:
        return "---"
    percentage = current / total
    bar_len = 20
    filled = int(bar_len * percentage)
    bar = "█" * filled + "░" * (bar_len - filled)
    elapsed = time.time() - start_time
    speed = current / elapsed if elapsed > 0 else 0
    eta = int((total - current) / speed) if speed > 0 else 0

    try:
        import resource
        mem_usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    except:
        mem_usage = 0

    return (
        f"🌐 **SYSTEM STATUS: EXECUTING...**\n"
        f"┌{'─' * 22}┐\n"
        f"  {bar} {int(percentage * 100)}%\n"
        f"└{'─' * 22}┘\n"
        f"📡 **THROUGHPUT:** `{speed:.1f} req/s`\n"
        f"⏳ **ELAPSED:** `{int(elapsed)}s`\n"
        f"⏱ **ETA:** `{eta}s`\n"
        f"💎 **PACKETS:** `{current}/{total}`\n"
        f"✅ `{stats['ok']}` | ❌ `{stats['bad']}` | 🔄 `{stats.get('retried', 0)}`\n"
        f"🖥️ **RAM:** `{mem_usage:.0f} MB` | ⚡ `{CPU_CORES} vCPU`"
    )

def get_main_menu():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row("⚡ CONNECT GROUPS", "🛡️ APPROVE MEMBERS")
    markup.row("👑 MODERATOR APPROVAL", "📟 SYSTEM INFO")
    markup.row("🚫 TERMINATE", "🔌 DISCONNECT")
    return markup

def get_speed_buttons():
    markup = types.InlineKeyboardMarkup(row_width=4)
    speeds = [1, 5, 10, 50, 100, 200, 350, 500]
    btns = [types.InlineKeyboardButton(f"⚡ {s}", callback_data=f"spd:{s}") for s in speeds]
    markup.add(*btns)
    return markup

def get_pages_list(all_pages, selected_ids):
    markup = types.InlineKeyboardMarkup()
    btn_all = "✅ DESELECT ALL" if len(selected_ids) == len(all_pages) and len(all_pages) > 0 else "🔲 SELECT ALL"
    markup.add(types.InlineKeyboardButton(btn_all, callback_data="toggle_all"))
    for p in all_pages:
        icon = "☑️" if p['id'] in selected_ids else "⬜"
        markup.add(types.InlineKeyboardButton(f"{icon} {p['name']}", callback_data=f"pg:{p['id']}"))
    markup.add(types.InlineKeyboardButton(f"CONTINUE ({len(selected_ids)}) ⬅️", callback_data="done_select"))
    return markup

def get_confirm_buttons(speed):
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🟢 CONFIRM & INITIALIZE", callback_data=f"confirm:{speed}"))
    markup.add(types.InlineKeyboardButton("🔴 ABORT MISSION", callback_data="cancel_run"))
    return markup

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🔧 Async Runner (with error handling)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def run_async(coro, chat_id=None):
    def _runner():
        loop = uvloop.new_event_loop() if 'uvloop' in sys.modules else asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(coro)
        except Exception as e:
            print(f"❌ ASYNC ERROR: {e}")
            import traceback
            traceback.print_exc()
            if chat_id:
                try:
                    bot.send_message(chat_id,
                        f"❌ **RUNTIME ERROR:**\n`{str(e)[:500]}`",
                        parse_mode="Markdown", reply_markup=get_main_menu())
                except: pass
        finally:
            try:
                pending = asyncio.all_tasks(loop)
                for task in pending:
                    task.cancel()
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            except: pass
            loop.close()

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    return t

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🕹️ Auth
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@bot.message_handler(commands=['start'])
@bot.message_handler(func=lambda m: m.text == "🔌 DISCONNECT")
def start(message):
    chat_id = message.chat.id
    stop_flags[chat_id] = False
    if chat_id in users_db and message.text != "🔌 DISCONNECT":
        bot.send_message(chat_id,
            f"Welcome back, **{users_db[chat_id]['name']}** 🟢\n"
            f"🖥️ `{CPU_CORES} vCPU | {MAX_RAM_MB}MB RAM`",
            parse_mode="Markdown", reply_markup=get_main_menu())
        user_state[chat_id] = S_MENU
    else:
        users_db.pop(chat_id, None)
        bot.send_message(chat_id, "🔐 **ENTER ACCESS TOKEN:**",
                         parse_mode="Markdown", reply_markup=types.ReplyKeyboardRemove())
        user_state[chat_id] = S_AUTH

@bot.message_handler(func=lambda m: user_state.get(m.chat.id) == S_AUTH)
def login(message):
    chat_id = message.chat.id
    token = message.text.strip()
    wait = bot.send_message(chat_id, "🛰️ **AUTHENTICATING...**")

    async def verify():
        async with httpx.AsyncClient(http2=True) as client:
            try:
                resp = await client.get(
                    f"https://graph.facebook.com/me?access_token={token}",
                    timeout=10.0)
                if resp.status_code == 200:
                    data = resp.json()
                    users_db[chat_id] = {'token': token, 'id': data['id'], 'name': data['name']}
                    bot.delete_message(chat_id, wait.message_id)
                    bot.send_message(chat_id,
                        f"✅ **ACCESS GRANTED**\nNode: `{data['name']}`",
                        parse_mode="Markdown", reply_markup=get_main_menu())
                    user_state[chat_id] = S_MENU
                else:
                    bot.edit_message_text("❌ **INVALID TOKEN**", chat_id, wait.message_id)
            except:
                bot.edit_message_text("⚠️ **CONNECTION ERROR**", chat_id, wait.message_id)

    run_async(verify(), chat_id)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 👑 Moderator Approval Engine (قبل Join!)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@bot.message_handler(func=lambda m: m.text == "👑 MODERATOR APPROVAL")
def mod_start(message):
    chat_id = message.chat.id
    if chat_id not in users_db:
        return bot.reply_to(message, "❌ **LOGIN FIRST!**", parse_mode="Markdown")
    user_data[chat_id] = {'op': 'moderator'}
    bot.send_message(chat_id, "📥 **أرسل Group IDs:**\n(كل ID في سطر)", parse_mode="Markdown")
    user_state[chat_id] = S_INPUT_MOD_GROUPS

@bot.message_handler(content_types=['document', 'text'],
                      func=lambda m: user_state.get(m.chat.id) == S_INPUT_MOD_GROUPS)
def receive_mod_groups(message):
    chat_id = message.chat.id
    if message.text and any(x in message.text for x in ["⚡", "🛡️", "👑", "📟", "🚫", "🔌"]):
        return
    content = (bot.download_file(bot.get_file(message.document.file_id).file_path).decode('utf-8')
                if message.document else message.text)
    groups = [l.strip() for l in content.splitlines() if l.strip()]
    if not groups:
        return bot.reply_to(message, "❌ EMPTY LIST!")
    user_data[chat_id]['mod_groups'] = groups
    bot.send_message(chat_id,
        f"✅ Received `{len(groups)}` Groups\n\n🏎️ **SET SPEED:**",
        parse_mode="Markdown", reply_markup=get_speed_buttons())

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🚀 Join Engine
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@bot.message_handler(func=lambda m: m.text == "⚡ CONNECT GROUPS")
def join_start(message):
    chat_id = message.chat.id
    if chat_id not in users_db:
        return bot.reply_to(message, "❌ **LOGIN FIRST!**", parse_mode="Markdown")
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("👤 MAIN PROFILE", callback_data="src_me"))
    markup.add(types.InlineKeyboardButton("📄 FAN PAGES", callback_data="src_pages"))
    bot.send_message(message.chat.id, "🛠️ **SELECT UPLINK SOURCE:**",
                     parse_mode="Markdown", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("src_"))
def select_source(call):
    chat_id = call.message.chat.id
    bot.delete_message(chat_id, call.message.message_id)
    user_data[chat_id] = {'op': 'join', 'actors': []}

    if call.data == "src_me":
        user_data[chat_id]['actors'] = [{
            'id': users_db[chat_id]['id'],
            'name': users_db[chat_id]['name'],
            'token': users_db[chat_id]['token']
        }]
        bot.send_message(chat_id, "📥 **STEP 1:** Send Target Group IDs:")
        user_state[chat_id] = S_INPUT_JOIN
    elif call.data == "src_pages":
        msg = bot.send_message(chat_id, "📡 **SCANNING DATABASE...**")

        async def fetch():
            token = users_db[chat_id]['token']
            async with httpx.AsyncClient(http2=True) as client:
                try:
                    resp = await client.get(
                        f"https://graph.facebook.com/me/accounts?fields=name,access_token&access_token={token}&limit=500",
                        timeout=15.0)
                    data = resp.json()
                    p_data = data.get('data', [])
                    if not p_data:
                        bot.edit_message_text("❌ **NO PAGES FOUND**", chat_id, msg.message_id)
                        return
                    pages = [{'id': p['id'], 'name': p['name'], 'token': p.get('access_token')} for p in p_data]
                    user_data[chat_id]['all_pages'] = pages
                    user_data[chat_id]['selected_pages'] = []
                    bot.delete_message(chat_id, msg.message_id)
                    bot.send_message(chat_id, "💎 **SELECT TARGET PAGES:**",
                                     reply_markup=get_pages_list(pages, []))
                except:
                    bot.edit_message_text("⚠️ **SCAN FAILED**", chat_id, msg.message_id)

        run_async(fetch(), chat_id)

@bot.callback_query_handler(func=lambda call: call.data.startswith("pg:") or call.data in ["toggle_all", "done_select"])
def pages_check(call):
    chat_id = call.message.chat.id
    if chat_id not in user_data:
        return
    all_p = user_data[chat_id].get('all_pages', [])
    sel = user_data[chat_id].get('selected_pages', [])
    if call.data == "done_select":
        if not sel:
            return bot.answer_callback_query(call.id, "SELECT AT LEAST ONE NODE!")
        user_data[chat_id]['actors'] = [
            {'id': p['id'], 'name': p['name'], 'token': p['token']}
            for p in all_p if p['id'] in sel]
        bot.delete_message(chat_id, call.message.message_id)
        bot.send_message(chat_id, "📥 **STEP 1:** Send Target Group IDs:")
        user_state[chat_id] = S_INPUT_JOIN
    elif call.data == "toggle_all":
        user_data[chat_id]['selected_pages'] = [] if len(sel) == len(all_p) else [p['id'] for p in all_p]
    else:
        pid = call.data.split(":")[1]
        if pid in sel:
            sel.remove(pid)
        else:
            sel.append(pid)
    try:
        bot.edit_message_reply_markup(chat_id, call.message.message_id,
                                      reply_markup=get_pages_list(all_p, user_data[chat_id].get('selected_pages', [])))
    except:
        pass

@bot.message_handler(content_types=['document', 'text'],
                      func=lambda m: user_state.get(m.chat.id) == S_INPUT_JOIN)
def receive_join_groups(message):
    chat_id = message.chat.id
    if message.text and any(x in message.text for x in ["⚡", "🛡️", "👑", "📟", "🚫", "🔌"]):
        return
    content = (bot.download_file(bot.get_file(message.document.file_id).file_path).decode('utf-8')
               if message.document else message.text)
    lines = [l.strip() for l in content.splitlines() if l.strip()]
    if not lines:
        return bot.reply_to(message, "❌ DATA STREAM EMPTY!")
    user_data[chat_id]['targets'] = lines
    bot.send_message(chat_id, "🏎️ **SET OVERCLOCK SPEED:**", reply_markup=get_speed_buttons())

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🛡️ Approve Members
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@bot.message_handler(func=lambda m: m.text == "🛡️ APPROVE MEMBERS")
def approve_start(message):
    chat_id = message.chat.id
    if chat_id not in users_db:
        return bot.reply_to(message, "❌ **LOGIN FIRST!**", parse_mode="Markdown")
    user_data[chat_id] = {'op': 'approve', 'app_groups': [], 'app_members': []}
    bot.send_message(chat_id, "1️⃣ **UPLINK:** أرسل قائمة (Group IDs):")
    user_state[chat_id] = S_INPUT_APP_GROUPS

@bot.message_handler(content_types=['document', 'text'],
                      func=lambda m: user_state.get(m.chat.id) == S_INPUT_APP_GROUPS)
def receive_app_groups(message):
    chat_id = message.chat.id
    if message.text and any(x in message.text for x in ["⚡", "🛡️", "👑", "📟", "🚫", "🔌"]):
        return
    content = (bot.download_file(bot.get_file(message.document.file_id).file_path).decode('utf-8')
               if message.document else message.text)
    groups = [l.strip() for l in content.splitlines() if l.strip()]
    if not groups:
        return bot.reply_to(message, "❌ EMPTY LIST!")
    user_data[chat_id]['app_groups'] = groups
    bot.send_message(chat_id, f"✅ Received {len(groups)} Groups.\n\n2️⃣ **TARGETS:** الآن أرسل قائمة (Member IDs):")
    user_state[chat_id] = S_INPUT_APP_MEMBERS

@bot.message_handler(content_types=['document', 'text'],
                      func=lambda m: user_state.get(m.chat.id) == S_INPUT_APP_MEMBERS)
def receive_app_mems(message):
    chat_id = message.chat.id
    if message.text and any(x in message.text for x in ["⚡", "🛡️", "👑", "📟", "🚫", "🔌"]):
        return
    content = (bot.download_file(bot.get_file(message.document.file_id).file_path).decode('utf-8')
               if message.document else message.text)
    mems = [l.strip() for l in content.splitlines() if l.strip()]
    if not mems:
        return bot.reply_to(message, "❌ EMPTY LIST!")
    user_data[chat_id]['app_members'] = mems
    bot.send_message(chat_id, "🏎️ **SET OVERCLOCK SPEED:**", reply_markup=get_speed_buttons())

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ⚡ NUCLEAR ENGINE v5 - Unified
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@bot.callback_query_handler(func=lambda call: call.data.startswith("spd:"))
def show_summary(call):
    chat_id = call.message.chat.id
    speed = int(call.data.split(":")[1])
    bot.delete_message(chat_id, call.message.message_id)
    data = user_data[chat_id]

    if data['op'] == 'join':
        total_ops = len(data.get('targets', [])) * len(data.get('actors', []))
    elif data['op'] == 'approve':
        total_ops = len(data.get('app_groups', [])) * len(data.get('app_members', []))
    elif data['op'] == 'moderator':
        total_ops = len(data.get('mod_groups', []))
    else:
        total_ops = 0

    summary = (
        f"📑 **MISSION BRIEFING**\n"
        f"⚙️ TYPE: `{data['op'].upper()}`\n"
        f"🔢 TOTAL OPS: `{total_ops}`\n"
        f"🚀 CONCURRENCY: `{speed} simultaneous`\n"
        f"⚡ ENGINE: `{'uvloop' if 'uvloop' in sys.modules else 'asyncio'}`\n\n"
        f"INITIALIZE?"
    )
    bot.send_message(chat_id, summary, parse_mode="Markdown",
                     reply_markup=get_confirm_buttons(speed))

@bot.callback_query_handler(func=lambda call: call.data == "cancel_run")
def cancel_run(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    bot.send_message(call.message.chat.id, "🚫 **MISSION ABORTED.**", reply_markup=get_main_menu())

@bot.callback_query_handler(func=lambda call: call.data.startswith("confirm:"))
def start_run_confirmed(call):
    chat_id = call.message.chat.id
    speed = int(call.data.split(":")[1])
    bot.delete_message(chat_id, call.message.message_id)
    run_async(process_async(chat_id, speed), chat_id)

async def process_async(chat_id, speed):
    try:
        stop_flags[chat_id] = False
        data = user_data.get(chat_id)
        main_token = users_db[chat_id]['token']
        main_id = users_db[chat_id]['id']
        op = data['op']

        actor_names = {a['id']: a.get('name', 'Main Node') for a in data.get('actors', [])}

        # ━━━ بناء القائمة ━━━
        queue = []
        if op == 'join':
            for target in data.get('targets', []):
                for actor in data.get('actors', []):
                    queue.append({'target': target, 'act_id': actor['id'], 'token': actor['token']})
        elif op == 'approve':
            for grp in data.get('app_groups', []):
                for mem in data.get('app_members', []):
                    queue.append({'target': grp, 'mem_id': mem})
        elif op == 'moderator':
            for grp in data.get('mod_groups', []):
                queue.append({'target': grp})

        random.shuffle(queue)
        total = len(queue)

        if total == 0:
            bot.send_message(chat_id, "❌ **NO TASKS TO PROCESS!**",
                             parse_mode="Markdown", reply_markup=get_main_menu())
            user_state[chat_id] = S_MENU
            return

        main_msg = bot.send_message(chat_id,
            f"⚡ **NUCLEAR ENGINE v5 STARTING...**\n"
            f"Nodes: `{total}` | Concurrency: `{speed}`",
            parse_mode="Markdown")

        stats = {'ok': 0, 'bad': 0, 'done': 0, 'retried': 0}
        failed_details = []
        start_time = time.time()

        success_page_ids = set()
        success_mod_groups = []
        success_lock = asyncio.Lock()

        # ━━━ بناء الـ payloads ━━━
        prepared_items = []
        for item in queue:
            if op == 'join':
                payload = {
                    'access_token': item['token'],
                    'variables': json.dumps({"input": {"group_id": str(item['target'])}}),
                    'doc_id': '33243444848636579'
                }
            elif op == 'approve':
                payload = {
                    'access_token': main_token,
                    'variables': json.dumps({
                        "groupID": str(item['target']),
                        "memberID": str(item['mem_id']),
                        "input": {
                            "group_id": str(item['target']),
                            "member": str(item['mem_id']),
                            "actor_id": str(main_id)
                        },
                        "scale": 1
                    }),
                    'doc_id': '26744408605191970'
                }
            elif op == 'moderator':
                payload = {
                    'access_token': main_token,
                    'doc_id': '25320459267654690',
                    'variables': json.dumps({
                        "input": {
                            "client_mutation_id": "2",
                            "actor_id": str(main_id),
                            "admin_type": "MODERATOR",
                            "group_id": str(item['target']),
                            "source": "COMET_GROUP_PAGE"
                        },
                        "inviteShortLinkKey": None,
                        "scale": 1,
                        "__relay_internal__pv__GroupsCometGroupChatLazyLoadLastMessageSnippetrelayprovider": False
                    })
                }
            prepared_items.append({'payload': payload, 'meta': item})

        # ━━━ Updater ━━━
        async def updater_task():
            last_text = ""
            while stats['done'] < total and not stop_flags.get(chat_id):
                await asyncio.sleep(1.5)
                text = make_premium_progress(stats['done'], total, start_time, stats)
                if text != last_text:
                    try:
                        bot.edit_message_text(text, chat_id, main_msg.message_id, parse_mode="Markdown")
                        last_text = text
                    except:
                        pass

        updater = asyncio.create_task(updater_task())

        # ━━━ Worker ━━━
        sem = asyncio.Semaphore(speed)

        async def fire(client, prepared):
            async with sem:
                if stop_flags.get(chat_id):
                    stats['done'] += 1
                    return

                payload = prepared['payload']
                meta = prepared['meta']
                res = False

                for attempt in range(RETRY_ATTEMPTS):
                    try:
                        response = await client.post(
                            "https://graph.facebook.com/graphql",
                            data=payload,
                            timeout=REQUEST_TIMEOUT
                        )
                        rt = response.text

                        if op == 'join':
                            if 'MEMBER' in rt or 'already a member' in rt.lower() or '1341004' in rt:
                                res = True
                                break
                        elif op == 'approve':
                            if 'errors' not in rt or 'already a member' in rt.lower() or '1341004' in rt:
                                res = True
                                break
                        elif op == 'moderator':
                            if 'errors' not in rt:
                                res = True
                                break

                        if response.status_code == 429 or 'rate limit' in rt.lower():
                            stats['retried'] += 1
                            await asyncio.sleep(RETRY_BACKOFF[attempt] * (1 + random.random()))
                            continue

                        if response.status_code in [400, 403]:
                            break

                    except (httpx.TimeoutException, httpx.ConnectError,
                            httpx.ReadError, httpx.WriteError, httpx.PoolTimeout):
                        stats['retried'] += 1
                        if attempt < RETRY_ATTEMPTS - 1:
                            await asyncio.sleep(RETRY_BACKOFF[attempt])
                        continue
                    except Exception:
                        break

                stats['done'] += 1
                if res:
                    stats['ok'] += 1
                    async with success_lock:
                        if op == 'join':
                            success_page_ids.add(meta['act_id'])
                        elif op == 'moderator':
                            success_mod_groups.append(meta['target'])
                else:
                    stats['bad'] += 1
                    if op == 'join':
                        failed_details.append(f"❌ `{actor_names.get(meta['act_id'], '?')}` → `{meta['target']}`")
                    elif op == 'approve':
                        failed_details.append(f"❌ `{meta['target']}` → `{meta['mem_id']}`")
                    elif op == 'moderator':
                        failed_details.append(f"❌ Group: `{meta['target']}`")

        # ━━━ Multi-Client ━━━
        num_clients = min(CPU_CORES, max(1, len(prepared_items)))
        chunk_size = max(1, len(prepared_items) // num_clients)
        chunks = [prepared_items[i:i + chunk_size] for i in range(0, len(prepared_items), chunk_size)]

        async def run_chunk(chunk_items):
            limits = httpx.Limits(
                max_keepalive_connections=max(speed, 1),
                max_connections=max(speed * 2, 2)
            )
            transport = httpx.AsyncHTTPTransport(retries=1, http2=True)
            async with httpx.AsyncClient(
                limits=limits, transport=transport,
                http2=True, follow_redirects=True
            ) as client:
                tasks = [asyncio.create_task(fire(client, item)) for item in chunk_items]
                await asyncio.gather(*tasks, return_exceptions=True)

        chunk_tasks = [asyncio.create_task(run_chunk(chunk)) for chunk in chunks if chunk]
        await asyncio.gather(*chunk_tasks, return_exceptions=True)

        updater.cancel()
        try:
            await updater
        except asyncio.CancelledError:
            pass

        # ━━━ Final Report ━━━
        elapsed = max(int(time.time() - start_time), 1)
        throughput = stats['done'] / elapsed

        final_report = (
            f"📡 **MISSION ACCOMPLISHED**\n"
            f"{'━' * 20}\n"
            f"📊 PROCESSED: `{stats['done']}`\n"
            f"✅ SUCCESS: `{stats['ok']}`\n"
            f"❌ FAILED: `{stats['bad']}`\n"
            f"🔄 RETRIED: `{stats['retried']}`\n"
            f"⏱ TIME: `{elapsed}s`\n"
            f"📡 AVG SPEED: `{throughput:.1f} req/s`\n"
            f"⚡ ENGINE: `{'uvloop' if 'uvloop' in sys.modules else 'asyncio'}`\n"
            f"🖥️ CORES: `{CPU_CORES}` | CLIENTS: `{num_clients}`"
        )

        try:
            bot.edit_message_text(final_report, chat_id, main_msg.message_id, parse_mode="Markdown")
        except:
            bot.send_message(chat_id, final_report, parse_mode="Markdown")

        # ━━━ IDs الصفحات الناجحة (Join) ━━━
        if op == 'join' and success_page_ids:
            ids_text = "\n".join(sorted(success_page_ids))
            try:
                bot.send_message(chat_id,
                    f"✅ **الصفحات اللي انضمت ({len(success_page_ids)}):**\n\n```\n{ids_text}\n```",
                    parse_mode="Markdown")
            except:
                bot.send_message(chat_id, f"✅ الصفحات اللي انضمت:\n\n{ids_text}")

        # ━━━ IDs الجروبات الناجحة (Moderator) ━━━
        if op == 'moderator' and success_mod_groups:
            ids_text = "\n".join(sorted(set(success_mod_groups)))
            try:
                bot.send_message(chat_id,
                    f"✅ **جروبات Moderator ({len(set(success_mod_groups))}):**\n\n```\n{ids_text}\n```",
                    parse_mode="Markdown")
            except:
                bot.send_message(chat_id, f"✅ جروبات Moderator:\n\n{ids_text}")

        # ━━━ Error Log ━━━
        if failed_details:
            for i in range(0, min(len(failed_details), 200), 40):
                chunk = failed_details[i:i + 40]
                error_log = "⚠️ **ERROR LOG:**\n" + "\n".join(chunk)
                if i == 0 and len(failed_details) > 200:
                    error_log += f"\n\n+{len(failed_details) - 200} more"
                try:
                    bot.send_message(chat_id, error_log, parse_mode="Markdown")
                except:
                    pass
                await asyncio.sleep(0.3)

        user_state[chat_id] = S_MENU

    except Exception as e:
        print(f"❌ PROCESS ERROR: {e}")
        import traceback
        traceback.print_exc()
        try:
            bot.send_message(chat_id,
                f"❌ **PROCESS CRASHED:**\n`{str(e)[:500]}`",
                parse_mode="Markdown", reply_markup=get_main_menu())
        except:
            pass
        user_state[chat_id] = S_MENU

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 📟 System Info
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@bot.message_handler(func=lambda m: m.text == "📟 SYSTEM INFO")
def my_acc(message):
    chat_id = message.chat.id
    if chat_id in users_db:
        u = users_db[chat_id]
        try:
            import resource
            mem = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
        except:
            mem = 0
        bot.reply_to(message,
            f"📟 **SYSTEM DASHBOARD**\n\n"
            f"👤 `{u['name']}`\n🆔 `{u['id']}`\n🟢 ONLINE\n\n"
            f"🖥️ **SERVER:**\n"
            f"  ⚡ `{CPU_CORES} vCPU` | 🧠 `{MAX_RAM_MB}MB`\n"
            f"  💾 `75GB NVMe` | 📊 `{mem:.0f}MB used`\n\n"
            f"⚙️ **ENGINE:**\n"
            f"  🔧 `{'uvloop ✅' if 'uvloop' in sys.modules else 'asyncio'}`\n"
            f"  🌐 `httpx HTTP/2`\n"
            f"  🔗 `{CPU_CORES} parallel clients`",
            parse_mode="Markdown")

@bot.message_handler(func=lambda m: m.text == "🚫 TERMINATE")
def stop_now(message):
    stop_flags[message.chat.id] = True
    bot.reply_to(message, "⚠️ **TERMINATION SIGNAL SENT**")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🚀 LAUNCH
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def graceful_shutdown(signum, frame):
    print("\n🔴 Shutting down...")
    for cid in stop_flags:
        stop_flags[cid] = True
    bot.stop_polling()
    sys.exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, graceful_shutdown)
    signal.signal(signal.SIGTERM, graceful_shutdown)

    print("=" * 50)
    print("🤖 Cyberpunk Bot v5.0 - NUCLEAR ENGINE")
    print(f"⚡ Loop: {'uvloop' if 'uvloop' in sys.modules else 'asyncio'}")
    print(f"🖥️  {CPU_CORES} vCPU | {MAX_RAM_MB}MB RAM")
    print(f"🔗 {CPU_CORES} parallel HTTP clients")
    print("=" * 50)

    while True:
        try:
            bot.infinity_polling(timeout=60, long_polling_timeout=60,
                                 allowed_updates=["message", "callback_query"])
        except KeyboardInterrupt:
            graceful_shutdown(None, None)
        except Exception as e:
            print(f"⚠️ Crash: {e} | Restart in 3s...")
            time.sleep(3)

"""
Safe structured logging utility.
Prevents leaking tokens, passwords, cookies, and sensitive headers.
"""

import logging
import re
import sys

# Masking patterns to safeguard accidental leakage in messages
_TOKEN_PATTERN = re.compile(r"(EAA[A-Za-z0-9]+|\b\d{8,11}:[A-Za-z0-9_-]{30,40}\b|[A-Za-z0-9]{30,})")


def mask_sensitive(text: str) -> str:
    """Masks tokens, secrets, Authorization headers, and cookies."""
    if not isinstance(text, str):
        text = str(text)
    text = re.sub(r"(Bearer\s+)[A-Za-z0-9_\-\.]+", r"\1[REDACTED_TOKEN]", text, flags=re.IGNORECASE)
    text = re.sub(r"(EAAD[A-Za-z0-9]+|EAA[A-Za-z0-9]{15,})", "[REDACTED_FB_TOKEN]", text)
    text = re.sub(r"(\b\d{8,11}:[A-Za-z0-9_-]{30,40}\b)", "[REDACTED_TG_TOKEN]", text)
    text = re.sub(r"(access_token[\"']?\s*[:=]\s*[\"']?)[^&\"'\s]+", r"\1[REDACTED_TOKEN]", text, flags=re.IGNORECASE)
    return text


class SafeFormatter(logging.Formatter):
    """Logging formatter that redacts sensitive patterns and tokens."""

    def format(self, record: logging.LogRecord) -> str:
        original = super().format(record)
        return mask_sensitive(original)


def setup_logger(name: str = "bot_logger", level: int = logging.INFO) -> logging.Logger:
    """Configures and returns a safe logger instance."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(level)
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)
        formatter = SafeFormatter(
            fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.propagate = False
    return logger


logger = setup_logger()


def log_operation_start(chat_id: int, op_type: str, task_count: int, speed: int) -> None:
    """Safely log operation start without printing any credentials."""
    logger.info("Operation started | chat_id=%s | op=%s | tasks=%s | speed=%s", chat_id, op_type, task_count, speed)


def log_operation_complete(chat_id: int, op_type: str, done: int, ok: int, bad: int, retried: int, elapsed: float) -> None:
    """Safely log operation completion stats."""
    logger.info(
        "Operation completed | chat_id=%s | op=%s | done=%s | ok=%s | bad=%s | retried=%s | elapsed=%.2fs",
        chat_id, op_type, done, ok, bad, retried, elapsed
    )


def log_safe_error(context: str, exc: Exception, chat_id: int | None = None) -> None:
    """Safely log an exception without sensitive payload details."""
    chat_info = f" | chat_id={chat_id}" if chat_id else ""
    error_msg = mask_sensitive(str(exc)[:200])
    logger.error("Error in %s%s: %s (%s)", context, chat_info, type(exc).__name__, error_msg)

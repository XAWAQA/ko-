"""
Cross-platform system information helper.
Provides CPU cores, memory metrics, and uvloop detection.
"""

import os
import sys

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False


def get_cpu_cores() -> int:
    """Returns the number of CPU cores available."""
    return os.cpu_count() or 4


def get_memory_usage_mb() -> float:
    """
    Returns the current process resident memory usage in megabytes.
    Works across Windows, Linux, and macOS using psutil with fallback.
    """
    if _HAS_PSUTIL:
        try:
            process = psutil.Process()
            return process.memory_info().rss / (1024 * 1024)
        except Exception:
            pass

    # Fallback to Unix resource module if available
    try:
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    except (ImportError, Exception):
        return 0.0


def has_uvloop() -> bool:
    """Checks whether uvloop is available in the current runtime."""
    return "uvloop" in sys.modules


def try_install_uvloop() -> bool:
    """Attempts to install uvloop if supported on the platform."""
    try:
        import uvloop
        uvloop.install()
        return True
    except (ImportError, AttributeError, Exception):
        return False

"""
Input validation and sanitization utilities.
"""

import re
from typing import List

_ID_CLEAN_PATTERN = re.compile(r"^[A-Za-z0-9_.-]+$")


def parse_id_list(content: str) -> List[str]:
    """
    Parses a string containing IDs separated by newlines or whitespace.
    Strips whitespace, discards empty lines, and filters invalid items.
    """
    if not content:
        return []

    results = []
    seen = set()
    for line in content.splitlines():
        cleaned = line.strip()
        if not cleaned:
            continue
        # Check against menu emoji buttons to avoid accidental injection
        if any(marker in cleaned for marker in ["⚡", "🔗", "🛡️", "👑", "📟", "📊", "🚫", "⏹️", "🔌", "🔎", "👥"]):
            continue
        # Verify valid ID format (numbers, characters without control chars or spaces)
        if _ID_CLEAN_PATTERN.match(cleaned) and cleaned not in seen:
            results.append(cleaned)
            seen.add(cleaned)

    return results


def is_valid_token(token: str) -> bool:
    """
    Validates basic token structure (non-empty string without whitespace).
    """
    if not token or not isinstance(token, str):
        return False
    stripped = token.strip()
    return len(stripped) >= 10 and not any(c.isspace() for c in stripped)

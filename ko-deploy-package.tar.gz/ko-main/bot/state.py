"""
Thread-safe in-memory state manager for Telegram bot users.
Manages user authentication sessions, conversational states, task payloads, and stop flags.
"""

import threading
from typing import Any, Dict, Optional

# Conversation states matching original workflow plus independent tools
(
    S_AUTH,
    S_MENU,
    S_INPUT_JOIN,
    S_INPUT_APP_GROUPS,
    S_INPUT_APP_MEMBERS,
    S_INPUT_MOD_GROUPS,
    S_INPUT_FF_FILE,
    S_FF_WAIT_SCOPE,
    S_ADMIN_ADD_ID,
    S_ADMIN_SEARCH,
) = range(10)


class StateManager:
    """Thread-safe state store for user sessions and active tasks."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._users_db: Dict[int, Dict[str, Any]] = {}
        self._user_state: Dict[int, int] = {}
        self._user_data: Dict[int, Dict[str, Any]] = {}
        self._stop_flags: Dict[int, bool] = {}
        self._running_tasks: Dict[int, bool] = {}

    def acquire_task_lock(self, chat_id: int) -> bool:
        """
        Attempts to acquire execution lock for a chat_id.
        Returns True if lock acquired (no task was running).
        Returns False if task is already running for this chat (prevents double-tap).
        Resets stop flag to False upon legitimate new task acquisition.
        """
        with self._lock:
            if self._running_tasks.get(chat_id, False):
                return False
            self._running_tasks[chat_id] = True
            self._stop_flags[chat_id] = False
            return True

    def release_task_lock(self, chat_id: int) -> None:
        """Releases the execution lock, allowing future operations."""
        with self._lock:
            self._running_tasks[chat_id] = False
            # If user already logged out/disconnected while task was finishing, clean up stop flag
            if chat_id not in self._users_db:
                self._stop_flags.pop(chat_id, None)

    def is_task_running(self, chat_id: int) -> bool:
        """Checks if an operation is currently executing for this chat."""
        with self._lock:
            return self._running_tasks.get(chat_id, False)

    def set_user(self, chat_id: int, user_info: Dict[str, Any]) -> None:
        """Stores authenticated user information."""
        with self._lock:
            self._users_db[chat_id] = user_info

    def get_user(self, chat_id: int) -> Optional[Dict[str, Any]]:
        """Retrieves authenticated user details or None."""
        with self._lock:
            user = self._users_db.get(chat_id)
            return dict(user) if user else None

    def has_user(self, chat_id: int) -> bool:
        """Checks if a user session exists."""
        with self._lock:
            return chat_id in self._users_db

    def set_state(self, chat_id: int, state: int) -> None:
        """Sets the conversational step for a chat."""
        with self._lock:
            self._user_state[chat_id] = state

    def get_state(self, chat_id: int) -> Optional[int]:
        """Gets current conversational state for a chat."""
        with self._lock:
            return self._user_state.get(chat_id)

    def init_operation_data(self, chat_id: int, op_type: str) -> None:
        """Initializes empty operation data for a user action."""
        with self._lock:
            self._user_data[chat_id] = {"op": op_type}

    def set_data(self, chat_id: int, key: str, value: Any) -> None:
        """Stores a specific data attribute for the current operation."""
        with self._lock:
            if chat_id not in self._user_data:
                self._user_data[chat_id] = {}
            self._user_data[chat_id][key] = value

    def get_data(self, chat_id: int) -> Dict[str, Any]:
        """Returns the current operation payload dictionary."""
        with self._lock:
            data = self._user_data.get(chat_id, {})
            return dict(data)

    def update_data(self, chat_id: int, updates: Dict[str, Any]) -> None:
        """Updates multiple keys in operation data."""
        with self._lock:
            if chat_id not in self._user_data:
                self._user_data[chat_id] = {}
            self._user_data[chat_id].update(updates)

    def clear_data(self, chat_id: int) -> None:
        """Clears transient operation data for a user."""
        with self._lock:
            self._user_data.pop(chat_id, None)

    def set_stop_flag(self, chat_id: int, flag: bool) -> None:
        """
        Sets the cancellation flag for an ongoing task.
        Guards against accidental reset to False while a task is actively running.
        """
        with self._lock:
            if not flag and self._running_tasks.get(chat_id, False):
                return
            self._stop_flags[chat_id] = flag

    def is_stopped(self, chat_id: int) -> bool:
        """Checks if cancellation has been requested."""
        with self._lock:
            return self._stop_flags.get(chat_id, False)

    def disconnect(self, chat_id: int) -> None:
        """
        Completely purges all sensitive credentials, tokens, states, and data
        for the given chat_id to ensure clean logout and zero memory leaks.
        If a task is running, actively signals it to terminate while keeping lock.
        If no task is running, cleans up stop flags and task state completely.
        """
        with self._lock:
            self._users_db.pop(chat_id, None)
            self._user_data.pop(chat_id, None)
            if self._running_tasks.get(chat_id, False):
                self._stop_flags[chat_id] = True
            else:
                self._stop_flags.pop(chat_id, None)
                self._running_tasks.pop(chat_id, None)
            self._user_state[chat_id] = S_AUTH

    def reset_all(self) -> None:
        """Purges all state across all users (used primarily in tests)."""
        with self._lock:
            self._users_db.clear()
            self._user_state.clear()
            self._user_data.clear()
            self._stop_flags.clear()
            self._running_tasks.clear()


# Default singleton instance
state_manager = StateManager()

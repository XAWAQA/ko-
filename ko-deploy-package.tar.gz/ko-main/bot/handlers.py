"""
Telegram message and callback handlers.
Coordinates user interactions, keyboards, input parsing, and worker triggers.
"""

import os
from typing import Any, Dict, List
import telebot
from telebot import types

from access.manager import AccessManager, access_manager, format_user_card
from bot.keyboards import (
    get_add_confirm_keyboard,
    get_add_role_keyboard,
    get_confirm_buttons,
    get_delete_confirm_keyboard,
    get_ff_scope_buttons,
    get_main_menu,
    get_pages_list,
    get_search_list_keyboard,
    get_source_buttons,
    get_speed_buttons,
    get_user_mgmt_menu,
    get_users_list_keyboard,
    get_conv_pages_keyboard,
)
from bot.state import (
    S_ADMIN_ADD_ID,
    S_ADMIN_SEARCH,
    S_AUTH,
    S_INPUT_APP_GROUPS,
    S_INPUT_APP_MEMBERS,
    S_INPUT_FF_FILE,
    S_FF_WAIT_SCOPE,
    S_INPUT_JOIN,
    S_INPUT_MOD_GROUPS,
    S_MENU,
    StateManager,
    state_manager,
)
from config import CPU_CORES, MAX_RAM_MB
from facebook.client import FacebookClient
from tools.ff_checker import FFCheckerEngine, extract_c_user_ids, load_checked_ids
from utils.logging import log_safe_error
from utils.system import get_memory_usage_mb, has_uvloop
from utils.validation import is_valid_token, parse_id_list
from workers.engine import WorkerEngine
BTN_CONNECT_GROUPS = ("🔗 CONNECT GROUPS", "⚡ CONNECT GROUPS")
BTN_APPROVE_MEMBERS = ("🛡️ APPROVE MEMBERS",)
BTN_MODERATOR_APPROVAL = ("👑 MODERATOR APPROVAL",)
BTN_FF_CHECKER = ("🔎 FF CHECKER",)
BTN_SYSTEM_STATUS = ("📊 SYSTEM STATUS", "📟 SYSTEM INFO")
BTN_STOP_TASK = ("⏹️ STOP TASK", "🚫 TERMINATE")
BTN_USER_MANAGEMENT = ("👥 USER MANAGEMENT", "👥 إدارة المستخدمين")
BTN_DISCONNECT = ("🔌 DISCONNECT",)

ALL_NAV_BUTTONS = set(
    BTN_CONNECT_GROUPS
    + BTN_APPROVE_MEMBERS
    + BTN_MODERATOR_APPROVAL
    + BTN_FF_CHECKER
    + BTN_SYSTEM_STATUS
    + BTN_STOP_TASK
    + BTN_USER_MANAGEMENT
    + BTN_DISCONNECT
)
NAV_COMMANDS = {"/start", "/menu", "/cancel", "/stop", "/help"}


def _is_nav_input(message: types.Message) -> bool:
    """Returns True if message represents a menu button or navigation command."""
    text = (getattr(message, "text", None) or "").strip()
    if not text:
        return False
    if text in ALL_NAV_BUTTONS:
        return True
    first_word = text.split()[0].lower()
    if first_word in NAV_COMMANDS or first_word.startswith("/"):
        return True
    return False


def register_handlers(
    bot: telebot.TeleBot,
    engine: WorkerEngine,
    state: StateManager = state_manager,
    fb_client: FacebookClient | None = None,
    ff_checker_engine: FFCheckerEngine | None = None,
    access_mgr: AccessManager | None = None,
) -> None:
    """Registers all Telegram message and callback handlers onto the TeleBot instance."""
    client = fb_client or engine.fb_client
    ff_engine = ff_checker_engine or FFCheckerEngine(bot=bot, state=state)
    ac = access_mgr or access_manager

    def _menu(chat_id: int) -> types.ReplyKeyboardMarkup:
        role = ac.get_role(chat_id) or "user"
        return get_main_menu(role=role)

    def _check_auth(message: types.Message) -> bool:
        chat_id = message.chat.id
        if getattr(message, "from_user", None):
            ac.sync_telegram_profile(message.from_user)
        if not ac.is_authorized(chat_id):
            bot.send_message(
                chat_id,
                f"⛔ **عذرًا، الوصول غير مصرح به.**\n\n"
                f"حسابك غير مسجل في النظام. تواصل مع مسؤول البوت للحصول على إذن الوصول.\n\n"
                f"🆔 معرفك: `{chat_id}`",
                parse_mode="Markdown",
            )
            return False
        return True

    def _check_cb_auth(call: types.CallbackQuery, required_role: str = "user") -> bool:
        chat_id = call.message.chat.id
        if getattr(call, "from_user", None):
            ac.sync_telegram_profile(call.from_user)
        if not ac.is_authorized(chat_id):
            try:
                bot.answer_callback_query(call.id, "⛔ غير مصرح لك بتنفيذ هذا الإجراء.", show_alert=True)
            except Exception:
                pass
            return False
        if required_role in ("admin", "owner") and not ac.is_admin_or_owner(chat_id):
            try:
                bot.answer_callback_query(call.id, "⛔ يتطلب هذا الإجراء صلاحيات إدارية.", show_alert=True)
            except Exception:
                pass
            return False
        if required_role == "owner" and not ac.is_owner(chat_id):
            try:
                bot.answer_callback_query(call.id, "⛔ هذا الإجراء مخصص لمالك البوت فقط.", show_alert=True)
            except Exception:
                pass
            return False
        return True

    def _extract_content(message: types.Message) -> str:
        """Extracts text content either from message text or uploaded document file."""
        if message.document:
            raw_name = getattr(message.document, "file_name", None)
            doc_name = str(raw_name).lower() if raw_name else ""
            if doc_name and not doc_name.endswith((".txt", ".csv", ".log")):
                return ""
            raw_size = getattr(message.document, "file_size", None)
            if isinstance(raw_size, int) and raw_size > 5 * 1024 * 1024:
                return ""
            try:
                file_info = bot.get_file(message.document.file_id)
                downloaded = bot.download_file(file_info.file_path)
                return downloaded.decode("utf-8", errors="replace")
            except Exception as exc:
                log_safe_error("download_file", exc, message.chat.id)
                return ""
        return message.text or ""

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 🕹️ Auth & Main Menu
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 🧭 Top Navigation & Command Handlers
    # (Registered FIRST to prevent input traps)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.message_handler(commands=["start", "menu", "help", "cancel"])
    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_DISCONNECT)
    def handle_start(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return

        if state.is_task_running(chat_id):
            state.set_stop_flag(chat_id, True)

        state.clear_data(chat_id)

        is_disconnect = (getattr(message, "text", None) or "").strip() in BTN_DISCONNECT
        if state.has_user(chat_id) and not is_disconnect:
            user = state.get_user(chat_id)
            user_name = user["name"] if user else "User"
            bot.send_message(
                chat_id,
                f"Welcome back, **{user_name}** 🟢\n"
                f"🖥️ `{CPU_CORES} vCPU | {MAX_RAM_MB}MB RAM`",
                parse_mode="Markdown",
                reply_markup=_menu(chat_id),
            )
            state.set_state(chat_id, S_MENU)
        else:
            state.disconnect(chat_id)
            bot.send_message(
                chat_id,
                "🔐 **ENTER ACCESS TOKEN:**",
                parse_mode="Markdown",
                reply_markup=_menu(chat_id),
            )
            state.set_state(chat_id, S_AUTH)

    @bot.message_handler(commands=["ff", "checker"])
    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_FF_CHECKER)
    def handle_ff_start(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if state.is_task_running(chat_id):
            bot.reply_to(message, "⚠️ **هناك عملية قيد التشغيل بالفعل!** يرجى الانتظار أو الإيقاف أولاً.")
            return

        state.clear_data(chat_id)
        state.init_operation_data(chat_id, "ff_checker")
        state.set_state(chat_id, S_INPUT_FF_FILE)
        cancel_kb = types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("🔴 إلغاء", callback_data="ff_cancel")
        )
        bot.send_message(
            chat_id,
            "🔎 **FF CHECKER — فحص الحسابات (Profile Picture & ID Check)**\n\n"
            "📥 أرسل ملف `.txt` يحتوي على أسطر الكوكيز (الحد الأقصى 10MB) أو أرسل أسطر الكوكيز مباشرة كنص.\n\n"
            "🔒 **الخصوصية والأمان:**\n"
            "سيتم استخراج معرفات `c_user` فقط ولن يتم تخزين أو إرسال أي كوكيز إطلاقاً.",
            parse_mode="Markdown",
            reply_markup=cancel_kb,
        )

    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_MODERATOR_APPROVAL)
    def handle_mod_start(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not state.has_user(chat_id):
            bot.reply_to(message, "❌ **LOGIN FIRST!**", parse_mode="Markdown")
            return

        state.clear_data(chat_id)
        state.init_operation_data(chat_id, "moderator")
        bot.send_message(chat_id, "📥 **أرسل Group IDs:**\n(كل ID في سطر)", parse_mode="Markdown")
        state.set_state(chat_id, S_INPUT_MOD_GROUPS)

    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_CONNECT_GROUPS)
    def handle_join_start(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not state.has_user(chat_id):
            bot.reply_to(message, "❌ **LOGIN FIRST!**", parse_mode="Markdown")
            return

        state.clear_data(chat_id)
        bot.send_message(
            chat_id,
            "🛠️ **SELECT UPLINK SOURCE:**",
            parse_mode="Markdown",
            reply_markup=get_source_buttons(),
        )

    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_APPROVE_MEMBERS)
    def handle_approve_start(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not state.has_user(chat_id):
            bot.reply_to(message, "❌ **LOGIN FIRST!**", parse_mode="Markdown")
            return

        state.clear_data(chat_id)
        state.init_operation_data(chat_id, "approve")
        state.set_data(chat_id, "app_groups", [])
        state.set_data(chat_id, "app_members", [])
        bot.send_message(chat_id, "1️⃣ **UPLINK:** أرسل قائمة (Group IDs):")
        state.set_state(chat_id, S_INPUT_APP_GROUPS)

    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_USER_MANAGEMENT)
    def handle_user_management_entry(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not ac.is_admin_or_owner(chat_id):
            bot.reply_to(message, "⛔ **ليس لديك صلاحية للوصول إلى لوحة إدارة المستخدمين.**", parse_mode="Markdown")
            return

        state.clear_data(chat_id)
        user_obj = ac.get_user(chat_id)
        role = ac.get_role(chat_id) or "user"
        name = user_obj.first_name if (user_obj and user_obj.first_name) else "المسؤول"
        is_owner = ac.is_owner(chat_id)

        bot.send_message(
            chat_id,
            f"👥 **لوحة إدارة المستخدمين والصلاحيات**\n\n"
            f"👤 **المسؤول الحالي:** `{name}`\n"
            f"🎭 **الدور:** `{role.upper()}`\n\n"
            f"اختر العملية المطلوبة من القائمة أدناه:",
            parse_mode="Markdown",
            reply_markup=get_user_mgmt_menu(is_owner=is_owner),
        )

    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_SYSTEM_STATUS)
    def handle_system_info(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        state.clear_data(chat_id)
        user = state.get_user(chat_id)
        if user:
            user_section = f"👤 `{user['name']}`\n🆔 `{user['id']}`\n🟢 ONLINE"
        else:
            u_obj = ac.get_user(chat_id)
            uname = u_obj.first_name if (u_obj and u_obj.first_name) else "Authorized User"
            role = ac.get_role(chat_id) or "user"
            user_section = f"👤 `{uname}` (Telegram)\n🎭 `{role.upper()}`\n⚪ FB: NOT CONNECTED"

        mem_mb = get_memory_usage_mb()
        engine_str = "uvloop ✅" if has_uvloop() else "asyncio"

        bot.reply_to(
            message,
            f"📟 **SYSTEM DASHBOARD**\n\n"
            f"{user_section}\n\n"
            f"🖥️ **SERVER:**\n"
            f"  ⚡ `{CPU_CORES} vCPU` | 🧠 `{MAX_RAM_MB}MB`\n"
            f"  💾 `75GB NVMe` | 📊 `{mem_mb:.0f}MB used`\n\n"
            f"⚙️ **ENGINE:**\n"
            f"  🔧 `{engine_str}`\n"
            f"  🌐 `httpx HTTP/2`\n"
            f"  🔗 `{CPU_CORES} parallel clients`",
            parse_mode="Markdown",
        )

    @bot.message_handler(func=lambda m: (getattr(m, "text", None) or "").strip() in BTN_STOP_TASK)
    def handle_stop_now(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        state.set_stop_flag(chat_id, True)
        state.clear_data(chat_id)
        state.set_state(chat_id, S_MENU)
        bot.reply_to(message, "⚠️ **TERMINATION SIGNAL SENT**")

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 📝 Input State Handlers
    # (Guarded with not _is_nav_input(m))
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.message_handler(func=lambda m: state.get_state(m.chat.id) == S_AUTH and not _is_nav_input(m))
    def handle_login(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return

        token = (message.text or "").strip()

        # Delete incoming token message from chat history for privacy
        try:
            bot.delete_message(chat_id, message.message_id)
        except Exception:
            pass

        if not is_valid_token(token):
            bot.send_message(chat_id, "❌ **INVALID TOKEN FORMAT**", parse_mode="Markdown")
            return

        wait_msg = bot.send_message(chat_id, "🛰️ **AUTHENTICATING...**")

        async def verify():
            try:
                fb_user = await client.verify_token(token)
                state.set_user(chat_id, {"token": fb_user.token, "id": fb_user.id, "name": fb_user.name})
                try:
                    bot.delete_message(chat_id, wait_msg.message_id)
                except Exception:
                    pass
                bot.send_message(
                    chat_id,
                    f"✅ **ACCESS GRANTED**\nNode: `{fb_user.name}`",
                    parse_mode="Markdown",
                    reply_markup=_menu(chat_id),
                )
                state.set_state(chat_id, S_MENU)
            except ValueError:
                bot.edit_message_text("❌ **INVALID TOKEN**", chat_id, wait_msg.message_id)
            except Exception as exc:
                log_safe_error("verify_token", exc, chat_id)
                bot.edit_message_text("⚠️ **CONNECTION ERROR**", chat_id, wait_msg.message_id)

        engine.run_async(verify(), chat_id)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 👑 Moderator Approval
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.message_handler(
        content_types=["document", "text"],
        func=lambda m: state.get_state(m.chat.id) == S_INPUT_MOD_GROUPS and not _is_nav_input(m),
    )
    def handle_receive_mod_groups(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        content = _extract_content(message)
        groups = parse_id_list(content)
        if not groups:
            bot.reply_to(message, "❌ EMPTY LIST!")
            return

        state.set_data(chat_id, "mod_groups", groups)
        bot.send_message(
            chat_id,
            f"✅ Received `{len(groups)}` Groups\n\n🏎️ **SET SPEED:**",
            parse_mode="Markdown",
            reply_markup=get_speed_buttons(),
        )

    @bot.callback_query_handler(func=lambda call: call.data.startswith("src_"))
    def handle_select_source(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass

        state.init_operation_data(chat_id, "join")
        state.set_data(chat_id, "actors", [])

        if call.data == "src_me":
            user = state.get_user(chat_id)
            if not user:
                return
            state.set_data(chat_id, "actors", [{"id": user["id"], "name": user["name"], "token": user["token"]}])
            bot.send_message(chat_id, "📥 **STEP 1:** Send Target Group IDs:")
            state.set_state(chat_id, S_INPUT_JOIN)

        elif call.data == "src_pages":
            msg = bot.send_message(chat_id, "📡 **SCANNING DATABASE...**")

            async def fetch_pages():
                user = state.get_user(chat_id)
                if not user:
                    return
                try:
                    pages = await client.get_pages(user["token"])
                    if not pages:
                        bot.edit_message_text("❌ **NO PAGES FOUND**", chat_id, msg.message_id)
                        return

                    pages_data = [{"id": p.id, "name": p.name, "token": p.token} for p in pages]
                    state.set_data(chat_id, "all_pages", pages_data)
                    state.set_data(chat_id, "selected_pages", [])
                    try:
                        bot.delete_message(chat_id, msg.message_id)
                    except Exception:
                        pass
                    bot.send_message(
                        chat_id,
                        "💎 **SELECT TARGET PAGES:**",
                        reply_markup=get_pages_list(pages_data, []),
                    )
                except Exception as exc:
                    log_safe_error("fetch_pages", exc, chat_id)
                    bot.edit_message_text("⚠️ **SCAN FAILED**", chat_id, msg.message_id)

            engine.run_async(fetch_pages(), chat_id)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("pg:") or call.data in ["toggle_all", "done_select"])
    def handle_pages_toggle(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        data = state.get_data(chat_id)
        all_p = data.get("all_pages", [])
        sel: List[str] = list(data.get("selected_pages", []))

        if call.data == "done_select":
            if not sel:
                bot.answer_callback_query(call.id, "SELECT AT LEAST ONE NODE!")
                return
            actors = [
                {"id": p["id"], "name": p["name"], "token": p["token"]}
                for p in all_p if p["id"] in sel
            ]
            state.set_data(chat_id, "actors", actors)
            try:
                bot.delete_message(chat_id, call.message.message_id)
            except Exception:
                pass
            bot.send_message(chat_id, "📥 **STEP 1:** Send Target Group IDs:")
            state.set_state(chat_id, S_INPUT_JOIN)
            return

        elif call.data == "toggle_all":
            new_sel = [] if len(sel) == len(all_p) else [p["id"] for p in all_p]
            state.set_data(chat_id, "selected_pages", new_sel)
            sel = new_sel
        else:
            pid = call.data.split(":")[1]
            if pid in sel:
                sel.remove(pid)
            else:
                sel.append(pid)
            state.set_data(chat_id, "selected_pages", sel)

        try:
            bot.edit_message_reply_markup(
                chat_id,
                call.message.message_id,
                reply_markup=get_pages_list(all_p, sel),
            )
        except Exception:
            pass

    @bot.message_handler(
        content_types=["document", "text"],
        func=lambda m: state.get_state(m.chat.id) == S_INPUT_JOIN and not _is_nav_input(m),
    )
    def handle_receive_join_groups(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        content = _extract_content(message)
        lines = parse_id_list(content)
        if not lines:
            bot.reply_to(message, "❌ DATA STREAM EMPTY!")
            return

        state.set_data(chat_id, "targets", lines)
        bot.send_message(chat_id, "🏎️ **SET OVERCLOCK SPEED:**", reply_markup=get_speed_buttons())

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 🛡️ Approve Members Input Handlers
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.message_handler(
        content_types=["document", "text"],
        func=lambda m: state.get_state(m.chat.id) == S_INPUT_APP_GROUPS and not _is_nav_input(m),
    )
    def handle_receive_app_groups(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        content = _extract_content(message)
        groups = parse_id_list(content)
        if not groups:
            bot.reply_to(message, "❌ EMPTY LIST!")
            return

        state.set_data(chat_id, "app_groups", groups)
        bot.send_message(
            chat_id,
            f"✅ Received {len(groups)} Groups.\n\n2️⃣ **TARGETS:** الآن أرسل قائمة (Member IDs):",
        )
        state.set_state(chat_id, S_INPUT_APP_MEMBERS)

    @bot.message_handler(
        content_types=["document", "text"],
        func=lambda m: state.get_state(m.chat.id) == S_INPUT_APP_MEMBERS and not _is_nav_input(m),
    )
    def handle_receive_app_members(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        content = _extract_content(message)
        members = parse_id_list(content)
        if not members:
            bot.reply_to(message, "❌ EMPTY LIST!")
            return

        state.set_data(chat_id, "app_members", members)
        bot.send_message(chat_id, "🏎️ **SET OVERCLOCK SPEED:**", reply_markup=get_speed_buttons())

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # ⚡ Concurrency & Confirmation
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.callback_query_handler(func=lambda call: call.data.startswith("spd:"))
    def handle_show_summary(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        speed = int(call.data.split(":")[1])
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass

        data = state.get_data(chat_id)
        op = data.get("op", "")

        if op == "join":
            total_ops = len(data.get("targets", [])) * len(data.get("actors", []))
        elif op == "approve":
            total_ops = len(data.get("app_groups", [])) * len(data.get("app_members", []))
        elif op == "moderator":
            total_ops = len(data.get("mod_groups", []))
        else:
            total_ops = 0

        engine_name = "uvloop" if has_uvloop() else "asyncio"
        summary = (
            f"📑 **MISSION BRIEFING**\n"
            f"⚙️ TYPE: `{op.upper()}`\n"
            f"🔢 TOTAL OPS: `{total_ops}`\n"
            f"🚀 CONCURRENCY: `{speed} simultaneous`\n"
            f"⚡ ENGINE: `{engine_name}`\n\n"
            f"INITIALIZE?"
        )
        bot.send_message(
            chat_id,
            summary,
            parse_mode="Markdown",
            reply_markup=get_confirm_buttons(speed),
        )

    @bot.callback_query_handler(func=lambda call: call.data == "cancel_run")
    def handle_cancel_run(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass
        state.set_state(chat_id, S_MENU)
        state.clear_data(chat_id)
        bot.send_message(chat_id, "🚫 **MISSION ABORTED.**", reply_markup=_menu(chat_id))

    @bot.callback_query_handler(func=lambda call: call.data.startswith("confirm:"))
    def handle_start_run_confirmed(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        speed = int(call.data.split(":")[1])

        # Prevent duplicate click / concurrent run
        if not state.acquire_task_lock(chat_id):
            try:
                bot.answer_callback_query(
                    call.id,
                    "⚠️ هناك عملية قيد التشغيل بالفعل! يرجى الانتظار أو الإيقاف أولاً.",
                    show_alert=True,
                )
            except Exception:
                pass
            return

        try:
            bot.answer_callback_query(call.id, "🚀 تم بدء العملية...")
        except Exception:
            pass

        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass

        engine.run_async(engine.process_async(chat_id, speed), chat_id)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 🔎 FF Checker (Profile Picture & ID Check)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.message_handler(
        content_types=["document", "text"],
        func=lambda m: state.get_state(m.chat.id) == S_INPUT_FF_FILE and not _is_nav_input(m),
    )
    def handle_receive_ff_file(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return

        content = ""
        if message.document:
            raw_name = getattr(message.document, "file_name", None)
            doc_name = str(raw_name).lower() if raw_name else ""
            if doc_name and not doc_name.endswith(".txt"):
                bot.reply_to(message, "❌ **صيغة الملف غير مدعومة!** يرجى إرسال ملف بصيغة `.txt` فقط.", parse_mode="Markdown")
                return

            raw_size = getattr(message.document, "file_size", None)
            if isinstance(raw_size, int) and raw_size > 10 * 1024 * 1024:
                bot.reply_to(message, "❌ **حجم الملف كبير جداً!** الحد الأقصى المسموح به هو 10MB.", parse_mode="Markdown")
                return

            try:
                file_info = bot.get_file(message.document.file_id)
                downloaded = bot.download_file(file_info.file_path)
                content = downloaded.decode("utf-8", errors="replace")
            except Exception as exc:
                log_safe_error("download_ff_file", exc, chat_id)
                bot.reply_to(message, "⚠️ **فشل تنزيل وقراءة الملف.** يرجى المحاولة مرة أخرى.")
                return
        else:
            content = message.text or ""

        if not content.strip():
            bot.reply_to(message, "❌ **يرجى إرسال ملف .txt صالح أو نص يحتوي على بيانات الكوكيز.**")
            return

        ids, total_lines = extract_c_user_ids(content)
        if not ids:
            bot.reply_to(
                message,
                "❌ **لم يتم العثور على أي معرفات `c_user` صالحة!**\nيرجى التأكد من أن الملف يحتوي على أسطر كوكيز تتضمن `c_user=...`.",
                parse_mode="Markdown",
            )
            return

        state.init_operation_data(chat_id, "ff_checker")
        state.set_data(chat_id, "ff_ids", ids)
        state.set_data(chat_id, "ff_total_lines", total_lines)
        state.set_state(chat_id, S_FF_WAIT_SCOPE)

        bot.send_message(
            chat_id,
            f"📊 **تم تحليل الملف بنجاح:**\n\n"
            f"📄 إجمالي الأسطر: `{total_lines}`\n"
            f"🆔 المعرفات الفريدة المستخرجة: `{len(ids)}`\n\n"
            f"هل تريد تخطي الـIDs التي تم فحصها سابقًا؟",
            parse_mode="Markdown",
            reply_markup=get_ff_scope_buttons(),
        )

    @bot.callback_query_handler(func=lambda call: call.data.startswith("ff_scope:"))
    def handle_ff_scope_selection(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        scope_type = call.data.split(":")[1]

        data = state.get_data(chat_id)
        all_ids: List[str] = data.get("ff_ids", [])
        total_lines: int = data.get("ff_total_lines", len(all_ids))

        if not all_ids:
            try:
                bot.answer_callback_query(call.id, "❌ انتهت صلاحية الجلسة أو البيانات فارغة.")
            except Exception:
                pass
            state.set_state(chat_id, S_MENU)
            return

        checked_file = os.path.join(ff_engine.base_dir, "checked.txt")
        if scope_type == "skip_checked":
            checked_ids = load_checked_ids(checked_file)
            ids_to_check = [uid for uid in all_ids if uid not in checked_ids]
            skipped_count = len(all_ids) - len(ids_to_check)
            if not ids_to_check:
                try:
                    bot.edit_message_text(
                        f"ℹ️ **جميع المعرفات المستخرجة ({len(all_ids)}) تم فحصها سابقًا!**\nلا توجد أي حسابات جديدة للفحص.",
                        chat_id,
                        call.message.message_id,
                        parse_mode="Markdown",
                    )
                except Exception:
                    bot.send_message(chat_id, f"ℹ️ جميع المعرفات ({len(all_ids)}) تم فحصها سابقًا!")
                state.set_state(chat_id, S_MENU)
                state.clear_data(chat_id)
                return
        else:  # check_all
            ids_to_check = list(all_ids)
            skipped_count = 0

        if not state.acquire_task_lock(chat_id):
            try:
                bot.answer_callback_query(
                    call.id,
                    "⚠️ هناك عملية قيد التشغيل بالفعل! يرجى الانتظار أو الإيقاف أولاً.",
                    show_alert=True,
                )
            except Exception:
                pass
            return

        try:
            bot.answer_callback_query(call.id, "🚀 تم بدء الفحص...")
        except Exception:
            pass

        initial_text = (
            f"🔎 **FF CHECKER — جاري بدء الفحص...**\n"
            f"{'━' * 20}\n"
            f"📄 إجمالي الأسطر: `{total_lines}`\n"
            f"🆔 المستخرجة: `{len(all_ids)}`\n"
            f"⏩ تم تخطيها: `{skipped_count}`\n"
            f"🎯 المستهدفة للفحص: `{len(ids_to_check)}`"
        )
        try:
            bot.edit_message_text(
                initial_text,
                chat_id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("🛑 إيقاف الفحص", callback_data="ff_stop")
                ),
            )
            msg_id = call.message.message_id
        except Exception:
            msg = bot.send_message(
                chat_id,
                initial_text,
                parse_mode="Markdown",
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("🛑 إيقاف الفحص", callback_data="ff_stop")
                ),
            )
            msg_id = msg.message_id

        engine.run_async(
            ff_engine.execute_task(
                chat_id=chat_id,
                ids_to_check=ids_to_check,
                skipped_count=skipped_count,
                total_lines=total_lines,
                initial_msg_id=msg_id,
            ),
            chat_id,
        )

    @bot.callback_query_handler(func=lambda call: call.data == "ff_stop")
    def handle_ff_stop(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        state.set_stop_flag(chat_id, True)
        try:
            bot.answer_callback_query(call.id, "🛑 جاري إيقاف الفحص بأمان...")
        except Exception:
            pass

    @bot.callback_query_handler(func=lambda call: call.data == "ff_cancel")
    def handle_ff_cancel(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass
        state.set_state(chat_id, S_MENU)
        state.clear_data(chat_id)
        bot.send_message(chat_id, "🚫 **تم إلغاء عملية فحص FF.**", parse_mode="Markdown", reply_markup=_menu(chat_id))

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 👥 User Management & Access Control
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━



    @bot.callback_query_handler(func=lambda call: call.data == "um_back")
    def handle_um_back(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return
        user_obj = ac.get_user(chat_id)
        role = ac.get_role(chat_id) or "user"
        name = user_obj.first_name if (user_obj and user_obj.first_name) else "المسؤول"
        is_owner = ac.is_owner(chat_id)
        try:
            bot.edit_message_text(
                f"👥 **لوحة إدارة المستخدمين والصلاحيات**\n\n"
                f"👤 **المسؤول الحالي:** `{name}`\n"
                f"🎭 **الدور:** `{role.upper()}`\n\n"
                f"اختر العملية المطلوبة من القائمة أدناه:",
                chat_id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=get_user_mgmt_menu(is_owner=is_owner),
            )
        except Exception:
            bot.send_message(
                chat_id,
                "👥 **لوحة إدارة المستخدمين والصلاحيات**",
                reply_markup=get_user_mgmt_menu(is_owner=is_owner),
            )

    @bot.callback_query_handler(func=lambda call: call.data == "um_close")
    def handle_um_close(call: types.CallbackQuery) -> None:
        if not _check_cb_auth(call, required_role="admin"):
            return
        chat_id = call.message.chat.id
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass

    @bot.callback_query_handler(func=lambda call: call.data == "um_cancel")
    def handle_um_cancel(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return
        state.clear_data(chat_id)
        state.set_state(chat_id, S_MENU)
        try:
            bot.edit_message_text("🚫 **تم إلغاء العملية الإدارية.**", chat_id, call.message.message_id)
        except Exception:
            bot.send_message(chat_id, "🚫 **تم إلغاء العملية الإدارية.**")

    @bot.callback_query_handler(func=lambda call: call.data == "um_add_start")
    def handle_um_add_start(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        if ac.is_owner(chat_id):
            try:
                bot.edit_message_text(
                    "👑 **إضافة مستخدم جديد**\n\nاختر الدور الذي ترغب في منحه للحساب:",
                    chat_id,
                    call.message.message_id,
                    parse_mode="Markdown",
                    reply_markup=get_add_role_keyboard(),
                )
            except Exception:
                bot.send_message(chat_id, "👑 **إضافة مستخدم جديد**", reply_markup=get_add_role_keyboard())
        else:
            # Admin can only add 'user'
            state.init_operation_data(chat_id, "add_user")
            state.set_data(chat_id, "pending_role", "user")
            state.set_state(chat_id, S_ADMIN_ADD_ID)
            cancel_kb = types.InlineKeyboardMarkup().add(types.InlineKeyboardButton("🔴 إلغاء", callback_data="um_cancel"))
            try:
                bot.edit_message_text(
                    "📥 **إضافة عضو جديد (USER)**\n\nأرسل **Telegram ID** الرقمي للحساب المطلوب إضافته:",
                    chat_id,
                    call.message.message_id,
                    parse_mode="Markdown",
                    reply_markup=cancel_kb,
                )
            except Exception:
                bot.send_message(chat_id, "📥 **إضافة عضو جديد (USER)**", reply_markup=cancel_kb)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("um_set_role:"))
    def handle_um_set_role(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        # Strict hierarchy: ONLY Owner can set roles
        if not _check_cb_auth(call, required_role="owner"):
            return
        selected_role = call.data.split(":")[1]
        state.init_operation_data(chat_id, "add_user")
        state.set_data(chat_id, "pending_role", selected_role)
        state.set_state(chat_id, S_ADMIN_ADD_ID)

        role_title = "مشرف (ADMIN)" if selected_role == "admin" else "عضو (USER)"
        cancel_kb = types.InlineKeyboardMarkup().add(types.InlineKeyboardButton("🔴 إلغاء", callback_data="um_cancel"))
        try:
            bot.edit_message_text(
                f"📥 **إضافة حساب بدور: {role_title}**\n\nأرسل **Telegram ID** الرقمي للحساب المطلوب إضافته:",
                chat_id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=cancel_kb,
            )
        except Exception:
            bot.send_message(chat_id, f"📥 أرسل Telegram ID لإضافته كـ {role_title}:", reply_markup=cancel_kb)

    @bot.message_handler(func=lambda m: state.get_state(m.chat.id) == S_ADMIN_ADD_ID and not _is_nav_input(m))
    def handle_receive_add_id(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not ac.is_admin_or_owner(chat_id):
            return

        text = (message.text or "").strip()
        if not text.isdigit() or int(text) <= 0:
            bot.reply_to(
                message,
                "❌ **معرّف غير صالح!** يرجى إرسال أرقام معرّف Telegram ID فقط (أرقام موجبة بدون مسافات أو أحرف).",
                parse_mode="Markdown",
            )
            return

        target_id = int(text)
        if target_id == ac.owner_id:
            bot.reply_to(message, "ℹ️ هذا المعرّف يخص مالك البوت الأساسي بالفعل ولا يمكن تعديله.")
            state.clear_data(chat_id)
            state.set_state(chat_id, S_MENU)
            return

        data = state.get_data(chat_id)
        role = data.get("pending_role", "user")

        # Admin cannot add admin
        if not ac.is_owner(chat_id) and role != "user":
            bot.reply_to(message, "⛔ المشرف يملك صلاحية إضافة أعضاء (USER) فقط.")
            state.clear_data(chat_id)
            state.set_state(chat_id, S_MENU)
            return

        state.set_data(chat_id, "pending_target_id", target_id)
        role_label = "مشرف (ADMIN)" if role == "admin" else "عضو (USER)"

        bot.send_message(
            chat_id,
            f"⚠️ **تأكيد إضافة الحساب**\n\n"
            f"🆔 **معرّف Telegram:** `{target_id}`\n"
            f"🎭 **الدور المطلوب منحه:** `{role_label}`\n\n"
            f"هل أنت متأكد من رغبتك في حفظ الحساب ومنحه إذن استخدام البوت؟",
            parse_mode="Markdown",
            reply_markup=get_add_confirm_keyboard(),
        )

    @bot.callback_query_handler(func=lambda call: call.data == "um_add_confirm")
    def handle_um_add_confirm(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        data = state.get_data(chat_id)
        target_id = data.get("pending_target_id")
        role = data.get("pending_role", "user")

        if not target_id:
            bot.answer_callback_query(call.id, "❌ انتهت الجلسة أو البيانات فارغة.")
            return

        actor_name = ""
        if call.from_user:
            actor_name = f"{call.from_user.first_name or ''} {call.from_user.last_name or ''}".strip()
            if call.from_user.username:
                actor_name = f"@{call.from_user.username}"

        success, msg = ac.add_user(
            actor_id=chat_id,
            target_id=target_id,
            role=role,
            actor_name=actor_name,
        )

        state.clear_data(chat_id)
        state.set_state(chat_id, S_MENU)

        role_str = ac.get_role(chat_id) or "user"
        try:
            bot.edit_message_text(msg, chat_id, call.message.message_id, parse_mode="Markdown")
        except Exception:
            bot.send_message(chat_id, msg, parse_mode="Markdown", reply_markup=_menu(chat_id))

    @bot.callback_query_handler(func=lambda call: call.data.startswith("um_list:"))
    def handle_um_list_users(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        parts = call.data.split(":")
        role_filter = parts[1] if len(parts) > 1 else "all"
        page = int(parts[2]) if len(parts) > 2 else 1

        actual_filter = role_filter if role_filter in ("admin", "user") else None
        users, total_count, total_pages = ac.list_users(role_filter=actual_filter, page=page, page_size=4)

        title = "المسؤولين (ADMIN)" if role_filter == "admin" else ("الأعضاء (USER)" if role_filter == "user" else "جميع الحسابات")

        if not users:
            text = f"📋 **قائمة {title}**\n\nℹ️ لا توجد أي حسابات مسجلة في هذا القسم حاليًا."
            kb = types.InlineKeyboardMarkup().add(types.InlineKeyboardButton("🔙 لوحة الإدارة", callback_data="um_back"))
        else:
            cards = [format_user_card(u) for u in users]
            separator = "\n" + ("━" * 25) + "\n"
            text = (
                f"📋 **قائمة {title}** — صفحة `{page}/{total_pages}`\n"
                f"📊 إجمالي الحسابات: `{total_count}`\n\n"
                + separator.join(cards)
            )
            kb = get_users_list_keyboard(
                users=users,
                role_filter=role_filter,
                current_page=page,
                total_pages=total_pages,
                actor_role=ac.get_role(chat_id) or "user",
                owner_id=ac.owner_id,
            )

        try:
            bot.edit_message_text(text, chat_id, call.message.message_id, parse_mode="Markdown", reply_markup=kb)
        except Exception:
            bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("um_del_req:"))
    def handle_um_del_request(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        target_id = int(call.data.split(":")[1])
        if target_id == ac.owner_id:
            bot.answer_callback_query(call.id, "⛔ لا يمكن حذف مالك البوت إطلاقًا.", show_alert=True)
            return

        target_user = ac.get_user(target_id)
        if not target_user:
            bot.answer_callback_query(call.id, "❌ المستخدم غير موجود في قاعدة البيانات.", show_alert=True)
            return

        if not ac.is_owner(chat_id) and target_user.role in ("admin", "owner"):
            bot.answer_callback_query(call.id, "⛔ المشرف لا يملك صلاحية حذف المشرفين أو المالك.", show_alert=True)
            return

        name = f"{target_user.first_name or ''} {target_user.last_name or ''}".strip() or "غير متاح"
        role_label = target_user.role.upper()

        text = (
            f"⚠️ **تأكيد سحب الصلاحيات والحذف**\n\n"
            f"هل أنت متأكد من رغبتك في حذف الحساب التالي وسحب كافة صلاحياته من البوت؟\n\n"
            f"🆔 **معرّف Telegram:** `{target_id}`\n"
            f"👤 **الاسم:** {name}\n"
            f"🎭 **الدور:** `{role_label}`"
        )
        try:
            bot.edit_message_text(
                text,
                chat_id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=get_delete_confirm_keyboard(target_id),
            )
        except Exception:
            bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=get_delete_confirm_keyboard(target_id))

    @bot.callback_query_handler(func=lambda call: call.data.startswith("um_del_confirm:"))
    def handle_um_del_confirm(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        target_id = int(call.data.split(":")[1])
        success, msg = ac.delete_user(actor_id=chat_id, target_id=target_id)
        if success:
            state.disconnect(target_id)

        try:
            bot.answer_callback_query(call.id, msg)
        except Exception:
            pass

        kb = types.InlineKeyboardMarkup().add(types.InlineKeyboardButton("🔙 لوحة الإدارة", callback_data="um_back"))
        try:
            bot.edit_message_text(msg, chat_id, call.message.message_id, parse_mode="Markdown", reply_markup=kb)
        except Exception:
            bot.send_message(chat_id, msg, parse_mode="Markdown", reply_markup=kb)

    @bot.callback_query_handler(func=lambda call: call.data == "um_search_start")
    def handle_um_search_start(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        state.set_state(chat_id, S_ADMIN_SEARCH)
        cancel_kb = types.InlineKeyboardMarkup().add(types.InlineKeyboardButton("🔴 إلغاء", callback_data="um_cancel"))
        try:
            bot.edit_message_text(
                "🔍 **البحث عن حساب**\n\n"
                "أرسل **Telegram ID** أو **اسم المستخدم (Username)** أو **الاسم** للبحث عنه:",
                chat_id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=cancel_kb,
            )
        except Exception:
            bot.send_message(chat_id, "🔍 أرسل معرّف أو اسم المستخدم للبحث:", reply_markup=cancel_kb)

    @bot.message_handler(func=lambda m: state.get_state(m.chat.id) == S_ADMIN_SEARCH and not _is_nav_input(m))
    def handle_receive_search_query(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not ac.is_admin_or_owner(chat_id):
            return

        query = (message.text or "").strip()
        state.set_state(chat_id, S_MENU)

        users, total_count, total_pages = ac.search_users(query=query, page=1, page_size=4)
        if not users:
            kb = types.InlineKeyboardMarkup().add(
                types.InlineKeyboardButton("🔍 بحث آخر", callback_data="um_search_start"),
                types.InlineKeyboardButton("🔙 لوحة الإدارة", callback_data="um_back"),
            )
            bot.send_message(
                chat_id,
                f"❌ **لم يتم العثور على أي نتائج مطابقة لـ:** `{query}`",
                parse_mode="Markdown",
                reply_markup=kb,
            )
            return

        cards = [format_user_card(u) for u in users]
        separator = "\n" + ("━" * 25) + "\n"
        text = (
            f"🔍 **نتائج البحث عن:** `{query}` — صفحة `1/{total_pages}`\n"
            f"📊 إجمالي النتائج: `{total_count}`\n\n"
            + separator.join(cards)
        )
        kb = get_search_list_keyboard(
            users=users,
            query=query,
            current_page=1,
            total_pages=total_pages,
            actor_role=ac.get_role(chat_id) or "user",
            owner_id=ac.owner_id,
        )
        bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("um_spage:"))
    def handle_um_search_page(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call, required_role="admin"):
            return

        parts = call.data.split(":")
        query = parts[1]
        page = int(parts[2]) if len(parts) > 2 else 1

        users, total_count, total_pages = ac.search_users(query=query, page=page, page_size=4)
        cards = [format_user_card(u) for u in users]
        separator = "\n" + ("━" * 25) + "\n"
        text = (
            f"🔍 **نتائج البحث عن:** `{query}` — صفحة `{page}/{total_pages}`\n"
            f"📊 إجمالي النتائج: `{total_count}`\n\n"
            + separator.join(cards)
        )
        kb = get_search_list_keyboard(
            users=users,
            query=query,
            current_page=page,
            total_pages=total_pages,
            actor_role=ac.get_role(chat_id) or "user",
            owner_id=ac.owner_id,
        )
        try:
            bot.edit_message_text(text, chat_id, call.message.message_id, parse_mode="Markdown", reply_markup=kb)
        except Exception:
            bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 💬 Facebook Conversations & Inbox Inspection
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    @bot.message_handler(commands=["convs", "conversations", "scan_convs"])
    def handle_convs_start(message: types.Message) -> None:
        chat_id = message.chat.id
        if not _check_auth(message):
            return
        if not state.has_user(chat_id):
            bot.reply_to(
                message,
                "❌ **LOGIN FIRST!**\nيرجى تسجيل الدخول أولاً بحساب فيسبوك لإجراء فحص المحادثات.",
                parse_mode="Markdown",
            )
            return
        if state.is_task_running(chat_id):
            bot.reply_to(message, "⚠️ **هناك عملية قيد التشغيل بالفعل!** يرجى الانتظار أو الإيقاف أولاً.")
            return

        user = state.get_user(chat_id)
        if not user or not user.get("token"):
            bot.reply_to(message, "❌ **LOGIN FIRST!**")
            return

        msg = bot.send_message(chat_id, "📡 **جاري جلب صفحات فيسبوك الخاصة بالحساب...**", parse_mode="Markdown")

        async def fetch_conv_pages():
            try:
                pages = await client.get_pages(user["token"])
                if not pages:
                    bot.edit_message_text("❌ لم يتم العثور على أي صفحات في هذا الحساب.", chat_id, msg.message_id)
                    return
                pages_data = [{"id": p.id, "name": p.name, "token": p.token} for p in pages]
                all_ids = [p["id"] for p in pages_data]
                state.set_data(chat_id, "conv_all_pages", pages_data)
                state.set_data(chat_id, "conv_selected_pages", all_ids)
                bot.edit_message_text(
                    "💎 **اختر الصفحات المطلوب فحص محادثاتها:**",
                    chat_id,
                    msg.message_id,
                    parse_mode="Markdown",
                    reply_markup=get_conv_pages_keyboard(pages_data, all_ids),
                )
            except Exception as exc:
                log_safe_error("fetch_conv_pages", exc, chat_id)
                bot.edit_message_text("⚠️ **فشل جلب الصفحات من فيسبوك.** تأكد من صلاحية التوكن.", chat_id, msg.message_id)

        engine.run_async(fetch_conv_pages(), chat_id)

    @bot.callback_query_handler(
        func=lambda call: call.data.startswith("cpg:") or call.data in ["cpg_toggle_all", "cpg_done", "cpg_cancel"]
    )
    def handle_conv_pages_toggle(call: types.CallbackQuery) -> None:
        chat_id = call.message.chat.id
        if not _check_cb_auth(call):
            return

        data = state.get_data(chat_id)
        all_p = data.get("conv_all_pages", [])
        sel: List[str] = list(data.get("conv_selected_pages", []))

        if call.data == "cpg_cancel":
            try:
                bot.delete_message(chat_id, call.message.message_id)
            except Exception:
                pass
            state.clear_data(chat_id)
            bot.send_message(chat_id, "🚫 **تم إلغاء فحص المحادثات.**", parse_mode="Markdown", reply_markup=_menu(chat_id))
            return

        elif call.data == "cpg_toggle_all":
            new_sel = [] if len(sel) == len(all_p) else [p["id"] for p in all_p]
            state.set_data(chat_id, "conv_selected_pages", new_sel)
            sel = new_sel

        elif call.data.startswith("cpg:"):
            pid = call.data.split(":")[1]
            if pid in sel:
                sel.remove(pid)
            else:
                sel.append(pid)
            state.set_data(chat_id, "conv_selected_pages", sel)

        elif call.data == "cpg_done":
            if not sel:
                try:
                    bot.answer_callback_query(call.id, "⚠️ اختر صفحة واحدة على الأقل!", show_alert=True)
                except Exception:
                    pass
                return

            user = state.get_user(chat_id)
            if not user or not user.get("token"):
                try:
                    bot.answer_callback_query(call.id, "❌ انتهت الجلسة. سجل دخول مجدداً.")
                except Exception:
                    pass
                return

            if not state.acquire_task_lock(chat_id):
                try:
                    bot.answer_callback_query(call.id, "⚠️ هناك عملية قيد التشغيل بالفعل!", show_alert=True)
                except Exception:
                    pass
                return

            try:
                bot.answer_callback_query(call.id, "🚀 بدء فحص المحادثات...")
            except Exception:
                pass

            initial_text = f"⏳ **جاري فحص محادثات `{len(sel)}` صفحة...**\nيرجى الانتظار، سيتم إرسال التقرير فور الانتهاء."
            try:
                bot.edit_message_text(initial_text, chat_id, call.message.message_id, parse_mode="Markdown")
            except Exception:
                bot.send_message(chat_id, initial_text, parse_mode="Markdown")

            async def execute_conv_scan():
                try:
                    from test import scan_pages_conversations
                    results = await scan_pages_conversations(
                        fb_user_token=user["token"],
                        selected_page_ids=sel,
                        tg_bot_token=None,
                        tg_chat_id=None,
                    )

                    total_scanned = sum(r.get("total_scanned", 0) for r in results)
                    total_open = sum(r.get("open_convs", 0) for r in results)

                    rep_lines = [
                        "📊 **تقرير فحص محادثات صفحات فيسبوك**",
                        "━" * 25,
                        f"📄 الصفحات المفحوصة: `{len(results)}`",
                        f"💬 إجمالي المحادثات: `{total_scanned}`",
                        f"📬 المحادثات المفتوحة: `{total_open}`",
                        "━" * 25,
                        "",
                    ]
                    for r in results:
                        p_name = r.get("name", "<Unnamed>")
                        st = r.get("status", "ok")
                        sc = r.get("total_scanned", 0)
                        op = r.get("open_convs", 0)
                        icon = "✅" if st == "ok" else ("⚠️" if st == "partial" else "❌")
                        rep_lines.append(f"{icon} **{p_name}**")
                        rep_lines.append(f"   • مفتوحة: `{op}` | مفحوصة: `{sc}` [{st}]\n")

                    bot.send_message(chat_id, "\n".join(rep_lines), parse_mode="Markdown", reply_markup=_menu(chat_id))
                except Exception as exc:
                    log_safe_error("execute_conv_scan", exc, chat_id)
                    bot.send_message(chat_id, f"⚠️ **فشل فحص المحادثات:** {str(exc)[:150]}", reply_markup=_menu(chat_id))
                finally:
                    state.clear_data(chat_id)
                    state.release_task_lock(chat_id)

            engine.run_async(execute_conv_scan(), chat_id)
            return

        try:
            bot.edit_message_reply_markup(
                chat_id,
                call.message.message_id,
                reply_markup=get_conv_pages_keyboard(all_p, sel),
            )
        except Exception:
            pass




"""
Telegram keyboards and UI markup components.
Preserves exact original labels, emojis, and callback formats.
"""

from typing import Any, Dict, List
from telebot import types
from config import SPEED_OPTIONS


def get_main_menu(role: str = "user") -> types.ReplyKeyboardMarkup:
    """Returns the persistent main menu reply keyboard with professional layout."""
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row("🔗 CONNECT GROUPS", "🛡️ APPROVE MEMBERS")
    markup.row("👑 MODERATOR APPROVAL", "🔎 FF CHECKER")
    markup.row("📊 SYSTEM STATUS", "⏹️ STOP TASK")
    if role in ("owner", "admin"):
        markup.row("👥 إدارة المستخدمين", "🔌 DISCONNECT")
    else:
        markup.row("🔌 DISCONNECT")
    return markup


def get_ff_scope_buttons() -> types.InlineKeyboardMarkup:
    """Returns inline buttons for FF Checker previous check scope."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("✅ تخطَّ المفحوص سابقًا", callback_data="ff_scope:skip_checked"),
        types.InlineKeyboardButton("🔄 فحص كامل القائمة", callback_data="ff_scope:check_all"),
        types.InlineKeyboardButton("🛑 إلغاء", callback_data="ff_cancel"),
    )
    return markup


def get_speed_buttons(speeds: List[int] | None = None) -> types.InlineKeyboardMarkup:
    """Returns inline buttons for speed / concurrency selection."""
    markup = types.InlineKeyboardMarkup(row_width=4)
    options = speeds or SPEED_OPTIONS
    btns = [types.InlineKeyboardButton(f"⚡ {s}", callback_data=f"spd:{s}") for s in options]
    markup.add(*btns)
    return markup


def get_pages_list(all_pages: List[Dict[str, Any]], selected_ids: List[str]) -> types.InlineKeyboardMarkup:
    """Returns the interactive page selection inline keyboard."""
    markup = types.InlineKeyboardMarkup()
    btn_all = "✅ DESELECT ALL" if len(selected_ids) == len(all_pages) and len(all_pages) > 0 else "🔲 SELECT ALL"
    markup.add(types.InlineKeyboardButton(btn_all, callback_data="toggle_all"))
    for p in all_pages:
        icon = "☑️" if p["id"] in selected_ids else "⬜"
        markup.add(types.InlineKeyboardButton(f"{icon} {p['name']}", callback_data=f"pg:{p['id']}"))
    markup.add(types.InlineKeyboardButton(f"CONTINUE ({len(selected_ids)}) ⬅️", callback_data="done_select"))
    return markup


def get_conv_pages_keyboard(all_pages: List[Dict[str, Any]], selected_ids: List[str]) -> types.InlineKeyboardMarkup:
    """Returns interactive page selection inline keyboard for Facebook conversation scanning."""
    markup = types.InlineKeyboardMarkup()
    btn_all = "✅ إلغاء تحديد الكل" if len(selected_ids) == len(all_pages) and len(all_pages) > 0 else "🔲 تحديد كل الصفحات"
    markup.add(types.InlineKeyboardButton(btn_all, callback_data="cpg_toggle_all"))
    for p in all_pages:
        icon = "☑️" if p["id"] in selected_ids else "⬜"
        markup.add(types.InlineKeyboardButton(f"{icon} {p['name']}", callback_data=f"cpg:{p['id']}"))
    markup.add(types.InlineKeyboardButton(f"🚀 بدء فحص المحادثات ({len(selected_ids)})", callback_data="cpg_done"))
    markup.add(types.InlineKeyboardButton("🔴 إلغاء", callback_data="cpg_cancel"))
    return markup



def get_confirm_buttons(speed: int) -> types.InlineKeyboardMarkup:
    """Returns confirmation inline buttons before task launch."""
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🟢 CONFIRM & INITIALIZE", callback_data=f"confirm:{speed}"))
    markup.add(types.InlineKeyboardButton("🔴 ABORT MISSION", callback_data="cancel_run"))
    return markup


def get_source_buttons() -> types.InlineKeyboardMarkup:
    """Returns the uplink source selection inline keyboard."""
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("👤 MAIN PROFILE", callback_data="src_me"))
    markup.add(types.InlineKeyboardButton("📄 FAN PAGES", callback_data="src_pages"))
    return markup


def get_user_mgmt_menu(is_owner: bool = False) -> types.InlineKeyboardMarkup:
    """Returns user management menu inline buttons."""
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("➕ إضافة مستخدم", callback_data="um_add_start"),
        types.InlineKeyboardButton("🔍 بحث عن حساب", callback_data="um_search_start"),
    )
    markup.add(
        types.InlineKeyboardButton("👥 قائمة الأعضاء (USER)", callback_data="um_list:user:1"),
        types.InlineKeyboardButton("🛡️ قائمة المسؤولين (ADMIN)", callback_data="um_list:admin:1"),
    )
    markup.add(
        types.InlineKeyboardButton("📋 عرض جميع الحسابات", callback_data="um_list:all:1"),
        types.InlineKeyboardButton("❌ إغلاق", callback_data="um_close"),
    )
    return markup


def get_add_role_keyboard() -> types.InlineKeyboardMarkup:
    """Returns role selection inline keyboard for Owner."""
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("👤 عضو (USER)", callback_data="um_set_role:user"),
        types.InlineKeyboardButton("🛡️ مشرف (ADMIN)", callback_data="um_set_role:admin"),
    )
    markup.add(types.InlineKeyboardButton("🔴 إلغاء", callback_data="um_cancel"))
    return markup


def get_add_confirm_keyboard() -> types.InlineKeyboardMarkup:
    """Returns confirmation buttons for adding a user."""
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("✅ تأكيد الإضافة", callback_data="um_add_confirm"),
        types.InlineKeyboardButton("🔴 إلغاء", callback_data="um_cancel"),
    )
    return markup


def get_delete_confirm_keyboard(target_id: int) -> types.InlineKeyboardMarkup:
    """Returns confirmation buttons for deleting a user."""
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🔴 نعم، تأكيد الحذف", callback_data=f"um_del_confirm:{target_id}"),
        types.InlineKeyboardButton("❌ إلغاء", callback_data="um_cancel"),
    )
    return markup


def get_users_list_keyboard(
    users: List[Any],
    role_filter: str,
    current_page: int,
    total_pages: int,
    actor_role: str,
    owner_id: int,
) -> types.InlineKeyboardMarkup:
    """Returns interactive keyboard for paginated user listing."""
    markup = types.InlineKeyboardMarkup()
    for u in users:
        target_id = getattr(u, "telegram_id", None) or (u.get("telegram_id") if isinstance(u, dict) else None)
        target_role = getattr(u, "role", None) or (u.get("role", "user") if isinstance(u, dict) else "user")
        if not target_id:
            continue
        can_delete = False
        if target_id != owner_id:
            if actor_role == "owner":
                can_delete = True
            elif actor_role == "admin" and target_role == "user":
                can_delete = True
        if can_delete:
            markup.add(types.InlineKeyboardButton(f"🗑️ حذف ({target_id})", callback_data=f"um_del_req:{target_id}"))

    nav_row = []
    if current_page > 1:
        nav_row.append(types.InlineKeyboardButton("◀️ السابق", callback_data=f"um_list:{role_filter}:{current_page - 1}"))
    nav_row.append(types.InlineKeyboardButton(f"📄 {current_page}/{total_pages}", callback_data="um_noop"))
    if current_page < total_pages:
        nav_row.append(types.InlineKeyboardButton("التالي ▶️", callback_data=f"um_list:{role_filter}:{current_page + 1}"))
    if nav_row:
        markup.row(*nav_row)

    markup.add(types.InlineKeyboardButton("🔙 لوحة الإدارة", callback_data="um_back"))
    return markup


def get_search_list_keyboard(
    users: List[Any],
    query: str,
    current_page: int,
    total_pages: int,
    actor_role: str,
    owner_id: int,
) -> types.InlineKeyboardMarkup:
    """Returns interactive keyboard for paginated search results."""
    markup = types.InlineKeyboardMarkup()
    for u in users:
        target_id = getattr(u, "telegram_id", None) or (u.get("telegram_id") if isinstance(u, dict) else None)
        target_role = getattr(u, "role", None) or (u.get("role", "user") if isinstance(u, dict) else "user")
        if not target_id:
            continue
        can_delete = False
        if target_id != owner_id:
            if actor_role == "owner":
                can_delete = True
            elif actor_role == "admin" and target_role == "user":
                can_delete = True
        if can_delete:
            markup.add(types.InlineKeyboardButton(f"🗑️ حذف ({target_id})", callback_data=f"um_del_req:{target_id}"))

    nav_row = []
    if current_page > 1:
        nav_row.append(types.InlineKeyboardButton("◀️ السابق", callback_data=f"um_spage:{query}:{current_page - 1}"))
    nav_row.append(types.InlineKeyboardButton(f"📄 {current_page}/{total_pages}", callback_data="um_noop"))
    if current_page < total_pages:
        nav_row.append(types.InlineKeyboardButton("التالي ▶️", callback_data=f"um_spage:{query}:{current_page + 1}"))
    if nav_row:
        markup.row(*nav_row)

    markup.add(types.InlineKeyboardButton("🔙 لوحة الإدارة", callback_data="um_back"))
    return markup


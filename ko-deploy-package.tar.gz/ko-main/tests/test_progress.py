"""
Tests for progress bar computation and final report rendering.
"""

import time
import unittest
from workers.progress import make_final_report, make_premium_progress


class TestProgress(unittest.TestCase):
    def test_progress_zero_total(self):
        """Verifies handling when total operations is zero."""
        result = make_premium_progress(0, 0, time.time(), {"ok": 0, "bad": 0, "retried": 0})
        self.assertEqual(result, "---")

    def test_progress_rendering_components(self):
        """Verifies ASCII progress rendering contains required metrics."""
        start_time = time.time() - 10.0
        stats = {"ok": 20, "bad": 5, "retried": 2}
        result = make_premium_progress(current=25, total=50, start_time=start_time, stats=stats)

        self.assertIn("SYSTEM STATUS: EXECUTING...", result)
        self.assertIn("50%", result)
        self.assertIn("THROUGHPUT:", result)
        self.assertIn("ELAPSED:", result)
        self.assertIn("ETA:", result)
        self.assertIn("PACKETS:** `25/50`", result)
        self.assertIn("✅ `20`", result)
        self.assertIn("❌ `5`", result)
        self.assertIn("🔄 `2`", result)
        self.assertIn("RAM:", result)
        self.assertIn("vCPU", result)

    def test_final_report_rendering(self):
        """Verifies final report formatting."""
        stats = {"done": 100, "ok": 90, "bad": 10, "retried": 3}
        result = make_final_report(stats=stats, elapsed=15, num_clients=4)

        self.assertIn("MISSION ACCOMPLISHED", result)
        self.assertIn("PROCESSED: `100`", result)
        self.assertIn("SUCCESS: `90`", result)
        self.assertIn("FAILED: `10`", result)
        self.assertIn("RETRIED: `3`", result)
        self.assertIn("TIME: `15s`", result)
        self.assertIn("AVG SPEED:", result)
        self.assertIn("ENGINE:", result)
        self.assertIn("CLIENTS: `4`", result)


if __name__ == "__main__":
    unittest.main()

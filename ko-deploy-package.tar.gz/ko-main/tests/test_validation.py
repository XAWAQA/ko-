"""
Tests for input validation and sanitization.
"""

import unittest
from utils.validation import is_valid_token, parse_id_list


class TestValidation(unittest.TestCase):
    def test_parse_id_list_valid(self):
        """Verifies clean extraction of ID lists."""
        content = "1000123456\n1000789012\n  1000345678  \n"
        result = parse_id_list(content)
        self.assertEqual(result, ["1000123456", "1000789012", "1000345678"])

    def test_parse_id_list_with_empty_and_duplicate_lines(self):
        """Verifies deduplication and blank line omission."""
        content = "123\n\n  \n123\n456\n"
        result = parse_id_list(content)
        self.assertEqual(result, ["123", "456"])

    def test_parse_id_list_ignores_menu_buttons(self):
        """Verifies menu buttons clicked as text are ignored."""
        content = "⚡ CONNECT GROUPS\n12345\n🚫 TERMINATE\n67890"
        result = parse_id_list(content)
        self.assertEqual(result, ["12345", "67890"])

    def test_is_valid_token(self):
        """Verifies access token format checking."""
        self.assertFalse(is_valid_token(""))
        self.assertFalse(is_valid_token("short"))
        self.assertFalse(is_valid_token("token with space 123456"))
        self.assertTrue(is_valid_token("EAABsbCS1234567890abcdefghijklmnopqrstuvwxyz"))


if __name__ == "__main__":
    unittest.main()

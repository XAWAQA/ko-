"""
Tests for FacebookClient without contacting real Facebook servers.
All network interactions are strictly mocked.
"""

import json
import unittest
from unittest.mock import AsyncMock, MagicMock
import httpx

from facebook.client import FacebookClient
from facebook.models import OperationStatus


class TestFacebookClient(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        self.mock_http = MagicMock(spec=httpx.AsyncClient)

    def _create_mock_response(self, status_code: int, text: str):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = status_code
        resp.text = text
        try:
            resp.json.return_value = json.loads(text)
        except Exception:
            resp.json.side_effect = json.JSONDecodeError("Invalid JSON", text, 0)
        return resp

    async def test_successful_api_response(self):
        """Verifies parsing of standard successful GraphQL response."""
        resp_data = {"data": {"group_join": {"status": "SUCCESS"}}}
        self.mock_http.post = AsyncMock(return_value=self._create_mock_response(200, json.dumps(resp_data)))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={"input": {}},
            token="tok_abc",
            op_type="join",
        )
        self.assertTrue(result.success)
        self.assertEqual(result.status, OperationStatus.SUCCESS)
        self.assertFalse(result.is_retryable)

    async def test_legacy_already_member_treated_as_success(self):
        """Verifies code 1341004 / already a member is parsed as success (legacy compatibility)."""
        resp_data = {"errors": [{"message": "User is already a member", "code": 1341004}]}
        self.mock_http.post = AsyncMock(return_value=self._create_mock_response(200, json.dumps(resp_data)))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={"input": {}},
            token="tok_abc",
            op_type="join",
        )
        self.assertTrue(result.success)
        self.assertEqual(result.status, OperationStatus.SUCCESS)

    async def test_failed_api_response(self):
        """Verifies non-retryable GraphQL business failure."""
        resp_data = {"errors": [{"message": "Group not found or deleted", "code": 100}]}
        self.mock_http.post = AsyncMock(return_value=self._create_mock_response(200, json.dumps(resp_data)))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={"input": {}},
            token="tok_abc",
            op_type="join",
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.CLIENT_ERROR)
        self.assertFalse(result.is_retryable)

    async def test_http_429_rate_limit(self):
        """Verifies HTTP 429 is classified as retryable rate limit."""
        self.mock_http.post = AsyncMock(return_value=self._create_mock_response(429, "Too Many Requests"))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={},
            token="tok_abc",
            op_type="join",
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.RATE_LIMIT)
        self.assertTrue(result.is_retryable)
        self.assertEqual(result.status_code, 429)

    async def test_http_500_server_error(self):
        """Verifies HTTP 5xx is classified as retryable server error."""
        self.mock_http.post = AsyncMock(return_value=self._create_mock_response(500, "Internal Server Error"))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={},
            token="tok_abc",
            op_type="join",
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.SERVER_ERROR)
        self.assertTrue(result.is_retryable)
        self.assertEqual(result.status_code, 500)

    async def test_http_401_403_auth_error(self):
        """Verifies HTTP 401/403 are classified as permanent non-retryable auth error."""
        for status_code in (401, 403):
            self.mock_http.post = AsyncMock(return_value=self._create_mock_response(status_code, "Forbidden"))

            result = await self.client.execute_graphql_request(
                client=self.mock_http,
                doc_id="123",
                variables={},
                token="tok_abc",
                op_type="join",
            )
            self.assertFalse(result.success)
            self.assertEqual(result.status, OperationStatus.AUTH_ERROR)
            self.assertFalse(result.is_retryable)

    async def test_timeout_handling(self):
        """Verifies httpx.TimeoutException produces retryable TIMEOUT result."""
        self.mock_http.post = AsyncMock(side_effect=httpx.TimeoutException("Connection timed out"))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={},
            token="tok_abc",
            op_type="join",
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.TIMEOUT)
        self.assertTrue(result.is_retryable)

    async def test_malformed_api_response(self):
        """Verifies malformed (non-JSON) response is safely handled via fallback."""
        raw_non_json = "<html><body>502 Bad Gateway</body></html>"
        self.mock_http.post = AsyncMock(return_value=self._create_mock_response(200, raw_non_json))

        result = await self.client.execute_graphql_request(
            client=self.mock_http,
            doc_id="123",
            variables={},
            token="tok_abc",
            op_type="join",
        )
        self.assertFalse(result.success)


if __name__ == "__main__":
    unittest.main()

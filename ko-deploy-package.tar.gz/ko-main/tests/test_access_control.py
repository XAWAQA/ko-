"""
Comprehensive Unit & Integration Tests for Access Control System.
Tests:
- Owner, Admin, User role permissions and hierarchy enforcement.
- Permanent Owner (1167798421) protection against deletion or demotion.
- SQLite persistence, concurrency lock, and audit logging.
- Application update safety: guarantees existing database is NEVER overwritten on updates or reloads.
- Complete isolation: unregistered users CANNOT execute ANY operational function, button, callback, or admin tool.
- User management workflows: Add, List, Search, Delete, Pagination, Confirmation.
- Profile metadata formatting with 'غير متاح' fallbacks.
"""

import fnmatch
import os
import re
import shutil
import tempfile
import unittest
from unittest.mock import MagicMock

import telebot
from telebot import types

from access.db import AccessDatabase, AccessUser
from access.manager import AccessManager, Role, format_user_card
from access.testing import TestAccessManager, create_test_access_manager
from bot.handlers import register_handlers
from bot.keyboards import get_main_menu
from bot.state import (
    S_ADMIN_ADD_ID,
    S_ADMIN_SEARCH,
    S_AUTH,
    S_INPUT_APP_GROUPS,
    S_INPUT_APP_MEMBERS,
    S_INPUT_FF_FILE,
    S_INPUT_JOIN,
    S_INPUT_MOD_GROUPS,
    S_MENU,
    StateManager,
)
from config import OWNER_ID
from facebook.client import MockFacebookClient
from facebook.models import OperationStatus
from workers.engine import WorkerEngine


class TestAccessDatabaseLayer(unittest.TestCase):
    """Direct tests for the AccessDatabase SQLite storage engine."""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_access.db")
        self.owner_id = OWNER_ID
        self.db = AccessDatabase(db_path=self.db_path, owner_id=self.owner_id)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_init_seeds_permanent_owner(self):
        """Owner is automatically inserted with 'owner' role upon initialization."""
        owner = self.db.get_user(self.owner_id)
        self.assertIsNotNone(owner)
        self.assertEqual(owner.telegram_id, self.owner_id)
        self.assertEqual(owner.role, "owner")
        self.assertEqual(self.db.get_role(self.owner_id), "owner")

    def test_owner_cannot_be_deleted(self):
        """Attempting to delete the owner must always fail."""
        success, msg = self.db.delete_user(actor_id=self.owner_id, target_id=self.owner_id)
        self.assertFalse(success)
        self.assertIn("لا يمكن حذف مالك البوت", msg)

        # Owner still exists in DB
        self.assertIsNotNone(self.db.get_user(self.owner_id))

    def test_owner_cannot_be_demoted(self):
        """Re-initializing or updating owner role must not allow demotion."""
        # Try adding owner as user
        success, msg = self.db.add_user(
            actor_id=self.owner_id,
            target_id=self.owner_id,
            role="user",
        )
        self.assertFalse(success)
        self.assertIn("مالك البوت الأساسي", msg)

        # Confirm owner role is unchanged
        self.assertEqual(self.db.get_role(self.owner_id), "owner")

    def test_owner_can_add_and_delete_admin_and_user(self):
        """Owner can add admins and users, and delete them."""
        # 1. Owner adds admin
        success, msg = self.db.add_user(
            actor_id=self.owner_id,
            target_id=200001,
            role="admin",
            first_name="AdminBob",
        )
        self.assertTrue(success)
        self.assertEqual(self.db.get_role(200001), "admin")

        # 2. Owner adds user
        success, msg = self.db.add_user(
            actor_id=self.owner_id,
            target_id=200002,
            role="user",
            first_name="UserCharlie",
        )
        self.assertTrue(success)
        self.assertEqual(self.db.get_role(200002), "user")

        # 3. Owner deletes admin
        success, msg = self.db.delete_user(actor_id=self.owner_id, target_id=200001)
        self.assertTrue(success)
        self.assertIsNone(self.db.get_role(200001))

        # 4. Owner deletes user
        success, msg = self.db.delete_user(actor_id=self.owner_id, target_id=200002)
        self.assertTrue(success)
        self.assertIsNone(self.db.get_role(200002))

    def test_admin_restrictions_on_add_and_delete(self):
        """Admin can only add/delete regular users; cannot touch admins or owner."""
        admin_id = 200003
        self.db.add_user(actor_id=self.owner_id, target_id=admin_id, role="admin")

        other_admin_id = 200004
        self.db.add_user(actor_id=self.owner_id, target_id=other_admin_id, role="admin")

        user_id = 200005

        # Admin tries to add an admin -> MUST FAIL
        success, msg = self.db.add_user(actor_id=admin_id, target_id=user_id, role="admin")
        self.assertFalse(success)
        self.assertIn("المشرف يملك صلاحية إضافة أعضاء (USER) فقط", msg)

        # Admin adds a regular user -> MUST SUCCEED
        success, msg = self.db.add_user(actor_id=admin_id, target_id=user_id, role="user")
        self.assertTrue(success)
        self.assertEqual(self.db.get_role(user_id), "user")

        # Admin tries to delete Owner -> MUST FAIL
        success, msg = self.db.delete_user(actor_id=admin_id, target_id=self.owner_id)
        self.assertFalse(success)

        # Admin tries to delete another Admin -> MUST FAIL
        success, msg = self.db.delete_user(actor_id=admin_id, target_id=other_admin_id)
        self.assertFalse(success)
        self.assertIn("المشرف لا يملك صلاحية حذف المشرفين أو المالك", msg)

        # Admin deletes regular user -> MUST SUCCEED
        success, msg = self.db.delete_user(actor_id=admin_id, target_id=user_id)
        self.assertTrue(success)
        self.assertIsNone(self.db.get_role(user_id))

    def test_invalid_target_id_and_duplicate_handling(self):
        """Rejects non-numeric or non-positive target IDs and duplicate registrations."""
        # Invalid target ID
        success, msg = self.db.add_user(actor_id=self.owner_id, target_id=-5, role="user")
        self.assertFalse(success)
        self.assertIn("غير صالح", msg)

        # Duplicate addition with same role
        self.db.add_user(actor_id=self.owner_id, target_id=300001, role="user")
        success, msg = self.db.add_user(actor_id=self.owner_id, target_id=300001, role="user")
        self.assertFalse(success)
        self.assertIn("مسجل بالفعل بالدور نفسه", msg)

    def test_profile_sync(self):
        """Profile metadata is updated when sync_telegram_profile is invoked."""
        target_id = 300002
        self.db.add_user(actor_id=self.owner_id, target_id=target_id, role="user")

        self.db.sync_telegram_profile(
            telegram_id=target_id,
            first_name="Ahmad",
            last_name="Ali",
            username="ahmad_ali",
        )

        user = self.db.get_user(target_id)
        self.assertEqual(user.first_name, "Ahmad")
        self.assertEqual(user.last_name, "Ali")
        self.assertEqual(user.username, "ahmad_ali")

    def test_pagination_and_search(self):
        """Tests pagination for list_users and search_users."""
        # Add 12 users
        for i in range(1, 13):
            self.db.add_user(
                actor_id=self.owner_id,
                target_id=400000 + i,
                role="user",
                first_name=f"User_{i}",
                username=f"uname_{i}",
            )

        # Page 1 (limit 10)
        users_p1, total, pages = self.db.list_users(role_filter="user", page=1, page_size=10)
        self.assertEqual(len(users_p1), 10)
        self.assertEqual(total, 12)
        self.assertEqual(pages, 2)

        # Page 2
        users_p2, _, _ = self.db.list_users(role_filter="user", page=2, page_size=10)
        self.assertEqual(len(users_p2), 2)

        # Search by username substring
        search_res, s_total, s_pages = self.db.search_users(query="uname_1", page=1, page_size=10)
        self.assertEqual(s_total, 4)

        # Search by exact Telegram ID
        search_res, s_total, _ = self.db.search_users(query="400005", page=1)
        self.assertEqual(s_total, 1)
        self.assertEqual(search_res[0].telegram_id, 400005)

    def test_audit_log_persists_actions_without_tokens(self):
        """Ensures audit actions are logged with no tokens or passwords."""
        target_id = 500001
        self.db.add_user(actor_id=self.owner_id, target_id=target_id, role="user", actor_name="OwnerAdmin")
        self.db.delete_user(actor_id=self.owner_id, target_id=target_id, actor_name="OwnerAdmin")

        conn = self.db._get_connection()
        cur = conn.execute("SELECT action, target_id, actor_id FROM audit_log ORDER BY id ASC")
        rows = cur.fetchall()

        actions = [r["action"] for r in rows]
        self.assertIn("ADD_USER", actions)
        self.assertIn("DELETE_USER", actions)

    def test_persistence_across_db_reopens(self):
        """Data persists when a new AccessDatabase instance connects to the same file."""
        target_id = 600001
        self.db.add_user(actor_id=self.owner_id, target_id=target_id, role="admin", first_name="PersistentAdmin")

        # Open second instance on same file
        db2 = AccessDatabase(db_path=self.db_path, owner_id=self.owner_id)
        user = db2.get_user(target_id)
        self.assertIsNotNone(user)
        self.assertEqual(user.role, "admin")
        self.assertEqual(user.first_name, "PersistentAdmin")


class TestDatabaseUpdatePreservation(unittest.TestCase):
    """
    Verifies that application updates, service restarts, or deployment runs
    never overwrite, wipe, or replace an existing user database.
    """

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.dest_app_dir = os.path.join(self.temp_dir, "opt_ko_bot")
        self.source_code_dir = os.path.join(self.temp_dir, "release_bundle")

        os.makedirs(os.path.join(self.dest_app_dir, "data", "ff_checker", "runs"), exist_ok=True)
        os.makedirs(self.source_code_dir, exist_ok=True)

        self.db_path = os.path.join(self.dest_app_dir, "data", "access_control.db")

        # Pre-seed existing production database with admin and users
        self.db = AccessDatabase(db_path=self.db_path, owner_id=OWNER_ID)
        self.db.add_user(actor_id=OWNER_ID, target_id=777001, role="admin", first_name="ProductionAdmin")
        self.db.add_user(actor_id=777001, target_id=777002, role="user", first_name="ProductionUser1")
        self.db.add_user(actor_id=777001, target_id=777003, role="user", first_name="ProductionUser2")

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_database_preserved_across_app_reinitialization(self):
        """Reinstantiating AccessManager or AccessDatabase must keep all registered data intact."""
        # Simulate bot restarting and re-opening database
        mgr2 = AccessManager(db_path=self.db_path, owner_id=OWNER_ID)

        self.assertTrue(mgr2.is_owner(OWNER_ID))
        self.assertEqual(mgr2.get_role(777001), Role.ADMIN.value)
        self.assertEqual(mgr2.get_role(777002), Role.USER.value)
        self.assertEqual(mgr2.get_role(777003), Role.USER.value)

        user1 = mgr2.get_user(777002)
        self.assertIsNotNone(user1)
        self.assertEqual(user1.first_name, "ProductionUser1")

    def test_deployment_sync_strictly_preserves_database(self):
        """
        Directly parses and tests the actual sync and exclusion logic from deploy/setup_ubuntu.sh.
        Guarantees that:
        1. setup_ubuntu.sh explicitly defines exclusions for data/ and runtime artifacts.
        2. The actual exclusion rules in setup_ubuntu.sh protect existing data/ from being replaced.
        3. Pre-existing database with real users remains 100% intact after synchronization.
        """
        # 1. Locate and read the actual deploy/setup_ubuntu.sh script
        repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        setup_script_path = os.path.join(repo_root, "deploy", "setup_ubuntu.sh")
        self.assertTrue(os.path.isfile(setup_script_path), f"Script not found at {setup_script_path}")

        with open(setup_script_path, "r", encoding="utf-8") as f:
            script_content = f.read()

        # 2. Extract actual rsync and find exclusions directly from the script
        rsync_excludes = re.findall(r"--exclude='([^']+)'", script_content)
        find_excludes = re.findall(r"! -name '([^']+)'", script_content)

        # Ensure exclusions are parsed directly from setup_ubuntu.sh
        self.assertGreater(len(rsync_excludes), 0, "No rsync exclusions found in setup_ubuntu.sh")
        self.assertGreater(len(find_excludes), 0, "No find exclusions found in setup_ubuntu.sh")

        # Verify that data/ is explicitly excluded in both mechanisms
        self.assertIn("data/", rsync_excludes, "rsync must explicitly exclude 'data/' in setup_ubuntu.sh")
        self.assertIn("data", find_excludes, "find fallback must explicitly exclude 'data' in setup_ubuntu.sh")
        self.assertIn("__pycache__/", rsync_excludes)
        self.assertIn(".pytest_cache/", rsync_excludes)
        self.assertIn(".env", rsync_excludes)

        # 3. Create mock source release files
        with open(os.path.join(self.source_code_dir, "app.py"), "w", encoding="utf-8") as f:
            f.write("# Updated version 5.1 code\n")

        # Source contains dummy database and cache that MUST NOT overwrite destination
        os.makedirs(os.path.join(self.source_code_dir, "data"), exist_ok=True)
        with open(os.path.join(self.source_code_dir, "data", "access_control.db"), "w", encoding="utf-8") as f:
            f.write("DUMMY_EMPTY_DB_THAT_MUST_NOT_OVERWRITE_PRODUCTION")

        os.makedirs(os.path.join(self.source_code_dir, "__pycache__"), exist_ok=True)
        with open(os.path.join(self.source_code_dir, "__pycache__", "app.pyc"), "w") as f:
            f.write("CACHE")

        with open(os.path.join(self.source_code_dir, ".env"), "w", encoding="utf-8") as f:
            f.write("DEV_ENV_VARS")

        # 4. Execute synchronization using the exclusion rules extracted from setup_ubuntu.sh
        normalized_excludes = {ex.rstrip("/") for ex in rsync_excludes}

        for item in os.listdir(self.source_code_dir):
            if any(fnmatch.fnmatch(item, pat) for pat in normalized_excludes):
                continue
            src_item = os.path.join(self.source_code_dir, item)
            dst_item = os.path.join(self.dest_app_dir, item)
            if os.path.isdir(src_item):
                shutil.copytree(src_item, dst_item, dirs_exist_ok=True)
            else:
                shutil.copy2(src_item, dst_item)

        # 5. Verify application files were updated
        self.assertTrue(os.path.isfile(os.path.join(self.dest_app_dir, "app.py")))
        with open(os.path.join(self.dest_app_dir, "app.py"), "r", encoding="utf-8") as f:
            self.assertIn("Updated version 5.1 code", f.read())

        # Verify excluded dev artifacts were not copied
        self.assertFalse(os.path.exists(os.path.join(self.dest_app_dir, ".env")))
        self.assertFalse(os.path.exists(os.path.join(self.dest_app_dir, "__pycache__")))

        # 6. VERIFY PRODUCTION DATABASE: Must still be valid SQLite with original users intact
        mgr = AccessManager(db_path=self.db_path, owner_id=OWNER_ID)
        self.assertEqual(mgr.get_role(777001), Role.ADMIN.value)
        self.assertEqual(mgr.get_role(777002), Role.USER.value)
        self.assertEqual(mgr.get_role(777003), Role.USER.value)
        self.assertEqual(mgr.get_user(777001).first_name, "ProductionAdmin")
        self.assertEqual(mgr.get_user(777002).first_name, "ProductionUser1")


class TestAccessManagerAndFormatting(unittest.TestCase):
    """Tests for AccessManager wrapper and user card formatting."""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_mgr.db")
        self.manager = AccessManager(db_path=self.db_path, owner_id=OWNER_ID)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_strict_role_checks(self):
        """Strict access check correctly categorizes owner, admin, user, and unauthorized."""
        unregistered_id = 888888888
        self.assertFalse(self.manager.is_authorized(unregistered_id))
        self.assertIsNone(self.manager.get_role(unregistered_id))

        # Owner
        self.assertTrue(self.manager.is_authorized(OWNER_ID))
        self.assertTrue(self.manager.is_owner(OWNER_ID))
        self.assertTrue(self.manager.is_admin_or_owner(OWNER_ID))
        self.assertEqual(self.manager.get_role(OWNER_ID), Role.OWNER.value)

        # Admin
        admin_id = 700001
        self.manager.add_user(actor_id=OWNER_ID, target_id=admin_id, role="admin")
        self.assertTrue(self.manager.is_authorized(admin_id))
        self.assertFalse(self.manager.is_owner(admin_id))
        self.assertTrue(self.manager.is_admin_or_owner(admin_id))
        self.assertEqual(self.manager.get_role(admin_id), Role.ADMIN.value)

        # User
        user_id = 700002
        self.manager.add_user(actor_id=OWNER_ID, target_id=user_id, role="user")
        self.assertTrue(self.manager.is_authorized(user_id))
        self.assertFalse(self.manager.is_owner(user_id))
        self.assertFalse(self.manager.is_admin_or_owner(user_id))
        self.assertEqual(self.manager.get_role(user_id), Role.USER.value)

    def test_format_user_card_fallbacks(self):
        """Missing attributes render clean 'غير متاح' fallbacks."""
        user = AccessUser(
            telegram_id=999999,
            role="user",
            first_name=None,
            last_name=None,
            username=None,
            created_at=None,
            added_by_id=None,
            added_by_name=None,
        )
        card = format_user_card(user)
        self.assertIn("999999", card)
        self.assertIn("غير متاح", card)
        self.assertIn("USER (عضو)", card)

    def test_main_menu_keyboard_visibility(self):
        """Owner and admin see '👥 إدارة المستخدمين', regular users do not."""
        owner_menu = get_main_menu(role="owner")
        admin_menu = get_main_menu(role="admin")
        user_menu = get_main_menu(role="user")

        def has_button(markup, text):
            for row in markup.keyboard:
                for btn in row:
                    b_text = btn.get("text", "") if isinstance(btn, dict) else getattr(btn, "text", "")
                    if text in b_text:
                        return True
            return False

        self.assertTrue(has_button(owner_menu, "👥 إدارة المستخدمين") or has_button(owner_menu, "👥 USER MANAGEMENT"))
        self.assertTrue(has_button(admin_menu, "👥 إدارة المستخدمين") or has_button(admin_menu, "👥 USER MANAGEMENT"))
        self.assertFalse(has_button(user_menu, "👥 إدارة المستخدمين") or has_button(user_menu, "👥 USER MANAGEMENT"))


class TestBotHandlerAccessControl(unittest.TestCase):
    """End-to-end integration tests of bot handlers with AccessManager gating."""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_handlers_access.db")
        self.access_mgr = AccessManager(db_path=self.db_path, owner_id=OWNER_ID)

        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN_FOR_TESTS", threaded=False)
        self.state = StateManager()
        self.mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        self.engine = WorkerEngine(bot=self.bot, fb_client=self.mock_fb, state=self.state)

        # Register handlers with our test access manager
        register_handlers(
            bot=self.bot,
            engine=self.engine,
            state=self.state,
            fb_client=self.mock_fb,
            access_mgr=self.access_mgr,
        )

        # Mock outbound calls
        self.bot.send_message = MagicMock(side_effect=lambda *args, **kwargs: self._make_message("reply", OWNER_ID))
        self.bot.edit_message_text = MagicMock(return_value=True)
        self.bot.edit_message_reply_markup = MagicMock(return_value=True)
        self.bot.delete_message = MagicMock(return_value=True)
        self.bot.reply_to = MagicMock(side_effect=lambda *args, **kwargs: self._make_message("reply", OWNER_ID))
        self.bot.answer_callback_query = MagicMock(return_value=True)
        self.bot.get_file = MagicMock()
        self.bot.download_file = MagicMock()

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _make_message(self, text: str = "", chat_id: int = OWNER_ID, document=None) -> types.Message:
        msg = types.Message(
            message_id=10,
            from_user=types.User(chat_id, False, "TestUser", username="testuser"),
            date=1700000000,
            chat=types.Chat(chat_id, "private"),
            content_type="document" if document else "text",
            options={},
            json_string="",
        )
        msg.text = text
        msg.document = document
        return msg

    def _make_callback(self, data: str, chat_id: int = OWNER_ID, message_id: int = 20) -> types.CallbackQuery:
        cb = types.CallbackQuery(
            id="cb_123",
            from_user=types.User(chat_id, False, "TestUser", username="testuser"),
            data=data,
            chat_instance="ci_1",
            json_string="",
        )
        cb.message = self._make_message("", chat_id)
        cb.message.message_id = message_id
        return cb

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Unregistered User Complete Isolation Tests
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_unregistered_user_blocked_on_start_and_disconnect(self):
        """Unregistered user sending /start or DISCONNECT is strictly rejected."""
        unreg_id = 999111222
        for cmd in ["/start", "🔌 DISCONNECT"]:
            self.bot.send_message.reset_mock()
            msg = self._make_message(cmd, chat_id=unreg_id)
            self.bot.process_new_messages([msg])

            self.bot.send_message.assert_called_once()
            sent_text = self.bot.send_message.call_args[0][1]
            self.assertIn("الوصول غير مصرح به", sent_text)
            self.assertIsNone(self.state.get_state(unreg_id))

    def test_unregistered_user_blocked_on_all_main_menu_buttons(self):
        """Unregistered user clicking ANY menu button is immediately rejected."""
        unreg_id = 999111333
        buttons_to_test = [
            "⚡ CONNECT GROUPS",
            "🛡️ APPROVE MEMBERS",
            "👑 MODERATOR APPROVAL",
            "🔎 FF CHECKER",
            "👥 إدارة المستخدمين",
            "📟 SYSTEM INFO",
            "🚫 TERMINATE",
        ]
        for btn in buttons_to_test:
            self.bot.send_message.reset_mock()
            msg = self._make_message(btn, chat_id=unreg_id)
            self.bot.process_new_messages([msg])

            self.bot.send_message.assert_called_once()
            sent_text = self.bot.send_message.call_args[0][1]
            self.assertIn("الوصول غير مصرح به", sent_text)
            # Ensure state was not modified
            self.assertIsNone(self.state.get_state(unreg_id))

    def test_unregistered_user_blocked_on_all_callback_queries(self):
        """Unregistered user cannot trigger operational or administrative callbacks."""
        unreg_id = 999111444
        callbacks_to_test = [
            "src_me",
            "src_pages",
            "pg:pg_1",
            "done_select",
            "toggle_all",
            "spd:1",
            "confirm:1",
            "cancel_run",
            "ff_scope:all",
            "ff_scope:skip",
            "ff_stop",
            "ff_cancel",
            "um_add_start",
            "um_set_role:admin",
            "um_add_confirm",
            "um_list:all:1",
            "um_del_req:123",
            "um_del_confirm:123",
            "um_search_start",
            "um_spage:all:1",
            "um_cancel",
            "um_back",
            "um_close",
        ]
        for cb_data in callbacks_to_test:
            self.bot.answer_callback_query.reset_mock()
            cb = self._make_callback(cb_data, chat_id=unreg_id)
            self.bot.process_new_callback_query([cb])

            self.bot.answer_callback_query.assert_called_with(
                cb.id,
                "⛔ غير مصرح لك بتنفيذ هذا الإجراء.",
                show_alert=True,
            )

    def test_unregistered_user_blocked_on_all_stateful_inputs_and_uploads(self):
        """Unregistered user sending messages or documents in any active state is rejected."""
        unreg_id = 999111555

        # 1. Text-based states
        text_states = [S_AUTH, S_ADMIN_ADD_ID, S_ADMIN_SEARCH]
        for st in text_states:
            self.state.set_state(unreg_id, st)
            self.bot.send_message.reset_mock()

            msg = self._make_message("1000123456", chat_id=unreg_id)
            self.bot.process_new_messages([msg])

            self.bot.send_message.assert_called_once()
            sent_text = self.bot.send_message.call_args[0][1]
            self.assertIn("الوصول غير مصرح به", sent_text)

        # 2. Document/text states (uploading target lists or cookies)
        doc_states = [
            S_INPUT_JOIN,
            S_INPUT_MOD_GROUPS,
            S_INPUT_APP_GROUPS,
            S_INPUT_APP_MEMBERS,
            S_INPUT_FF_FILE,
        ]
        doc = types.Document("doc_1", "uniq_1", file_name="targets.txt", mime_type="text/plain", file_size=100)
        for st in doc_states:
            self.state.set_state(unreg_id, st)
            self.bot.send_message.reset_mock()

            # Test text
            msg_text = self._make_message("1000123456", chat_id=unreg_id)
            self.bot.process_new_messages([msg_text])
            self.bot.send_message.assert_called_once()
            self.assertIn("الوصول غير مصرح به", self.bot.send_message.call_args[0][1])

            # Test document upload
            self.bot.send_message.reset_mock()
            msg_doc = self._make_message("", chat_id=unreg_id, document=doc)
            self.bot.process_new_messages([msg_doc])
            self.bot.send_message.assert_called_once()
            self.assertIn("الوصول غير مصرح به", self.bot.send_message.call_args[0][1])

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # User Role Guard Tests
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_regular_user_cannot_access_user_management(self):
        """Regular user sending management button or admin callback is rejected."""
        user_id = 800001
        self.access_mgr.add_user(actor_id=OWNER_ID, target_id=user_id, role="user")

        # 1. Message trigger
        msg = self._make_message("👥 إدارة المستخدمين", chat_id=user_id)
        self.bot.process_new_messages([msg])
        reply_text = self.bot.reply_to.call_args[0][1]
        self.assertIn("ليس لديك صلاحية للوصول إلى لوحة إدارة المستخدمين", reply_text)

        # 2. Callback trigger
        cb = self._make_callback("um_add_start", chat_id=user_id)
        self.bot.process_new_callback_query([cb])
        self.bot.answer_callback_query.assert_called_with(
            cb.id,
            "⛔ يتطلب هذا الإجراء صلاحيات إدارية.",
            show_alert=True,
        )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Owner Add/Delete User Workflow Tests
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_owner_add_user_full_flow(self):
        """Owner initiates add user -> inputs ID -> picks role -> confirms -> user added."""
        # 1. Click '👥 إدارة المستخدمين'
        msg_menu = self._make_message("👥 إدارة المستخدمين", chat_id=OWNER_ID)
        self.bot.process_new_messages([msg_menu])
        sent_text = self.bot.send_message.call_args[0][1]
        self.assertIn("لوحة إدارة المستخدمين", sent_text)

        # 2. Click '➕ إضافة مستخدم' -> shows role picker
        cb_add = self._make_callback("um_add_start", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_add])
        edit_text = self.bot.edit_message_text.call_args[0][0]
        self.assertIn("اختر الدور الذي ترغب في منحه", edit_text)

        # 3. Owner selects 'admin' role -> transitions to S_ADMIN_ADD_ID
        cb_role = self._make_callback("um_set_role:admin", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_role])
        self.assertEqual(self.state.get_state(OWNER_ID), S_ADMIN_ADD_ID)

        # 4. Enter target Telegram ID
        target_id = 888001
        msg_id = self._make_message(str(target_id), chat_id=OWNER_ID)
        self.bot.process_new_messages([msg_id])
        sent_text = self.bot.send_message.call_args[0][1]
        self.assertIn("تأكيد إضافة الحساب", sent_text)

        # 5. Owner confirms addition
        cb_confirm = self._make_callback("um_add_confirm", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_confirm])

        # Verify added to DB
        self.assertEqual(self.access_mgr.get_role(target_id), "admin")

    def test_admin_add_user_restricted_flow(self):
        """Admin adding user automatically skips role selection and defaults to 'user'."""
        admin_id = 888002
        self.access_mgr.add_user(actor_id=OWNER_ID, target_id=admin_id, role="admin")

        # 1. Admin clicks '➕ إضافة مستخدم'
        cb_add = self._make_callback("um_add_start", chat_id=admin_id)
        self.bot.process_new_callback_query([cb_add])
        self.assertEqual(self.state.get_state(admin_id), S_ADMIN_ADD_ID)

        # 2. Admin enters target Telegram ID
        target_id = 888003
        msg_id = self._make_message(str(target_id), chat_id=admin_id)
        self.bot.process_new_messages([msg_id])

        # Admin gets direct confirmation keyboard (role is fixed to 'user')
        sent_text = self.bot.send_message.call_args[0][1]
        self.assertIn("تأكيد إضافة الحساب", sent_text)
        self.assertIn("عضو (USER)", sent_text)

        # 3. Admin confirms
        cb_confirm = self._make_callback("um_add_confirm", chat_id=admin_id)
        self.bot.process_new_callback_query([cb_confirm])

        # Verify added as user
        self.assertEqual(self.access_mgr.get_role(target_id), "user")

    def test_add_user_invalid_non_numeric_id(self):
        """Providing invalid non-numeric input for Telegram ID sends validation error."""
        self.state.set_state(OWNER_ID, S_ADMIN_ADD_ID)
        msg_invalid = self._make_message("invalid_non_numeric_id", chat_id=OWNER_ID)
        self.bot.process_new_messages([msg_invalid])

        reply_text = self.bot.reply_to.call_args[0][1]
        self.assertIn("معرّف غير صالح", reply_text)
        self.assertEqual(self.state.get_state(OWNER_ID), S_ADMIN_ADD_ID)

    def test_delete_user_workflow(self):
        """Test delete user confirmation and execution."""
        user_id = 888004
        self.access_mgr.add_user(actor_id=OWNER_ID, target_id=user_id, role="user")

        # Request delete
        cb_del_req = self._make_callback(f"um_del_req:{user_id}", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_del_req])

        edit_text = self.bot.edit_message_text.call_args[0][0]
        self.assertIn("تأكيد سحب الصلاحيات والحذف", edit_text)

        # Confirm delete
        cb_del_conf = self._make_callback(f"um_del_confirm:{user_id}", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_del_conf])

        # User is deleted
        self.assertIsNone(self.access_mgr.get_role(user_id))

    def test_delete_user_disconnects_session_and_stops_worker(self):
        """
        When user deletion is confirmed, state.disconnect(target_id) must be invoked immediately:
        - Active Facebook login session is purged
        - Transient operation data is wiped
        - If a task is actively running, stop signal is set (is_stopped == True)
        - Conversation state is reset to S_AUTH
        """
        target_id = 888099
        self.access_mgr.add_user(actor_id=OWNER_ID, target_id=target_id, role="user")

        # Simulate user having an active session, temporary data, running task lock, and state
        self.state.set_user(target_id, {"id": str(target_id), "name": "ActiveUser", "token": "EAAG..."})
        self.state.set_state(target_id, S_MENU)
        self.state.init_operation_data(target_id, "connect_groups")
        self.state.set_data(target_id, "speed", 5)

        # Simulate worker running with acquired task lock
        acquired = self.state.acquire_task_lock(target_id)
        self.assertTrue(acquired)
        self.assertTrue(self.state.is_task_running(target_id))
        self.assertFalse(self.state.is_stopped(target_id))
        self.assertTrue(self.state.has_user(target_id))

        # Admin/Owner confirms deletion
        cb_del_conf = self._make_callback(f"um_del_confirm:{target_id}", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_del_conf])

        # Assert user removed from Access Control DB
        self.assertIsNone(self.access_mgr.get_role(target_id))

        # Assert state.disconnect(target_id) was executed
        self.assertFalse(self.state.has_user(target_id), "Active login session must be completely purged")
        self.assertEqual(self.state.get_data(target_id), {}, "Temporary operation data must be cleared")
        self.assertTrue(self.state.is_stopped(target_id), "Stop flag must be set to terminate running worker")
        self.assertEqual(self.state.get_state(target_id), S_AUTH, "User state must be reset to S_AUTH")

    def test_search_user_flow(self):
        """Test search user by username query."""
        user_id = 888005
        self.access_mgr.add_user(
            actor_id=OWNER_ID,
            target_id=user_id,
            role="user",
            first_name="Zaid",
            username="zaid_dev",
        )

        # Start search
        cb_search = self._make_callback("um_search_start", chat_id=OWNER_ID)
        self.bot.process_new_callback_query([cb_search])
        self.assertEqual(self.state.get_state(OWNER_ID), S_ADMIN_SEARCH)

        # Submit search query
        msg_query = self._make_message("zaid_dev", chat_id=OWNER_ID)
        self.bot.process_new_messages([msg_query])

        sent_text = self.bot.send_message.call_args[0][1]
        self.assertIn("نتائج البحث", sent_text)
        self.assertIn("zaid_dev", sent_text)

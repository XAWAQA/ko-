"""
Tests for configuration loading and validation.
"""

import os
import unittest
from unittest.mock import patch
import config


class TestConfig(unittest.TestCase):
    def test_default_config_values(self):
        """Verifies safe defaults are present."""
        self.assertGreater(config.CPU_CORES, 0)
        self.assertGreaterEqual(config.REQUEST_TIMEOUT, 5.0)
        self.assertEqual(config.RETRY_ATTEMPTS, 3)
        self.assertIn(50, config.SPEED_OPTIONS)
        self.assertIn(100, config.SPEED_OPTIONS)

    def test_missing_telegram_token_exits_cleanly(self):
        """Verifies that empty TELEGRAM_BOT_TOKEN triggers clean exit with code 1."""
        with patch.object(config, "TELEGRAM_BOT_TOKEN", ""):
            with self.assertRaises(SystemExit) as cm:
                config.validate_config()
            self.assertEqual(cm.exception.code, 1)

    def test_valid_telegram_token_passes(self):
        """Verifies that configuring TELEGRAM_BOT_TOKEN validates without error."""
        with patch.object(config, "TELEGRAM_BOT_TOKEN", "123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"):
            try:
                config.validate_config()
            except SystemExit:
                self.fail("validate_config() raised SystemExit unexpectedly!")


if __name__ == "__main__":
    unittest.main()

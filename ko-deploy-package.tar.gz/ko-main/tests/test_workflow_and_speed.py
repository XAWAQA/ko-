"""
Comprehensive Bot Workflow, Speed, Concurrency, and Resilience Tests.
Exhaustively audits:
1. Connect Groups workflow (single & multi page selection, txt uploads).
2. Input validation (empty, invalid, duplicates, emoji filters).
3. All speed settings (1, 5, 10, 50, 100, 200, 350, 500) and worker semaphore mapping.
4. Mathematical task count calculation (join, approve, moderator).
5. Double-click prevention on confirm button.
6. Termination / stop button responsiveness and cleanup.
7. Partial task failure logging and stats accuracy.
8. Zero-token leak guarantee in logs, messages, and reports.
9. Approve member actor restriction (personal profile only).
"""

import asyncio
import io
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import telebot
from telebot import types

from access.testing import create_test_access_manager
from bot.handlers import register_handlers
from bot.keyboards import (
    get_confirm_buttons,
    get_main_menu,
    get_pages_list,
    get_source_buttons,
    get_speed_buttons,
)
from bot.state import (
    S_AUTH,
    S_INPUT_APP_GROUPS,
    S_INPUT_APP_MEMBERS,
    S_INPUT_JOIN,
    S_INPUT_MOD_GROUPS,
    S_MENU,
    StateManager,
)
from config import SPEED_OPTIONS
from facebook.client import MockFacebookClient
from facebook.models import FacebookPage, FacebookUser, OperationStatus, TaskResult
from utils.validation import is_valid_token, parse_id_list
from workers.engine import WorkerEngine
from workers.progress import make_final_report, make_premium_progress


class TestBotWorkflowAndSpeedAudit(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN_WORKFLOW_TEST", threaded=False)
        self.state = StateManager()
        self.mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        self.engine = WorkerEngine(bot=self.bot, fb_client=self.mock_fb, state=self.state)
        self.access_mgr = create_test_access_manager()
        register_handlers(
            bot=self.bot,
            engine=self.engine,
            state=self.state,
            fb_client=self.mock_fb,
            access_mgr=self.access_mgr,
        )

        # Mock telebot outbound network operations
        self.bot.send_message = MagicMock(side_effect=lambda *args, **kwargs: self._make_message("mock_resp", 1001))
        self.bot.edit_message_text = MagicMock(return_value=True)
        self.bot.edit_message_reply_markup = MagicMock(return_value=True)
        self.bot.delete_message = MagicMock(return_value=True)
        self.bot.reply_to = MagicMock(side_effect=lambda *args, **kwargs: self._make_message("mock_reply", 1001))
        self.bot.answer_callback_query = MagicMock(return_value=True)
        self.bot.get_file = MagicMock()
        self.bot.download_file = MagicMock()

    def tearDown(self):
        if hasattr(self, "access_mgr") and self.access_mgr:
            self.access_mgr.cleanup()

    def _make_message(self, text: str = "", chat_id: int = 1001, document=None) -> types.Message:
        msg = types.Message(
            message_id=99,
            from_user=types.User(chat_id, False, "TestUser"),
            date=1700000000,
            chat=types.Chat(chat_id, "private"),
            content_type="document" if document else "text",
            options={},
            json_string="",
        )
        msg.text = text
        msg.document = document
        return msg

    def _make_callback(self, data: str, chat_id: int = 1001, message_id: int = 88) -> types.CallbackQuery:
        cb = types.CallbackQuery(
            id="cb_test_1",
            from_user=types.User(chat_id, False, "TestUser"),
            data=data,
            chat_instance="ci_test",
            json_string="",
        )
        cb.message = self._make_message("", chat_id)
        cb.message.message_id = message_id
        return cb

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1. Join Groups: Single & Multi-Page Selection
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_single_and_multi_page_selection(self):
        """Audits page toggling: selecting 1 page, multiple pages, toggle all, and finalize."""
        chat_id = 2001
        self.state.set_user(chat_id, {"id": "user_1", "name": "Admin", "token": "EAAB_SECRET_TOKEN"})
        self.state.init_operation_data(chat_id, "join")

        # Simulate 3 pages discovered from Facebook API
        pages_data = [
            {"id": "pg_1", "name": "Page Alpha", "token": "tok_p1"},
            {"id": "pg_2", "name": "Page Beta", "token": "tok_p2"},
            {"id": "pg_3", "name": "Page Gamma", "token": "tok_p3"},
        ]
        self.state.set_data(chat_id, "all_pages", pages_data)
        self.state.set_data(chat_id, "selected_pages", [])

        # 1. Toggle page 1 -> selected: [pg_1]
        cb1 = self._make_callback("pg:pg_1", chat_id)
        self.bot.process_new_callback_query([cb1])
        data = self.state.get_data(chat_id)
        self.assertEqual(data["selected_pages"], ["pg_1"])

        # 2. Toggle page 2 -> selected: [pg_1, pg_2] (multi-page)
        cb2 = self._make_callback("pg:pg_2", chat_id)
        self.bot.process_new_callback_query([cb2])
        data = self.state.get_data(chat_id)
        self.assertEqual(data["selected_pages"], ["pg_1", "pg_2"])

        # 3. Toggle all -> selects all 3 pages
        cb_all = self._make_callback("toggle_all", chat_id)
        self.bot.process_new_callback_query([cb_all])
        data = self.state.get_data(chat_id)
        self.assertEqual(set(data["selected_pages"]), {"pg_1", "pg_2", "pg_3"})

        # 4. Deselect page 2 -> selected: [pg_1, pg_3]
        cb_desel = self._make_callback("pg:pg_2", chat_id)
        self.bot.process_new_callback_query([cb_desel])
        data = self.state.get_data(chat_id)
        self.assertEqual(set(data["selected_pages"]), {"pg_1", "pg_3"})

        # 5. Finalize selection via done_select
        cb_done = self._make_callback("done_select", chat_id)
        self.bot.process_new_callback_query([cb_done])

        # Verify state transitioned and actors preserved without loss or duplication
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_JOIN)
        actors = self.state.get_data(chat_id).get("actors", [])
        self.assertEqual(len(actors), 2)
        actor_ids = [a["id"] for a in actors]
        self.assertIn("pg_1", actor_ids)
        self.assertIn("pg_3", actor_ids)
        self.assertNotIn("pg_2", actor_ids)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 2. Input Validation: Valid, Empty, Duplicates, and Emojis
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_txt_file_and_input_parsing(self):
        """Audits txt file upload parsing, deduplication, invalid lines, and empty files."""
        # A. Valid multiline content with duplicates and extra spaces
        raw_content = "1001\n 1002 \n1001\n\n1003\n 1002\n"
        parsed = parse_id_list(raw_content)
        self.assertEqual(parsed, ["1001", "1002", "1003"], "Must deduplicate while preserving order")

        # B. Content with accidental menu emoji clicks
        menu_content = "1001\n⚡ CONNECT GROUPS\n1002\n🚫 TERMINATE\n"
        parsed_menu = parse_id_list(menu_content)
        self.assertEqual(parsed_menu, ["1001", "1002"], "Must filter out emoji menu buttons")

        # C. Empty file or whitespace-only
        self.assertEqual(parse_id_list(""), [])
        self.assertEqual(parse_id_list("   \n\n  \t  "), [])

        # D. Invalid characters and spaces within tokens
        invalid_content = "1001\nnot a valid id\n1002@#$%^&\n1003"
        parsed_invalid = parse_id_list(invalid_content)
        self.assertEqual(parsed_invalid, ["1001", "1003"])

    def test_txt_file_upload_handler(self):
        """Audits uploaded document handling in handle_receive_join_groups."""
        chat_id = 2002
        self.state.set_user(chat_id, {"id": "user_2", "name": "Admin", "token": "tok"})
        self.state.set_state(chat_id, S_INPUT_JOIN)

        # Mock telegram file download returning 3 group IDs
        doc = types.Document("doc_123", "uniq_123", file_name="groups.txt", mime_type="text/plain", file_size=100)
        self.bot.get_file.return_value = types.File("f1", "fpath", 100)
        self.bot.download_file.return_value = b"group_A\ngroup_B\ngroup_C\ngroup_A\n"

        msg = self._make_message(chat_id=chat_id, document=doc)
        self.bot.process_new_messages([msg])

        targets = self.state.get_data(chat_id).get("targets", [])
        self.assertEqual(targets, ["group_A", "group_B", "group_C"])
        self.bot.send_message.assert_called()

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 3. Speed Options & Concurrency Mapping
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_all_speed_options_and_worker_settings(self):
        """Verifies all speeds in SPEED_OPTIONS are generated and mapped to Semaphore."""
        expected_speeds = [1, 5, 10, 50, 100, 200, 350, 500]
        self.assertEqual(SPEED_OPTIONS, expected_speeds)

        markup = get_speed_buttons()
        button_callbacks = [b.callback_data for row in markup.keyboard for b in row]
        for s in expected_speeds:
            self.assertIn(f"spd:{s}", button_callbacks)

        # Verify that for each speed, show_summary computes concurrency text
        for s in expected_speeds:
            chat_id = 3000 + s
            self.state.init_operation_data(chat_id, "join")
            self.state.set_data(chat_id, "targets", ["g1", "g2"])
            self.state.set_data(chat_id, "actors", [{"id": "a1", "token": "t1"}])

            cb = self._make_callback(f"spd:{s}", chat_id)
            self.bot.process_new_callback_query([cb])

            # Check that the summary message was sent with exact speed
            args, kwargs = self.bot.send_message.call_args
            summary_text = args[1]
            self.assertIn(f"CONCURRENCY: `{s} simultaneous`", summary_text)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 4. Accurate Task Count Calculations (Before Run)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_expected_task_count_calculations(self):
        """Tests mathematical ops calculation for Join, Approve, and Moderator."""
        chat_id = 4001

        # A. Join: N targets * M actors
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", ["g1", "g2", "g3", "g4"])  # 4 targets
        self.state.set_data(chat_id, "actors", [{"id": "p1"}, {"id": "p2"}, {"id": "p3"}])  # 3 actors
        cb = self._make_callback("spd:10", chat_id)
        self.bot.process_new_callback_query([cb])
        args, _ = self.bot.send_message.call_args
        self.assertIn("TOTAL OPS: `12`", args[1])  # 4 * 3 = 12

        # B. Approve: G groups * M members
        self.state.init_operation_data(chat_id, "approve")
        self.state.set_data(chat_id, "app_groups", ["g1", "g2"])  # 2 groups
        self.state.set_data(chat_id, "app_members", ["m1", "m2", "m3", "m4", "m5"])  # 5 members
        cb = self._make_callback("spd:5", chat_id)
        self.bot.process_new_callback_query([cb])
        args, _ = self.bot.send_message.call_args
        self.assertIn("TOTAL OPS: `10`", args[1])  # 2 * 5 = 10

        # C. Moderator: G groups
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["g1", "g2", "g3", "g4", "g5", "g6", "g7"])  # 7 groups
        cb = self._make_callback("spd:50", chat_id)
        self.bot.process_new_callback_query([cb])
        args, _ = self.bot.send_message.call_args
        self.assertIn("TOTAL OPS: `7`", args[1])  # 7

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 5. Double-Click / Race Condition Protection
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_double_click_protection_acquire_task_lock(self):
        """Verifies duplicate clicks on confirm button are safely rejected."""
        chat_id = 5001
        self.assertFalse(self.state.is_task_running(chat_id))

        # First lock attempt succeeds
        acquired = self.state.acquire_task_lock(chat_id)
        self.assertTrue(acquired)
        self.assertTrue(self.state.is_task_running(chat_id))

        # Second lock attempt (double click simulation) fails
        duplicate_attempt = self.state.acquire_task_lock(chat_id)
        self.assertFalse(duplicate_attempt)

        # Trigger confirm callback while lock is held
        cb = self._make_callback("confirm:10", chat_id)
        with patch.object(self.engine, "run_async") as mock_run:
            self.bot.process_new_callback_query([cb])
            # Engine must NOT launch a second background task
            mock_run.assert_not_called()
            # Must answer callback with alert warning
            self.bot.answer_callback_query.assert_called_with(
                cb.id,
                "⚠️ هناك عملية قيد التشغيل بالفعل! يرجى الانتظار أو الإيقاف أولاً.",
                show_alert=True,
            )

        # Release lock -> future attempts succeed
        self.state.release_task_lock(chat_id)
        self.assertFalse(self.state.is_task_running(chat_id))
        self.assertTrue(self.state.acquire_task_lock(chat_id))
        self.state.release_task_lock(chat_id)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 6. Stop / Termination Responsiveness & Task Cleanup
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def test_stop_button_halts_new_tasks_and_cleans_up(self):
        """Verifies that TERMINATE signal halts queued tasks and frees lock."""
        chat_id = 6001
        self.state.set_user(chat_id, {"id": "usr_stop", "name": "Test", "token": "secret_tok"})
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", [f"grp_{i}" for i in range(20)])  # 20 tasks
        self.state.set_data(chat_id, "actors", [{"id": "act_1", "name": "Node", "token": "tok"}])

        executed_count = 0
        original_exec = self.mock_fb.execute_graphql_request

        async def counting_exec(*args, **kwargs):
            nonlocal executed_count
            executed_count += 1
            if executed_count == 3:
                # Trigger TERMINATE signal mid-run
                self.state.set_stop_flag(chat_id, True)
            return await original_exec(*args, **kwargs)

        self.mock_fb.execute_graphql_request = counting_exec

        # Run pipeline
        await self.engine.process_async(chat_id, speed=1)

        # Must not have executed all 20 tasks
        self.assertLess(executed_count, 20)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)
        self.assertFalse(self.state.is_task_running(chat_id), "Task lock must be released")

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 7. Partial Failure Handling & Stats Accuracy
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def test_partial_task_failures_record_accurate_stats(self):
        """Audits execution where half tasks fail and half succeed."""
        chat_id = 7001
        self.state.set_user(chat_id, {"id": "usr_part", "name": "Test", "token": "tok"})
        self.state.init_operation_data(chat_id, "approve")
        self.state.set_data(chat_id, "app_groups", ["grp_1", "grp_2"])
        self.state.set_data(chat_id, "app_members", ["mem_1", "mem_2"])  # 2 * 2 = 4 tasks

        call_idx = 0

        async def alternate_success_failure(*args, **kwargs):
            nonlocal call_idx
            call_idx += 1
            if call_idx % 2 == 1:
                return TaskResult(
                    success=True,
                    status=OperationStatus.SUCCESS,
                    is_retryable=False,
                    status_code=200,
                    data={"data": {"success": True}}
                )
            else:
                return TaskResult(
                    success=False,
                    status=OperationStatus.CLIENT_ERROR,
                    is_retryable=False,
                    status_code=400,
                    error_message="(#100) Invalid target",
                    data={"errors": [{"message": "Invalid target"}]}
                )

        self.mock_fb.execute_graphql_request = alternate_success_failure

        await self.engine.process_async(chat_id, speed=2)

        # Verify exact stats in final report
        # The bot should have edited message with final report
        edit_calls = self.bot.edit_message_text.call_args_list
        self.assertTrue(len(edit_calls) > 0)
        final_report_text = edit_calls[-1][0][0]
        self.assertIn("PROCESSED: `4`", final_report_text)
        self.assertIn("✅ SUCCESS: `2`", final_report_text)
        self.assertIn("❌ FAILED: `2`", final_report_text)

        # Verify error log details were sent for the 2 failures
        send_calls = self.bot.send_message.call_args_list
        error_log_messages = [c[0][1] for c in send_calls if "ERROR LOG" in str(c[0][1])]
        self.assertTrue(len(error_log_messages) > 0)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 8. Token Leak Prevention in Logs, Reports, & Progress
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_zero_token_leakage_in_reports_and_ui(self):
        """Verifies sensitive tokens never appear in progress or report text."""
        secret_token = "EAAD6V7os0gcBSrtFZANWdxAmIT5UlOwhR7Sawc7Nbu3fsQwKl8m24Qx"
        stats = {"done": 50, "ok": 45, "bad": 5, "retried": 2}

        # Generate progress text
        prog = make_premium_progress(50, 100, 1700000000.0, stats)
        self.assertNotIn(secret_token, prog)

        # Generate final report text
        report = make_final_report(stats, 12, 4)
        self.assertNotIn(secret_token, report)

        # Verify token validation function rejects invalid formats
        self.assertFalse(is_valid_token(""))
        self.assertFalse(is_valid_token("short"))
        self.assertFalse(is_valid_token("token with spaces"))
        self.assertTrue(is_valid_token(secret_token))

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 9. Approve Member: Restricted to Personal Profile Only
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def test_approve_member_actor_restriction(self):
        """Confirms Approve Member strictly binds to main user profile, NOT fan pages."""
        chat_id = 9001
        main_user_token = "EAAB_PERSONAL_TOKEN"
        main_user_id = "61550890575487"
        self.state.set_user(chat_id, {"id": main_user_id, "name": "MainUser", "token": main_user_token})

        # Even if data contains pages from previous operations:
        self.state.init_operation_data(chat_id, "approve")
        self.state.set_data(chat_id, "actors", [{"id": "fan_page_999", "token": "EAAB_PAGE_TOKEN"}])
        self.state.set_data(chat_id, "app_groups", ["grp_target"])
        self.state.set_data(chat_id, "app_members", ["mem_target"])

        captured_tokens = []
        captured_actors = []

        async def capture_request(client, doc_id, variables, token, op):
            captured_tokens.append(token)
            captured_actors.append(variables["input"]["actor_id"])
            return TaskResult(
                success=True,
                status=OperationStatus.SUCCESS,
                is_retryable=False,
                status_code=200,
                data={"data": {"success": True}}
            )

        self.mock_fb.execute_graphql_request = capture_request

        await self.engine.process_async(chat_id, speed=1)

        # Verify only main user token and main user id were used
        self.assertEqual(len(captured_tokens), 1)
        self.assertEqual(captured_tokens[0], main_user_token)
        self.assertEqual(captured_actors[0], main_user_id)
        self.assertNotIn("EAAB_PAGE_TOKEN", captured_tokens)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 10. Repetitive Terminate & Starting Task After Stop
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_repetitive_terminate_presses(self):
        """Audits rapid repeated clicks on TERMINATE."""
        chat_id = 9101
        self.state.acquire_task_lock(chat_id)
        msg = self._make_message("🚫 TERMINATE", chat_id)

        # Press terminate 5 times
        for _ in range(5):
            self.bot.process_new_messages([msg])
            self.assertTrue(self.state.is_stopped(chat_id))

        # Lock is released when task finishes
        self.state.release_task_lock(chat_id)
        self.assertFalse(self.state.is_task_running(chat_id))

    async def test_start_new_task_after_stopping_previous_task(self):
        """Audits starting a new task after safely cancelling a prior task."""
        chat_id = 9102
        self.state.set_user(chat_id, {"id": "usr_restart", "name": "RestartNode", "token": "tok_1"})

        # Task 1: Start and stop immediately
        self.state.acquire_task_lock(chat_id)
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", ["g1", "g2", "g3"])
        self.state.set_data(chat_id, "actors", [{"id": "act1", "token": "tok_1"}])
        self.state.set_stop_flag(chat_id, True)

        await self.engine.process_async(chat_id, speed=1)

        # Verify task 1 halted cleanly and freed the lock
        self.assertFalse(self.state.is_task_running(chat_id))

        # Task 2: Launch a new task cleanly
        lock_ok = self.state.acquire_task_lock(chat_id)
        self.assertTrue(lock_ok, "Must be able to acquire lock after previous task ended")
        self.assertFalse(self.state.is_stopped(chat_id), "Stop flag must be cleanly reset for new task")

        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["grp_new"])

        exec_count = 0
        async def mock_exec(*args, **kwargs):
            nonlocal exec_count
            exec_count += 1
            return TaskResult(success=True, status=OperationStatus.SUCCESS, is_retryable=False, status_code=200, data={"data": {"ok": True}})

        self.mock_fb.execute_graphql_request = mock_exec
        await self.engine.process_async(chat_id, speed=1)

        self.assertEqual(exec_count, 1)
        self.assertFalse(self.state.is_task_running(chat_id))

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 11. Disconnect Mid-Execution & Zombie Task Prevention
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def test_disconnect_while_task_is_running(self):
        """Audits disconnecting session mid-run: worker halts and lock is freed."""
        chat_id = 9103
        self.state.set_user(chat_id, {"id": "usr_dc", "name": "DcNode", "token": "tok_dc"})
        self.state.acquire_task_lock(chat_id)
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", [f"g_{i}" for i in range(15)])
        self.state.set_data(chat_id, "actors", [{"id": "a1", "token": "tok"}])

        executed_requests = 0
        async def exec_with_disconnect(*args, **kwargs):
            nonlocal executed_requests
            executed_requests += 1
            if executed_requests == 2:
                # User sends DISCONNECT mid-flight
                self.state.disconnect(chat_id)
            return TaskResult(success=True, status=OperationStatus.SUCCESS, is_retryable=False, status_code=200, data={"data": {"ok": True}})

        self.mock_fb.execute_graphql_request = exec_with_disconnect

        await self.engine.process_async(chat_id, speed=2)

        # Verify execution stopped early due to disconnect
        self.assertLess(executed_requests, 15)
        self.assertFalse(self.state.has_user(chat_id))
        self.assertFalse(self.state.is_task_running(chat_id))

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 12. GraphQL Null Entity & Ambiguous Responses
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_graphql_null_entity_and_empty_data_rejection(self):
        """Verifies FacebookClient rejects data payloads where entities are null."""
        from facebook.client import FacebookClient
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)

        # Case A: {"data": {"group_approve_member": None}} -> all nulls
        res_null = client._parse_json_result(
            {"data": {"group_approve_member": None}}, "{}", "approve", 200
        )
        self.assertFalse(res_null.success)
        self.assertIn("null entity", res_null.error_message)

        # Case B: {"data": None}
        res_none = client._parse_json_result(
            {"data": None}, "{}", "approve", 200
        )
        self.assertFalse(res_none.success)
        self.assertEqual(res_none.status, OperationStatus.INCONCLUSIVE)

        # Case C: {"data": {}}
        res_empty = client._parse_json_result(
            {"data": {}}, "{}", "approve", 200
        )
        self.assertFalse(res_empty.success)
        self.assertEqual(res_empty.status, OperationStatus.INCONCLUSIVE)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 13. Token Message Deleted Upon Login
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def test_token_message_deleted_on_login(self):
        """Verifies handle_login deletes the Telegram message containing the token."""
        chat_id = 9104
        self.state.set_state(chat_id, S_AUTH)
        token_msg = self._make_message("EAAB_SENSITIVE_SECRET_TOKEN_12345", chat_id)
        token_msg.message_id = 555

        self.bot.process_new_messages([token_msg])

        # Must have deleted message 555
        self.bot.delete_message.assert_any_call(chat_id, 555)


if __name__ == "__main__":
    unittest.main()


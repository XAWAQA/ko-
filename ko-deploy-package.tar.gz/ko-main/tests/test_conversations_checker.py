"""
Unit and integration tests for Facebook Page Conversations & Open Inbox Inspector (test.py).
Verifies:
- Accurate open/closed conversation heuristic classification.
- Resilient Graph API error handling (OAuth 190 auth error, rate limit 429, permission error).
- Event loop safety and nested loop execution.
- Telegram bot integration handlers for /convs command and page selection callbacks.
- Absence of hardcoded tokens and secrets.
"""

import asyncio
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import telebot

from access.testing import create_test_access_manager
from test import (
    FacebookAuthError,
    FacebookPermissionError,
    FacebookRateLimitError,
    FacebookGraphError,
    conv_is_open,
    fetch_json,
    get_pages,
    iterate_conversation_batches,
    process_page,
    run_async,
    select_pages_interactive,
    scan_pages_conversations,
    mask_token,
)


class TestConversationHeuristics(unittest.TestCase):
    """Verifies strict classification of open vs closed conversations."""

    def test_unread_count_greater_than_zero_is_open(self):
        self.assertTrue(conv_is_open({"id": "1", "unread_count": 3}))
        self.assertTrue(conv_is_open({"id": "2", "unread_count": "1"}))

    def test_zero_unread_without_tags_is_closed(self):
        self.assertFalse(conv_is_open({"id": "3", "unread_count": 0}))
        self.assertFalse(conv_is_open({"id": "4", "unread_count": None}))

    def test_closed_keywords_override_arbitrary_tags(self):
        # A conversation tagged with 'closed' or 'done' is closed
        self.assertFalse(conv_is_open({"id": "5", "unread_count": 0, "tags": [{"name": "closed"}, {"name": "vip"}]}))
        self.assertFalse(conv_is_open({"id": "6", "unread_count": 0, "tags": ["done", "support"]}))
        self.assertFalse(conv_is_open({"id": "7", "unread_count": 0, "tags": [{"name": "archived"}]}))
        self.assertFalse(conv_is_open({"id": "8", "unread_count": 0, "tags": ["resolved"]}))
        self.assertFalse(conv_is_open({"id": "9", "unread_count": 0, "tags": ["spam"]}))

    def test_explicit_open_keywords_are_open(self):
        self.assertTrue(conv_is_open({"id": "10", "unread_count": 0, "tags": [{"name": "inbox"}]}))
        self.assertTrue(conv_is_open({"id": "11", "unread_count": 0, "tags": ["needs_reply"]}))
        self.assertTrue(conv_is_open({"id": "12", "unread_count": 0, "tags": ["follow_up"]}))
        self.assertTrue(conv_is_open({"id": "13", "unread_count": 0, "tags": ["unread"]}))
        self.assertTrue(conv_is_open({"id": "14", "unread_count": 0, "tags": [{"name": "pending"}]}))

    def test_arbitrary_tags_do_not_falsely_mark_open(self):
        """Fixes previous bug: having a non-status tag like 'vip' does not mean it is open!"""
        self.assertFalse(conv_is_open({"id": "15", "unread_count": 0, "tags": [{"name": "vip"}]}))
        self.assertFalse(conv_is_open({"id": "16", "unread_count": 0, "tags": ["client_a", "sales"]}))
        self.assertFalse(conv_is_open({"id": "17", "unread_count": 0, "tags": [{"name": "custom_tag"}]}))

    def test_folder_attribute(self):
        self.assertTrue(conv_is_open({"id": "18", "folder": "inbox"}))
        self.assertFalse(conv_is_open({"id": "19", "folder": "done"}))
        self.assertFalse(conv_is_open({"id": "20", "folder": "spam"}))

    def test_malformed_and_edge_case_inputs(self):
        self.assertFalse(conv_is_open({}))
        self.assertFalse(conv_is_open(None))  # type: ignore
        self.assertFalse(conv_is_open("not a dict"))  # type: ignore
        self.assertFalse(conv_is_open({"unread_count": "invalid_number"}))


class TestGraphApiErrorHandling(unittest.IsolatedAsyncioTestCase):
    """Verifies API error classification, backoff, and timeouts."""

    async def test_auth_error_on_code_190(self):
        session = MagicMock()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value={"error": {"code": 190, "message": "Session has expired"}})
        session.get.return_value.__aenter__.return_value = mock_resp

        with self.assertRaises(FacebookAuthError) as cm:
            await fetch_json(session, "https://graph.facebook.com/me", retry=1)
        self.assertEqual(cm.exception.code, 190)

    async def test_auth_error_on_http_401_or_403(self):
        session = MagicMock()
        mock_resp = AsyncMock()
        mock_resp.status = 401
        mock_resp.json = AsyncMock(return_value={"error": {"message": "Invalid OAuth access token."}})
        session.get.return_value.__aenter__.return_value = mock_resp

        with self.assertRaises(FacebookAuthError):
            await fetch_json(session, "https://graph.facebook.com/me", retry=1)

    async def test_permission_error_on_code_200(self):
        session = MagicMock()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value={"error": {"code": 200, "message": "Requires pages_messaging permission"}})
        session.get.return_value.__aenter__.return_value = mock_resp

        with self.assertRaises(FacebookPermissionError):
            await fetch_json(session, "https://graph.facebook.com/page/conversations", retry=1)

    async def test_rate_limit_retry_and_exhaustion(self):
        session = MagicMock()
        mock_resp = AsyncMock()
        mock_resp.status = 429
        mock_resp.json = AsyncMock(return_value={"error": {"code": 4, "message": "Application request limit reached"}})
        session.get.return_value.__aenter__.return_value = mock_resp

        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            with self.assertRaises(FacebookRateLimitError):
                await fetch_json(session, "https://graph.facebook.com/me", retry=2)
            self.assertEqual(mock_sleep.await_count, 1)

    async def test_successful_fetch_after_transient_error(self):
        session = MagicMock()
        resp_err = AsyncMock()
        resp_err.status = 500
        resp_err.json = AsyncMock(return_value={"error": {"message": "Temporary internal error"}})

        resp_ok = AsyncMock()
        resp_ok.status = 200
        resp_ok.json = AsyncMock(return_value={"data": [{"id": "page_123"}]})

        session.get.return_value.__aenter__.side_effect = [resp_err, resp_ok]

        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await fetch_json(session, "https://graph.facebook.com/me/accounts", retry=2)
            self.assertEqual(result, {"data": [{"id": "page_123"}]})


class TestPagesAndConversationsProcessing(unittest.IsolatedAsyncioTestCase):
    """Verifies page retrieval and conversation batch processing."""

    async def test_get_pages_with_pagination(self):
        session = MagicMock()
        page_1 = {
            "data": [{"id": "101", "name": "Page A", "access_token": "tok_a"}],
            "paging": {"next": "https://graph.facebook.com/v18.0/me/accounts?after=xyz"},
        }
        page_2 = {
            "data": [{"id": "102", "name": "Page B", "access_token": "tok_b"}],
            "paging": {},
        }

        with patch("test.fetch_json", side_effect=[page_1, page_2]):
            pages = await get_pages(session, "user_token")
            self.assertEqual(len(pages), 2)
            self.assertEqual(pages[0]["id"], "101")
            self.assertEqual(pages[1]["id"], "102")

    async def test_process_page_counts_open_conversations(self):
        session = MagicMock()
        page = {"id": "101", "name": "Store Page", "access_token": "token_101"}

        batch_1 = [
            {"id": "c1", "unread_count": 2},  # open
            {"id": "c2", "unread_count": 0},  # closed
            {"id": "c3", "unread_count": 0, "tags": ["inbox"]},  # open
        ]
        batch_2 = [
            {"id": "c4", "unread_count": 0, "tags": ["done"]},  # closed
            {"id": "c5", "unread_count": 1},  # open
        ]

        async def mock_iterate(s, pid, tok, limit=499):
            yield batch_1, False, None
            yield batch_2, False, None

        with patch("test.iterate_conversation_batches", side_effect=mock_iterate):
            result = await process_page(session, page)
            self.assertEqual(result["id"], "101")
            self.assertEqual(result["total_scanned"], 5)
            self.assertEqual(result["open_convs"], 3)
            self.assertEqual(result["status"], "ok")

    async def test_process_page_partial_status_on_paging_failure(self):
        session = MagicMock()
        page = {"id": "102", "name": "Partial Page", "access_token": "token_102"}

        async def mock_iterate(s, pid, tok, limit=499):
            yield [{"id": "c1", "unread_count": 1}], True, "rate_limited"

        with patch("test.iterate_conversation_batches", side_effect=mock_iterate):
            result = await process_page(session, page)
            self.assertEqual(result["open_convs"], 1)
            self.assertEqual(result["total_scanned"], 1)
            self.assertEqual(result["status"], "partial")
            self.assertIn("rate_limited", result["note"])


class TestAsyncAndLoopSafety(unittest.TestCase):
    """Verifies run_async handles already running event loops cleanly."""

    def test_run_async_outside_event_loop(self):
        async def sample_coro():
            return 42

        self.assertEqual(run_async(sample_coro()), 42)

    def test_run_async_inside_existing_event_loop(self):
        async def outer():
            async def inner():
                return 99
            # Calling run_async inside an active loop must NOT throw RuntimeError
            return run_async(inner())

        result = asyncio.run(outer())
        self.assertEqual(result, 99)


class TestSecurityAndSecretsHygiene(unittest.TestCase):
    """Ensures zero hardcoded secrets exist in test.py."""

    def test_no_hardcoded_facebook_tokens_in_test_py(self):
        with open("test.py", "r", encoding="utf-8") as f:
            content = f.read()

        # The old exposed token started with EAAD6V7...
        self.assertNotIn("EAAD6V7os0gcBQ", content)
        self.assertNotIn("7127482770:AAHd6F", content)

    def test_mask_token_helper(self):
        self.assertEqual(mask_token("EAAB1234567890XYZ"), "EAAB...0XYZ")
        self.assertEqual(mask_token("short"), "***")
        self.assertEqual(mask_token(""), "<none>")
        self.assertEqual(mask_token(None), "<none>")


class TestTelegramBotIntegration(unittest.TestCase):
    """Verifies Telegram bot handlers for /convs command and page selection."""

    def setUp(self):
        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN", threaded=False)
        self.bot.send_message = MagicMock()
        self.bot.reply_to = MagicMock()
        self.bot.edit_message_text = MagicMock()
        self.bot.edit_message_reply_markup = MagicMock()
        self.bot.delete_message = MagicMock()

        from bot.state import StateManager
        self.state = StateManager()
        self.engine = MagicMock()
        self.fb_client = MagicMock()
        self.access_mgr = create_test_access_manager()

        from bot.handlers import register_handlers
        register_handlers(
            bot=self.bot,
            engine=self.engine,
            state=self.state,
            fb_client=self.fb_client,
            access_mgr=self.access_mgr,
        )

    def test_convs_command_requires_facebook_login(self):
        # Register user in access control so _check_auth passes
        chat_id = 999123
        self.access_mgr.add_user(actor_id=self.access_mgr.owner_id, target_id=chat_id, role="user")

        msg = MagicMock()
        msg.chat.id = chat_id
        msg.from_user = telebot.types.User(chat_id, False, "TestUser", username="testuser")
        msg.text = "/convs"

        for handler in self.bot.message_handlers:
            commands = handler.get("filters", {}).get("commands")
            if commands and "convs" in commands:
                handler["function"](msg)
                break

        self.bot.reply_to.assert_called_once()
        args, _ = self.bot.reply_to.call_args
        self.assertIn("LOGIN FIRST", args[1])

    def test_convs_command_fetches_pages_when_logged_in(self):
        chat_id = 888123
        self.access_mgr.add_user(actor_id=self.access_mgr.owner_id, target_id=chat_id, role="user")
        self.state.set_user(chat_id, {"token": "EAAB_VALID_TEST", "id": "fb_1", "name": "FB Tester"})

        msg = MagicMock()
        msg.chat.id = chat_id
        msg.from_user = telebot.types.User(chat_id, False, "TestUser", username="testuser")
        msg.text = "/convs"

        for handler in self.bot.message_handlers:
            commands = handler.get("filters", {}).get("commands")
            if commands and "convs" in commands:
                handler["function"](msg)
                break

        self.bot.send_message.assert_called()
        self.engine.run_async.assert_called_once()
        coro = self.engine.run_async.call_args[0][0]
        coro.close()


"""
Request Snapshot Tests.
Captures outgoing HTTP requests using Mock Client and compares them
against expected request structures extracted from legacy/bot.py.
All dynamic tokens and IDs are sanitized with placeholders.
"""

import json
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import httpx

from facebook.client import FacebookClient
from workers.engine import (
    DOC_ID_APPROVE,
    DOC_ID_JOIN,
    DOC_ID_MODERATOR,
    WorkerEngine,
)


class TestRequestSnapshots(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.client = FacebookClient(base_url="https://graph.facebook.com", timeout=12.0)

    def _sanitize_payload(self, payload: dict) -> dict:
        """Replaces dynamic IDs and access tokens with standardized placeholders."""
        sanitized = dict(payload)
        if "access_token" in sanitized:
            sanitized["access_token"] = "<ACCESS_TOKEN>"

        if "variables" in sanitized:
            vars_dict = json.loads(sanitized["variables"]) if isinstance(sanitized["variables"], str) else sanitized["variables"]

            def _clean_node(node):
                if isinstance(node, dict):
                    res = {}
                    for k, v in node.items():
                        if k in ("group_id", "groupID"):
                            res[k] = "<GROUP_ID>"
                        elif k in ("member", "memberID"):
                            res[k] = "<MEMBER_ID>"
                        elif k == "actor_id":
                            res[k] = "<ACTOR_ID>"
                        else:
                            res[k] = _clean_node(v)
                    return res
                return node

            sanitized["variables"] = _clean_node(vars_dict)

        return sanitized

    async def test_snapshot_request_1_verify_token(self):
        """Captures Request #1 (/me) and verifies method, endpoint, and token presence."""
        captured = {}

        async def mock_get(url, **kwargs):
            captured["method"] = "GET"
            captured["url"] = url
            captured["headers"] = kwargs.get("headers", {})
            captured["timeout"] = kwargs.get("timeout")
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            resp.json.return_value = {"id": "1000987654321", "name": "Snapshot User"}
            return resp

        with patch("httpx.AsyncClient.get", side_effect=mock_get):
            await self.client.verify_token("test_secret_token_12345")

        self.assertEqual(captured["method"], "GET")
        self.assertEqual(captured["url"], "https://graph.facebook.com/me")
        self.assertIn("Authorization", captured["headers"])
        self.assertTrue(captured["headers"]["Authorization"].startswith("Bearer "))

    async def test_snapshot_request_2_get_pages(self):
        """Captures Request #2 (/me/accounts) and verifies method, endpoint, and parameters."""
        captured = {}

        async def mock_get(url, **kwargs):
            captured["method"] = "GET"
            captured["url"] = url
            captured["headers"] = kwargs.get("headers", {})
            captured["timeout"] = kwargs.get("timeout")
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            resp.json.return_value = {
                "data": [
                    {"id": "page_123", "name": "My Page", "access_token": "page_tok_abc"}
                ]
            }
            return resp

        with patch("httpx.AsyncClient.get", side_effect=mock_get):
            await self.client.get_pages("test_secret_token_12345", limit=500)

        self.assertEqual(captured["method"], "GET")
        self.assertTrue(captured["url"].startswith("https://graph.facebook.com/me/accounts"))
        self.assertIn("fields=name,access_token", captured["url"])
        self.assertIn("limit=500", captured["url"])
        self.assertIn("Authorization", captured["headers"])

    async def test_snapshot_request_3_graphql_join(self):
        """Captures Request #3 (/graphql Join) and verifies exact legacy doc_id and payload structure."""
        captured = {}
        mock_http = MagicMock(spec=httpx.AsyncClient)

        async def mock_post(url, **kwargs):
            captured["method"] = "POST"
            captured["url"] = url
            captured["data"] = kwargs.get("data", {})
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            resp.text = '{"data": {"join_status": "MEMBER"}}'
            resp.json.return_value = {"data": {"join_status": "MEMBER"}}
            return resp

        mock_http.post = AsyncMock(side_effect=mock_post)

        variables = {"input": {"group_id": "999888777"}}
        await self.client.execute_graphql_request(
            client=mock_http,
            doc_id=DOC_ID_JOIN,
            variables=variables,
            token="test_tok_join",
            op_type="join",
        )

        sanitized = self._sanitize_payload(captured["data"])

        self.assertEqual(captured["method"], "POST")
        self.assertEqual(captured["url"], "https://graph.facebook.com/graphql")
        self.assertEqual(sanitized["doc_id"], "33243444848636579")
        self.assertEqual(sanitized["access_token"], "<ACCESS_TOKEN>")
        self.assertEqual(sanitized["variables"], {"input": {"group_id": "<GROUP_ID>"}})

    async def test_snapshot_request_4_graphql_approve(self):
        """Captures Request #4 (/graphql Approve) and verifies exact legacy doc_id and payload structure."""
        captured = {}
        mock_http = MagicMock(spec=httpx.AsyncClient)

        async def mock_post(url, **kwargs):
            captured["method"] = "POST"
            captured["url"] = url
            captured["data"] = kwargs.get("data", {})
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            resp.text = '{"data": {"success": true}}'
            resp.json.return_value = {"data": {"success": True}}
            return resp

        mock_http.post = AsyncMock(side_effect=mock_post)

        variables = {
            "groupID": "grp_100",
            "memberID": "mem_200",
            "input": {
                "group_id": "grp_100",
                "member": "mem_200",
                "actor_id": "actor_300",
            },
            "scale": 1,
        }
        await self.client.execute_graphql_request(
            client=mock_http,
            doc_id=DOC_ID_APPROVE,
            variables=variables,
            token="test_tok_approve",
            op_type="approve",
        )

        sanitized = self._sanitize_payload(captured["data"])

        self.assertEqual(captured["method"], "POST")
        self.assertEqual(captured["url"], "https://graph.facebook.com/graphql")
        self.assertEqual(sanitized["doc_id"], "26744408605191970")
        self.assertEqual(sanitized["access_token"], "<ACCESS_TOKEN>")
        expected_vars = {
            "groupID": "<GROUP_ID>",
            "memberID": "<MEMBER_ID>",
            "input": {
                "group_id": "<GROUP_ID>",
                "member": "<MEMBER_ID>",
                "actor_id": "<ACTOR_ID>",
            },
            "scale": 1,
        }
        self.assertEqual(sanitized["variables"], expected_vars)

    async def test_snapshot_request_5_graphql_moderator(self):
        """Captures Request #5 (/graphql Moderator) and verifies exact legacy doc_id and payload structure."""
        captured = {}
        mock_http = MagicMock(spec=httpx.AsyncClient)

        async def mock_post(url, **kwargs):
            captured["method"] = "POST"
            captured["url"] = url
            captured["data"] = kwargs.get("data", {})
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            resp.text = '{"data": {"success": true}}'
            resp.json.return_value = {"data": {"success": True}}
            return resp

        mock_http.post = AsyncMock(side_effect=mock_post)

        variables = {
            "input": {
                "client_mutation_id": "2",
                "actor_id": "act_500",
                "admin_type": "MODERATOR",
                "group_id": "grp_600",
                "source": "COMET_GROUP_PAGE",
            },
            "inviteShortLinkKey": None,
            "scale": 1,
            "__relay_internal__pv__GroupsCometGroupChatLazyLoadLastMessageSnippetrelayprovider": False,
        }
        await self.client.execute_graphql_request(
            client=mock_http,
            doc_id=DOC_ID_MODERATOR,
            variables=variables,
            token="test_tok_mod",
            op_type="moderator",
        )

        sanitized = self._sanitize_payload(captured["data"])

        self.assertEqual(captured["method"], "POST")
        self.assertEqual(captured["url"], "https://graph.facebook.com/graphql")
        self.assertEqual(sanitized["doc_id"], "25320459267654690")
        self.assertEqual(sanitized["access_token"], "<ACCESS_TOKEN>")
        expected_vars = {
            "input": {
                "client_mutation_id": "2",
                "actor_id": "<ACTOR_ID>",
                "admin_type": "MODERATOR",
                "group_id": "<GROUP_ID>",
                "source": "COMET_GROUP_PAGE",
            },
            "inviteShortLinkKey": None,
            "scale": 1,
            "__relay_internal__pv__GroupsCometGroupChatLazyLoadLastMessageSnippetrelayprovider": False,
        }
        self.assertEqual(sanitized["variables"], expected_vars)


if __name__ == "__main__":
    unittest.main()

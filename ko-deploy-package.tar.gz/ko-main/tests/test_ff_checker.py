"""
Comprehensive Unit and Integration Tests for the Independent FF Checker Tool.
Validates extraction, scope selection, public Graph API classification,
isolated directory management, thread-safe persistence, cancellation,
Telegram UI handlers, privacy guarantees, and non-regression.
Zero network requests are sent.
"""

import asyncio
import os
import shutil
import tempfile
import threading
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import httpx
import telebot
from telebot import types

from access.testing import create_test_access_manager
from bot.handlers import register_handlers
from bot.keyboards import get_main_menu
from bot.state import (
    S_AUTH,
    S_INPUT_FF_FILE,
    S_FF_WAIT_SCOPE,
    S_MENU,
    StateManager,
)
from facebook.client import MockFacebookClient
from facebook.models import OperationStatus
from tools.ff_checker import (
    FFCheckResult,
    FFCheckerEngine,
    FFStatus,
    check_single_id,
    extract_c_user_ids,
    load_checked_ids,
    record_checked_ids,
)
from workers.engine import WorkerEngine


class TestExtractCUserIds(unittest.TestCase):
    def test_extract_c_user_regex(self):
        sample = (
            "sb=123; datr=abc; c_user=1000000001; xs=xyz;\n"
            "fr=foo; c_user=1000000002; presence=bar\n"
        )
        ids, total_lines = extract_c_user_ids(sample)
        self.assertEqual(ids, ["1000000001", "1000000002"])
        self.assertEqual(total_lines, 2)

    def test_order_preserving_and_deduplication(self):
        sample = (
            "c_user=1001; extra=1\n"
            "c_user=1002; extra=2\n"
            "c_user=1001; duplicate=true\n"
            "c_user=1003; extra=3\n"
            "c_user=1002; duplicate=true\n"
        )
        ids, total_lines = extract_c_user_ids(sample)
        self.assertEqual(ids, ["1001", "1002", "1003"])
        self.assertEqual(total_lines, 5)

    def test_raw_numeric_ids_fallback(self):
        sample = (
            "1000123456\n"
            "61585015127256\n"
            "invalid_text\n"
            "c_user=1000999999\n"
        )
        ids, total_lines = extract_c_user_ids(sample)
        self.assertEqual(ids, ["1000123456", "61585015127256", "1000999999"])
        self.assertEqual(total_lines, 4)

    def test_empty_and_garbage_input(self):
        ids, total_lines = extract_c_user_ids("")
        self.assertEqual(ids, [])
        self.assertEqual(total_lines, 0)

        garbage = "   \n\n### COMMENTS ###\nnot_a_cookie\n"
        ids2, total_lines2 = extract_c_user_ids(garbage)
        self.assertEqual(ids2, [])
        self.assertEqual(total_lines2, 4)


class TestCheckedFilePersistence(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.checked_file = os.path.join(self.test_dir, "checked.txt")

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_load_nonexistent_returns_empty(self):
        loaded = load_checked_ids(self.checked_file)
        self.assertEqual(loaded, set())

    def test_record_and_load_checked_ids(self):
        record_checked_ids(["101", "102"], self.checked_file)
        loaded = load_checked_ids(self.checked_file)
        self.assertEqual(loaded, {"101", "102"})

        record_checked_ids(["103", "101"], self.checked_file)
        loaded2 = load_checked_ids(self.checked_file)
        self.assertEqual(loaded2, {"101", "102", "103"})

    def test_thread_safe_concurrent_records(self):
        def worker(start_id: int):
            batch = [str(start_id + i) for i in range(20)]
            record_checked_ids(batch, self.checked_file)

        threads = [threading.Thread(target=worker, args=(i * 100,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        loaded = load_checked_ids(self.checked_file)
        self.assertEqual(len(loaded), 100)


class TestCheckSingleId(unittest.IsolatedAsyncioTestCase):
    async def test_confirmed_profile_picture(self):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": {"height": 50, "width": 50, "is_silhouette": False, "url": "https://fb.com/pic.jpg"}
        }

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.get.return_value = mock_resp

        res = await check_single_id(mock_client, "10001")
        self.assertEqual(res.status, FFStatus.CONFIRMED)
        self.assertFalse(res.is_silhouette)
        self.assertIn("height=50", res.details)

        # Verify zero access tokens sent in url or params
        mock_client.get.assert_called_once()
        args, kwargs = mock_client.get.call_args
        self.assertIn("https://graph.facebook.com/10001/picture", args[0])
        self.assertEqual(kwargs.get("params"), {"redirect": "false"})
        self.assertNotIn("access_token", kwargs.get("params", {}))

    async def test_invalid_code_803(self):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 400
        mock_resp.json.return_value = {
            "error": {"message": "(#803) Some of the aliases you requested do not exist: non_exist", "code": 803}
        }

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.get.return_value = mock_resp

        res = await check_single_id(mock_client, "999999999999")
        self.assertEqual(res.status, FFStatus.INVALID)
        self.assertIn("803", res.details)

    async def test_rate_limited_429(self):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 429

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.get.return_value = mock_resp

        res = await check_single_id(mock_client, "10002")
        self.assertEqual(res.status, FFStatus.RATE_LIMITED)

    async def test_unknown_status_or_payload(self):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"data": {}}  # No height or url

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.get.return_value = mock_resp

        res = await check_single_id(mock_client, "10003")
        self.assertEqual(res.status, FFStatus.UNKNOWN)

    async def test_network_timeout(self):
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.get.side_effect = httpx.TimeoutException("Read timed out")

        res = await check_single_id(mock_client, "10004")
        self.assertEqual(res.status, FFStatus.NETWORK_ERROR)
        self.assertIn("Timeout", res.details)

    async def test_network_connect_error(self):
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.get.side_effect = httpx.ConnectError("Failed to resolve host")

        res = await check_single_id(mock_client, "10005")
        self.assertEqual(res.status, FFStatus.NETWORK_ERROR)
        self.assertIn("Connection", res.details)


class TestFFCheckerEngineExecution(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN", threaded=False)
        self.bot.send_message = MagicMock()
        self.bot.edit_message_text = MagicMock()
        self.bot.send_document = MagicMock()
        self.state = StateManager()
        self.engine = FFCheckerEngine(
            bot=self.bot,
            state=self.state,
            base_dir=self.test_dir,
            concurrency=2,
        )

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    async def test_execute_task_full_pipeline(self):
        chat_id = 777
        self.state.acquire_task_lock(chat_id)

        # Mock check_single_id to return deterministic results
        async def mock_checker(client, uid, timeout=6.0):
            if uid == "101":
                return FFCheckResult(uid, FFStatus.CONFIRMED, details="height=50")
            elif uid == "102":
                return FFCheckResult(uid, FFStatus.INVALID, details="Code 803")
            else:
                return FFCheckResult(uid, FFStatus.UNKNOWN, details="HTTP 500")

        with patch("tools.ff_checker.check_single_id", side_effect=mock_checker):
            await self.engine.execute_task(
                chat_id=chat_id,
                ids_to_check=["101", "102", "103"],
                skipped_count=2,
                total_lines=5,
                initial_msg_id=50,
            )

        # Verify task lock released and state returned to S_MENU
        self.assertFalse(self.state.is_task_running(chat_id))
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

        # Verify files generated in isolated dir
        run_dir = os.path.join(self.test_dir, "runs", str(chat_id))
        input_file = os.path.join(run_dir, "input.txt")
        output_file = os.path.join(run_dir, "output.txt")
        checked_file = os.path.join(self.test_dir, "checked.txt")

        self.assertTrue(os.path.exists(input_file))
        self.assertTrue(os.path.exists(output_file))
        self.assertTrue(os.path.exists(checked_file))

        # Check input.txt contains IDs only (strictly no cookies)
        with open(input_file, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f]
            self.assertEqual(lines, ["101", "102", "103"])

        # Check output.txt
        with open(output_file, "r", encoding="utf-8") as f:
            out_content = f.read()
            self.assertIn("101 | CONFIRMED", out_content)
            self.assertIn("102 | INVALID", out_content)
            self.assertIn("103 | UNKNOWN", out_content)

        # Check checked.txt updated
        checked_set = load_checked_ids(checked_file)
        self.assertTrue({"101", "102", "103"}.issubset(checked_set))

        # Check document sent to user
        self.bot.send_document.assert_called_once()
        call_args, call_kwargs = self.bot.send_document.call_args
        self.assertEqual(call_args[0], chat_id)
        self.assertIn("FF Checker", call_kwargs.get("caption", ""))

    async def test_execute_task_cancellation(self):
        chat_id = 888
        self.state.acquire_task_lock(chat_id)

        # Simulate stop flag being set after first ID
        async def mock_checker(client, uid, timeout=6.0):
            self.state.set_stop_flag(chat_id, True)
            return FFCheckResult(uid, FFStatus.CONFIRMED, details="height=50")

        with patch("tools.ff_checker.check_single_id", side_effect=mock_checker):
            await self.engine.execute_task(
                chat_id=chat_id,
                ids_to_check=["201", "202", "203"],
                skipped_count=0,
                total_lines=3,
                initial_msg_id=60,
            )

        self.assertFalse(self.state.is_task_running(chat_id))
        # Final message must reflect cancellation
        self.bot.edit_message_text.assert_called()
        last_edit = self.bot.edit_message_text.call_args[0][0]
        self.assertIn("تم إيقاف الفحص", last_edit)

    async def test_shared_concurrency_limiter_across_multiple_user_tasks(self):
        """
        Verifies that concurrency limit is shared across concurrent tasks from different users:
        - Simulates two separate users launching checking tasks concurrently
        - Total concurrent requests across BOTH users must never exceed the configured limit
        - Concurrency is configurable and dynamically adjustable
        """
        concurrency_limit = 2
        engine = FFCheckerEngine(
            bot=self.bot,
            state=self.state,
            base_dir=self.test_dir,
            concurrency=concurrency_limit,
        )

        user1_id = 9001
        user2_id = 9002
        self.state.acquire_task_lock(user1_id)
        self.state.acquire_task_lock(user2_id)

        user1_ids = [f"101_{i}" for i in range(8)]
        user2_ids = [f"202_{i}" for i in range(8)]

        active_concurrent_requests = 0
        max_observed_concurrent = 0
        counter_lock = asyncio.Lock()

        async def mock_checker_with_delay(client, uid, timeout=6.0):
            nonlocal active_concurrent_requests, max_observed_concurrent
            async with counter_lock:
                active_concurrent_requests += 1
                if active_concurrent_requests > max_observed_concurrent:
                    max_observed_concurrent = active_concurrent_requests

            # Simulate network request delay so tasks overlap
            await asyncio.sleep(0.03)

            async with counter_lock:
                active_concurrent_requests -= 1

            return FFCheckResult(uid, FFStatus.CONFIRMED, details="height=50")

        with patch("tools.ff_checker.check_single_id", side_effect=mock_checker_with_delay):
            task1 = engine.execute_task(
                chat_id=user1_id,
                ids_to_check=user1_ids,
                skipped_count=0,
                total_lines=len(user1_ids),
                initial_msg_id=101,
            )
            task2 = engine.execute_task(
                chat_id=user2_id,
                ids_to_check=user2_ids,
                skipped_count=0,
                total_lines=len(user2_ids),
                initial_msg_id=202,
            )
            # Run both user tasks concurrently
            await asyncio.gather(task1, task2)

        # Assert total concurrent requests across both users NEVER exceeded concurrency_limit
        self.assertLessEqual(max_observed_concurrent, concurrency_limit)
        self.assertGreater(max_observed_concurrent, 0)
        self.assertLessEqual(engine.limiter.peak, concurrency_limit)

        # Verify configurable limit adjustment
        engine.set_concurrency(4)
        self.assertEqual(engine.concurrency, 4)
        self.assertEqual(engine.limiter.limit, 4)


class TestFFCheckerTelegramHandlers(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN", threaded=False)
        self.state = StateManager()
        self.mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        self.engine = WorkerEngine(bot=self.bot, fb_client=self.mock_fb, state=self.state)
        self.ff_engine = FFCheckerEngine(
            bot=self.bot,
            state=self.state,
            base_dir=self.test_dir,
            concurrency=2,
        )

        self.access_mgr = create_test_access_manager()
        register_handlers(
            bot=self.bot,
            engine=self.engine,
            state=self.state,
            fb_client=self.mock_fb,
            ff_checker_engine=self.ff_engine,
            access_mgr=self.access_mgr,
        )

        self.bot.send_message = MagicMock(side_effect=lambda *a, **k: self._make_msg("mock", 10001))
        self.bot.edit_message_text = MagicMock(return_value=True)
        self.bot.delete_message = MagicMock(return_value=True)
        self.bot.reply_to = MagicMock(side_effect=lambda *a, **k: self._make_msg("mock_reply", 10001))
        self.bot.answer_callback_query = MagicMock(return_value=True)
        self.bot.get_file = MagicMock()
        self.bot.download_file = MagicMock()

    def tearDown(self):
        if hasattr(self, "access_mgr") and self.access_mgr:
            self.access_mgr.cleanup()
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def _make_msg(self, text: str = "", chat_id: int = 10001, document=None) -> types.Message:
        msg = types.Message(
            message_id=10,
            from_user=types.User(chat_id, False, "TestUser"),
            date=1700000000,
            chat=types.Chat(chat_id, "private"),
            content_type="document" if document else "text",
            options={},
            json_string="",
        )
        msg.text = text
        msg.document = document
        return msg

    def _make_cb(self, data: str, chat_id: int = 10001, message_id: int = 20) -> types.CallbackQuery:
        cb = types.CallbackQuery(
            id="cb_1",
            from_user=types.User(chat_id, False, "TestUser"),
            data=data,
            chat_instance="ci_1",
            json_string="",
        )
        cb.message = self._make_msg("", chat_id)
        cb.message.message_id = message_id
        return cb

    def test_menu_button_initiates_flow(self):
        msg = self._make_msg("🔎 FF CHECKER", 10001)
        self.bot.process_new_messages([msg])

        self.assertEqual(self.state.get_state(10001), S_INPUT_FF_FILE)
        self.bot.send_message.assert_called()
        sent_text = self.bot.send_message.call_args[0][1]
        self.assertIn("FF CHECKER", sent_text)

    def test_menu_button_blocked_when_task_running(self):
        self.state.acquire_task_lock(10001)
        msg = self._make_msg("🔎 FF CHECKER", 10001)
        self.bot.process_new_messages([msg])

        self.bot.reply_to.assert_called()
        self.assertIn("قيد التشغيل بالفعل", self.bot.reply_to.call_args[0][1])

    def test_receive_invalid_document_extension(self):
        self.state.set_state(10001, S_INPUT_FF_FILE)
        doc = MagicMock()
        doc.file_name = "data.pdf"
        doc.file_size = 1024
        msg = self._make_msg(chat_id=10001, document=doc)

        self.bot.process_new_messages([msg])
        self.bot.reply_to.assert_called()
        self.assertIn("غير مدعومة", self.bot.reply_to.call_args[0][1])

    def test_receive_oversized_file(self):
        self.state.set_state(10001, S_INPUT_FF_FILE)
        doc = MagicMock()
        doc.file_name = "huge.txt"
        doc.file_size = 15 * 1024 * 1024  # 15MB > 10MB
        msg = self._make_msg(chat_id=10001, document=doc)

        self.bot.process_new_messages([msg])
        self.bot.reply_to.assert_called()
        self.assertIn("كبير جداً", self.bot.reply_to.call_args[0][1])

    def test_receive_empty_or_no_c_user(self):
        self.state.set_state(10001, S_INPUT_FF_FILE)
        msg = self._make_msg("no cookies here at all", 10001)

        self.bot.process_new_messages([msg])
        self.bot.reply_to.assert_called()
        self.assertIn("لم يتم العثور على أي معرفات", self.bot.reply_to.call_args[0][1])
        self.assertEqual(self.state.get_state(10001), S_INPUT_FF_FILE)

    def test_receive_valid_text_triggers_scope_prompt(self):
        self.state.set_state(10001, S_INPUT_FF_FILE)
        content = "c_user=1001; foo=bar\nc_user=1002; baz=qux"
        msg = self._make_msg(content, 10001)

        self.bot.process_new_messages([msg])
        self.assertEqual(self.state.get_state(10001), S_FF_WAIT_SCOPE)
        self.bot.send_message.assert_called()
        sent_text = self.bot.send_message.call_args[0][1]
        self.assertIn("هل تريد تخطي الـIDs التي تم فحصها سابقًا؟", sent_text)
        data = self.state.get_data(10001)
        self.assertEqual(data.get("ff_ids"), ["1001", "1002"])
        self.assertEqual(data.get("ff_total_lines"), 2)

    def test_scope_skip_checked_all_previously_checked(self):
        checked_file = os.path.join(self.test_dir, "checked.txt")
        record_checked_ids(["1001", "1002"], checked_file)

        self.state.set_state(10001, S_FF_WAIT_SCOPE)
        self.state.init_operation_data(10001, "ff_checker")
        self.state.set_data(10001, "ff_ids", ["1001", "1002"])
        self.state.set_data(10001, "ff_total_lines", 2)

        cb = self._make_cb("ff_scope:skip_checked", 10001)
        self.bot.process_new_callback_query([cb])

        self.bot.edit_message_text.assert_called()
        self.assertIn("تم فحصها سابقًا", self.bot.edit_message_text.call_args[0][0])
        self.assertEqual(self.state.get_state(10001), S_MENU)
        self.assertFalse(self.state.is_task_running(10001))

    def test_scope_skip_checked_partial_and_launch(self):
        checked_file = os.path.join(self.test_dir, "checked.txt")
        record_checked_ids(["1001"], checked_file)

        self.state.set_state(10001, S_FF_WAIT_SCOPE)
        self.state.init_operation_data(10001, "ff_checker")
        self.state.set_data(10001, "ff_ids", ["1001", "1002"])
        self.state.set_data(10001, "ff_total_lines", 2)

        with patch.object(self.engine, "run_async") as mock_run_async:
            mock_run_async.side_effect = lambda coro, *a, **k: coro.close()
            cb = self._make_cb("ff_scope:skip_checked", 10001)
            self.bot.process_new_callback_query([cb])

            self.assertTrue(self.state.is_task_running(10001))
            mock_run_async.assert_called_once()

    def test_scope_check_all_launches(self):
        self.state.set_state(10001, S_FF_WAIT_SCOPE)
        self.state.init_operation_data(10001, "ff_checker")
        self.state.set_data(10001, "ff_ids", ["1001", "1002"])
        self.state.set_data(10001, "ff_total_lines", 2)

        with patch.object(self.engine, "run_async") as mock_run_async:
            mock_run_async.side_effect = lambda coro, *a, **k: coro.close()
            cb = self._make_cb("ff_scope:check_all", 10001)
            self.bot.process_new_callback_query([cb])

            self.assertTrue(self.state.is_task_running(10001))
            mock_run_async.assert_called_once()

    def test_stop_callback_sets_stop_flag(self):
        self.state.acquire_task_lock(10001)
        cb = self._make_cb("ff_stop", 10001)
        self.bot.process_new_callback_query([cb])

        self.assertTrue(self.state.is_stopped(10001))
        self.bot.answer_callback_query.assert_called_with(cb.id, "🛑 جاري إيقاف الفحص بأمان...")

    def test_cancel_callback_resets_to_menu(self):
        self.state.set_state(10001, S_INPUT_FF_FILE)
        cb = self._make_cb("ff_cancel", 10001)
        self.bot.process_new_callback_query([cb])

        self.assertEqual(self.state.get_state(10001), S_MENU)
        self.bot.send_message.assert_called()
        self.assertIn("تم إلغاء عملية فحص FF", self.bot.send_message.call_args[0][1])


if __name__ == "__main__":
    unittest.main()

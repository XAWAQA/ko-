"""
Production Preflight Mock Smoke Test.
Simulates full end-to-end bot workflows without contacting real external services.
"""

import unittest
from unittest.mock import MagicMock, patch
import telebot

from bot.state import S_AUTH, S_MENU, StateManager
from facebook.client import MockFacebookClient
from facebook.models import OperationStatus
from workers.engine import WorkerEngine


class TestProductionSmoke(unittest.IsolatedAsyncioTestCase):
    """End-to-end smoke test of all user flows using simulated mock components."""

    def setUp(self):
        self.state = StateManager()
        self.mock_bot = MagicMock(spec=telebot.TeleBot)
        dummy_msg = MagicMock()
        dummy_msg.message_id = 8888
        self.mock_bot.send_message.return_value = dummy_msg
        self.mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)

    async def test_full_pipeline_smoke(self):
        """Exercises Auth -> Pages -> Join -> Approve -> Moderator -> Terminate -> Disconnect."""
        chat_id = 99901
        engine = WorkerEngine(bot=self.mock_bot, fb_client=self.mock_fb, state=self.state)

        # 1. New User Session Initialization
        self.state.disconnect(chat_id)
        self.assertEqual(self.state.get_state(chat_id), S_AUTH)
        self.assertFalse(self.state.has_user(chat_id))

        # 2. Authentication Flow
        user_info = await self.mock_fb.verify_token("mock_test_token_smoke")
        self.state.set_user(chat_id, {"token": user_info.token, "id": user_info.id, "name": user_info.name})
        self.state.set_state(chat_id, S_MENU)
        self.assertTrue(self.state.has_user(chat_id))
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

        # 3. Fetch Pages
        pages = await self.mock_fb.get_pages(user_info.token)
        self.assertGreater(len(pages), 0)

        # 4. Connect Groups Pipeline (Join)
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "actors", [{"id": p.id, "name": p.name, "token": p.token} for p in pages])
        self.state.set_data(chat_id, "targets", ["smoke_grp_1", "smoke_grp_2"])
        await engine.process_async(chat_id, speed=4)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

        # 5. Approve Members Pipeline
        self.state.init_operation_data(chat_id, "approve")
        self.state.set_data(chat_id, "app_groups", ["smoke_grp_A", "smoke_grp_B"])
        self.state.set_data(chat_id, "app_members", ["smoke_mem_1", "smoke_mem_2"])
        await engine.process_async(chat_id, speed=2)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

        # 6. Moderator Approval Pipeline
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["smoke_mod_1", "smoke_mod_2", "smoke_mod_3"])
        await engine.process_async(chat_id, speed=3)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

        # 7. Disconnect and Session Purge
        self.state.disconnect(chat_id)
        self.assertFalse(self.state.has_user(chat_id))
        self.assertIsNone(self.state.get_user(chat_id))
        self.assertEqual(self.state.get_data(chat_id), {})
        self.assertEqual(self.state.get_state(chat_id), S_AUTH)


if __name__ == "__main__":
    unittest.main()

"""
Runtime Behavior Parity Tests.
Compares behavioral execution, state transitions, task generation,
GraphQL payloads, retry logic, and cleanup between legacy/bot.py and app.py/modular components.
Strictly offline: all Facebook interactions are mocked.
"""

import json
import unittest
from unittest.mock import MagicMock
import telebot

from bot.state import (
    S_AUTH,
    S_INPUT_APP_GROUPS,
    S_INPUT_APP_MEMBERS,
    S_INPUT_JOIN,
    S_INPUT_MOD_GROUPS,
    S_MENU,
    StateManager,
)
from facebook.client import MockFacebookClient
from facebook.models import OperationStatus
from workers.engine import (
    DOC_ID_APPROVE,
    DOC_ID_JOIN,
    DOC_ID_MODERATOR,
    WorkerEngine,
)
from workers.progress import make_final_report


class TestLegacyBehaviorParity(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.state = StateManager()
        self.mock_bot = MagicMock(spec=telebot.TeleBot)
        dummy_msg = MagicMock()
        dummy_msg.message_id = 999
        self.mock_bot.send_message.return_value = dummy_msg

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1. Start & Authentication Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_start_and_authentication(self):
        """Verifies state transitions and credential storage on Start and Login."""
        chat_id = 11101

        # A) Start for new user
        # Legacy: users_db.pop(chat_id, None), user_state[chat_id] = S_AUTH
        legacy_db = {}
        legacy_state = {chat_id: 0}  # S_AUTH

        # Modular:
        self.state.disconnect(chat_id)
        self.assertFalse(self.state.has_user(chat_id))
        self.assertEqual(self.state.get_state(chat_id), S_AUTH)
        self.assertEqual(self.state.get_state(chat_id), legacy_state[chat_id])

        # B) Authentication with valid token
        token = "mock_valid_user_token_abc"
        mock_api_data = {"id": "1000987654", "name": "Commander Node"}

        # Legacy logic (lines 175-181)
        legacy_db[chat_id] = {"token": token, "id": mock_api_data["id"], "name": mock_api_data["name"]}
        legacy_state[chat_id] = 1  # S_MENU

        # Modular logic
        self.state.set_user(chat_id, {"token": token, "id": mock_api_data["id"], "name": mock_api_data["name"]})
        self.state.set_state(chat_id, S_MENU)

        # Compare State & Data Parity
        modular_user = self.state.get_user(chat_id)
        self.assertEqual(modular_user["id"], legacy_db[chat_id]["id"])
        self.assertEqual(modular_user["name"], legacy_db[chat_id]["name"])
        self.assertEqual(modular_user["token"], legacy_db[chat_id]["token"])
        self.assertEqual(self.state.get_state(chat_id), legacy_state[chat_id])

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 2. Connect Groups - Main Profile Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_connect_groups_main_profile_task_plan(self):
        """Verifies Main Profile actor setup, target IDs, and task plan generation."""
        chat_id = 11102
        user_info = {"token": "user_tok_123", "id": "user_id_456", "name": "Main Profile User"}
        self.state.set_user(chat_id, user_info)

        # Target group IDs
        targets = ["group_101", "group_102", "group_103"]

        # Legacy task queue generation (lines 414-417)
        legacy_actors = [{"id": user_info["id"], "name": user_info["name"], "token": user_info["token"]}]
        legacy_queue = []
        for t in targets:
            for a in legacy_actors:
                legacy_queue.append({"target": t, "act_id": a["id"], "token": a["token"]})

        # Modular task queue generation
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "actors", legacy_actors)
        self.state.set_data(chat_id, "targets", targets)

        modular_data = self.state.get_data(chat_id)
        modular_queue = []
        for t in modular_data.get("targets", []):
            for a in modular_data.get("actors", []):
                modular_queue.append({"target": t, "act_id": a["id"], "token": a["token"]})

        # Compare Plan Parity
        self.assertEqual(len(modular_queue), len(legacy_queue))
        self.assertEqual(len(modular_queue), 3)
        for mod_task, leg_task in zip(modular_queue, legacy_queue):
            self.assertEqual(mod_task["target"], leg_task["target"])
            self.assertEqual(mod_task["act_id"], leg_task["act_id"])
            self.assertEqual(mod_task["token"], leg_task["token"])

        # Compare GraphQL doc_id and payload
        for item in modular_queue:
            mod_payload = {
                "access_token": item["token"],
                "variables": json.dumps({"input": {"group_id": str(item["target"])}}),
                "doc_id": DOC_ID_JOIN,
            }
            leg_payload = {
                "access_token": item["token"],
                "variables": json.dumps({"input": {"group_id": str(item["target"])}}),
                "doc_id": "33243444848636579",
            }
            self.assertEqual(mod_payload, leg_payload)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 3. Connect Groups - Fan Pages Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_connect_groups_fan_pages_task_plan(self):
        """Verifies Fan Pages multi-actor Cartesian product task plan generation."""
        chat_id = 11103
        pages = [
            {"id": "page_A", "name": "Brand A", "token": "page_tok_A"},
            {"id": "page_B", "name": "Brand B", "token": "page_tok_B"},
        ]
        targets = ["target_grp_1", "target_grp_2"]

        # Legacy task queue (lines 414-417)
        legacy_queue = []
        for t in targets:
            for a in pages:
                legacy_queue.append({"target": t, "act_id": a["id"], "token": a["token"]})

        # Modular task queue
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "actors", pages)
        self.state.set_data(chat_id, "targets", targets)

        data = self.state.get_data(chat_id)
        modular_queue = []
        for t in data["targets"]:
            for a in data["actors"]:
                modular_queue.append({"target": t, "act_id": a["id"], "token": a["token"]})

        # Parity check: 2 targets * 2 pages = 4 tasks
        self.assertEqual(len(modular_queue), len(legacy_queue))
        self.assertEqual(len(modular_queue), 4)
        for m, l in zip(modular_queue, legacy_queue):
            self.assertEqual(m, l)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 4. Approve Members Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_approve_members_task_plan(self):
        """Verifies Approve Members queue generation, doc_id, and variables."""
        chat_id = 11104
        user_info = {"token": "admin_tok", "id": "admin_999", "name": "Admin Node"}
        self.state.set_user(chat_id, user_info)

        app_groups = ["group_X", "group_Y"]
        app_members = ["member_1", "member_2", "member_3"]

        # Legacy queue (lines 418-421)
        legacy_queue = []
        for grp in app_groups:
            for mem in app_members:
                legacy_queue.append({"target": grp, "mem_id": mem})

        # Modular queue
        self.state.init_operation_data(chat_id, "approve")
        self.state.set_data(chat_id, "app_groups", app_groups)
        self.state.set_data(chat_id, "app_members", app_members)

        data = self.state.get_data(chat_id)
        modular_queue = []
        for grp in data["app_groups"]:
            for mem in data["app_members"]:
                modular_queue.append({"target": grp, "mem_id": mem})

        # Parity check: 2 groups * 3 members = 6 tasks
        self.assertEqual(len(modular_queue), 6)
        self.assertEqual(modular_queue, legacy_queue)

        # Verify exact GraphQL payload structure
        for item in modular_queue:
            expected_vars = json.dumps({
                "groupID": str(item["target"]),
                "memberID": str(item["mem_id"]),
                "input": {
                    "group_id": str(item["target"]),
                    "member": str(item["mem_id"]),
                    "actor_id": str(user_info["id"]),
                },
                "scale": 1,
            })
            self.assertEqual(DOC_ID_APPROVE, "26744408605191970")
            mod_vars = json.dumps({
                "groupID": str(item["target"]),
                "memberID": str(item["mem_id"]),
                "input": {
                    "group_id": str(item["target"]),
                    "member": str(item["mem_id"]),
                    "actor_id": str(user_info["id"]),
                },
                "scale": 1,
            })
            self.assertEqual(mod_vars, expected_vars)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 5. Moderator Approval Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_moderator_approval_task_plan(self):
        """Verifies Moderator Approval queue generation, doc_id, and variables."""
        chat_id = 11105
        user_info = {"token": "mod_tok", "id": "mod_user_888", "name": "Mod Admin"}
        self.state.set_user(chat_id, user_info)

        mod_groups = ["group_M1", "group_M2", "group_M3"]

        # Legacy queue (lines 422-424)
        legacy_queue = [{"target": grp} for grp in mod_groups]

        # Modular queue
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", mod_groups)

        data = self.state.get_data(chat_id)
        modular_queue = [{"target": grp} for grp in data["mod_groups"]]

        self.assertEqual(len(modular_queue), 3)
        self.assertEqual(modular_queue, legacy_queue)
        self.assertEqual(DOC_ID_MODERATOR, "25320459267654690")

        for item in modular_queue:
            expected_vars = json.dumps({
                "input": {
                    "client_mutation_id": "2",
                    "actor_id": str(user_info["id"]),
                    "admin_type": "MODERATOR",
                    "group_id": str(item["target"]),
                    "source": "COMET_GROUP_PAGE",
                },
                "inviteShortLinkKey": None,
                "scale": 1,
                "__relay_internal__pv__GroupsCometGroupChatLazyLoadLastMessageSnippetrelayprovider": False,
            })
            mod_vars = json.dumps({
                "input": {
                    "client_mutation_id": "2",
                    "actor_id": str(user_info["id"]),
                    "admin_type": "MODERATOR",
                    "group_id": str(item["target"]),
                    "source": "COMET_GROUP_PAGE",
                },
                "inviteShortLinkKey": None,
                "scale": 1,
                "__relay_internal__pv__GroupsCometGroupChatLazyLoadLastMessageSnippetrelayprovider": False,
            })
            self.assertEqual(mod_vars, expected_vars)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 6. Stop / Terminate Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_parity_stop_terminate(self):
        """Verifies cancellation signal halts remaining tasks immediately."""
        chat_id = 11106
        self.state.set_user(chat_id, {"token": "tok", "id": "u", "name": "Stop User"})
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", [f"grp_{i}" for i in range(10)])

        mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        call_tracker = []

        async def intercept_execute(*args, **kwargs):
            call_tracker.append(1)
            # Signal termination after 2 tasks
            if len(call_tracker) == 2:
                self.state.set_stop_flag(chat_id, True)
            return await MockFacebookClient.execute_graphql_request(mock_fb, *args, **kwargs)

        mock_fb.execute_graphql_request = intercept_execute

        engine = WorkerEngine(bot=self.mock_bot, fb_client=mock_fb, state=self.state)
        await engine.process_async(chat_id, speed=1)

        # Verified: tasks halted after stop flag, total executed is less than 10
        self.assertLess(len(call_tracker), 10)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 7. Disconnect & Cleanup Scenario Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_disconnect_cleanup(self):
        """Verifies complete session purge and state reset to S_AUTH on Disconnect."""
        chat_id = 11107
        self.state.set_user(chat_id, {"token": "secret_token_to_purge", "id": "user_777", "name": "Purge Node"})
        self.state.set_state(chat_id, S_INPUT_JOIN)
        self.state.set_data(chat_id, "targets", ["grp1", "grp2"])
        self.state.set_stop_flag(chat_id, True)

        # Trigger Disconnect
        self.state.disconnect(chat_id)

        # Check clean state
        self.assertFalse(self.state.has_user(chat_id))
        self.assertIsNone(self.state.get_user(chat_id))
        self.assertEqual(self.state.get_data(chat_id), {})
        self.assertFalse(self.state.is_stopped(chat_id))
        self.assertEqual(self.state.get_state(chat_id), S_AUTH)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 8. Success, Failure, and Retry Handling Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_parity_retry_and_error_handling(self):
        """Verifies retry on 429/timeout and break on 400/403."""
        chat_id = 11108
        self.state.set_user(chat_id, {"token": "retry_tok", "id": "u_ret", "name": "Retry Node"})
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["grp_retry"])

        # Test retry recovery
        mock_fb = MockFacebookClient(
            simulated_status=OperationStatus.RATE_LIMIT,
            should_succeed_after_retry=True
        )
        engine = WorkerEngine(bot=self.mock_bot, fb_client=mock_fb, state=self.state)
        await engine.process_async(chat_id, speed=1)

        self.assertGreaterEqual(mock_fb.call_count, 2)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 9. Final Report Structure Parity
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_parity_final_report_metrics(self):
        """Verifies final report contains all legacy report metrics."""
        stats = {"done": 40, "ok": 38, "bad": 2, "retried": 5}
        report = make_final_report(stats=stats, elapsed=8, num_clients=4)

        self.assertIn("MISSION ACCOMPLISHED", report)
        self.assertIn("PROCESSED: `40`", report)
        self.assertIn("SUCCESS: `38`", report)
        self.assertIn("FAILED: `2`", report)
        self.assertIn("RETRIED: `5`", report)
        self.assertIn("TIME: `8s`", report)
        self.assertIn("AVG SPEED: `5.0 req/s`", report)
        self.assertIn("CLIENTS: `4`", report)


if __name__ == "__main__":
    unittest.main()

"""
Tests for WorkerEngine execution, retry logic, cancellation, and MockFacebookClient.
"""

import asyncio
import unittest
from unittest.mock import MagicMock
import telebot

from bot.state import S_MENU, StateManager
from facebook.client import MockFacebookClient
from facebook.models import OperationStatus
from workers.engine import WorkerEngine


class TestWorkerEngine(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.mock_bot = MagicMock(spec=telebot.TeleBot)
        # Mock bot messages to return a dummy message with message_id
        dummy_msg = MagicMock()
        dummy_msg.message_id = 1234
        self.mock_bot.send_message.return_value = dummy_msg
        self.state = StateManager()

    async def test_successful_worker_run_with_mock_client(self):
        """Phase 15: Runs full worker pipeline safely with MockFacebookClient (SUCCESS)."""
        chat_id = 1001
        self.state.set_user(chat_id, {"token": "mock_token", "id": "user_1", "name": "Test Node"})
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", ["grp1", "grp2"])
        self.state.set_data(chat_id, "actors", [{"id": "user_1", "name": "Test Node", "token": "mock_token"}])

        mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        engine = WorkerEngine(bot=self.mock_bot, fb_client=mock_fb, state=self.state)

        await engine.process_async(chat_id, speed=5)

        self.assertEqual(self.state.get_state(chat_id), S_MENU)
        self.assertEqual(mock_fb.call_count, 2)  # 2 targets * 1 actor
        self.mock_bot.send_message.assert_called()

    async def test_cancellation_during_run(self):
        """Verifies cancellation flag stops remaining tasks during execution."""
        chat_id = 1002
        self.state.set_user(chat_id, {"token": "mock_token", "id": "user_2", "name": "Cancel Node"})
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["grp1", "grp2", "grp3", "grp4", "grp5"])

        mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        original_execute = mock_fb.execute_graphql_request

        async def cancel_on_first_call(*args, **kwargs):
            # User sends TERMINATE signal during run
            self.state.set_stop_flag(chat_id, True)
            return await original_execute(*args, **kwargs)

        mock_fb.execute_graphql_request = cancel_on_first_call

        engine = WorkerEngine(bot=self.mock_bot, fb_client=mock_fb, state=self.state)
        await engine.process_async(chat_id, speed=1)

        # After cancellation was triggered, not all 5 tasks should have executed
        self.assertLess(mock_fb.call_count, 5)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

    async def test_retry_logic_succeeds_after_initial_retry(self):
        """Verifies retry mechanism retries and succeeds if subsequent attempt succeeds."""
        chat_id = 1003
        self.state.set_user(chat_id, {"token": "mock_token", "id": "user_3", "name": "Retry Node"})
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["grp1"])

        # Fails first with RATE_LIMIT, succeeds on attempt 2
        mock_fb = MockFacebookClient(
            simulated_status=OperationStatus.RATE_LIMIT,
            should_succeed_after_retry=True
        )
        engine = WorkerEngine(bot=self.mock_bot, fb_client=mock_fb, state=self.state)

        await engine.process_async(chat_id, speed=1)

        self.assertGreaterEqual(mock_fb.call_count, 2)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

    async def test_mock_client_statuses(self):
        """Phase 15: Verifies mock client can simulate various statuses without real requests."""
        statuses = [
            OperationStatus.RATE_LIMIT,
            OperationStatus.AUTH_ERROR,
            OperationStatus.SERVER_ERROR,
            OperationStatus.TIMEOUT,
        ]
        chat_id = 2000
        self.state.set_user(chat_id, {"token": "mock_token", "id": "user_x", "name": "Status Node"})

        for st in statuses:
            self.state.init_operation_data(chat_id, "moderator")
            self.state.set_data(chat_id, "mod_groups", ["grp_test"])

            mock_fb = MockFacebookClient(simulated_status=st)
            engine = WorkerEngine(bot=self.mock_bot, fb_client=mock_fb, state=self.state)

            await engine.process_async(chat_id, speed=1)
            self.assertEqual(self.state.get_state(chat_id), S_MENU)


if __name__ == "__main__":
    unittest.main()

"""
Comprehensive Telegram Handlers Trace and Edge-Case Tests.
Tests all button texts, callbacks, document uploads, invalid inputs,
cancellation, and error handling branches using TeleBot mocks.
Zero network requests are sent.
"""

import json
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import telebot
from telebot import types

from access.testing import create_test_access_manager
from bot.handlers import register_handlers
from bot.keyboards import (
    get_confirm_buttons,
    get_main_menu,
    get_pages_list,
    get_source_buttons,
    get_speed_buttons,
)
from bot.state import (
    S_ADMIN_ADD_ID,
    S_ADMIN_SEARCH,
    S_AUTH,
    S_INPUT_APP_GROUPS,
    S_INPUT_APP_MEMBERS,
    S_INPUT_FF_FILE,
    S_INPUT_JOIN,
    S_INPUT_MOD_GROUPS,
    S_MENU,
    StateManager,
)
from facebook.client import MockFacebookClient
from facebook.models import FacebookPage, FacebookUser, OperationStatus
from workers.engine import WorkerEngine


class TestTelegramHandlersExhaustive(unittest.TestCase):
    def setUp(self):
        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN_FOR_TESTS", threaded=False)
        self.state = StateManager()
        self.mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        self.engine = WorkerEngine(bot=self.bot, fb_client=self.mock_fb, state=self.state)
        self.access_mgr = create_test_access_manager()
        # Register handlers onto this bot instance with explicit test access manager
        register_handlers(
            bot=self.bot,
            engine=self.engine,
            state=self.state,
            fb_client=self.mock_fb,
            access_mgr=self.access_mgr,
        )

        # Mock outbound bot methods to capture calls without network
        self.bot.send_message = MagicMock(side_effect=lambda *args, **kwargs: self._make_message("mock_response", 10001))
        self.bot.edit_message_text = MagicMock(return_value=True)
        self.bot.edit_message_reply_markup = MagicMock(return_value=True)
        self.bot.delete_message = MagicMock(return_value=True)
        self.bot.reply_to = MagicMock(side_effect=lambda *args, **kwargs: self._make_message("mock_reply", 10001))
        self.bot.answer_callback_query = MagicMock(return_value=True)
        self.bot.get_file = MagicMock()
        self.bot.download_file = MagicMock()

    def tearDown(self):
        if hasattr(self, "access_mgr") and self.access_mgr:
            self.access_mgr.cleanup()

    def _make_message(self, text: str = "", chat_id: int = 10001, document=None) -> types.Message:
        msg = types.Message(
            message_id=10,
            from_user=types.User(chat_id, False, "TestUser"),
            date=1700000000,
            chat=types.Chat(chat_id, "private"),
            content_type="document" if document else "text",
            options={},
            json_string="",
        )
        msg.text = text
        msg.document = document
        return msg

    def _make_callback(self, data: str, chat_id: int = 10001, message_id: int = 20) -> types.CallbackQuery:
        cb = types.CallbackQuery(
            id="cb_123",
            from_user=types.User(chat_id, False, "TestUser"),
            data=data,
            chat_instance="ci_1",
            json_string="",
        )
        cb.message = self._make_message("", chat_id)
        cb.message.message_id = message_id
        return cb

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1. /start and DISCONNECT
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_start_unauthenticated_prompts_token(self):
        msg = self._make_message("/start", 10001)
        self.bot.process_new_messages([msg])

        self.assertFalse(self.state.has_user(10001))
        self.assertEqual(self.state.get_state(10001), S_AUTH)
        self.bot.send_message.assert_called_with(
            10001,
            "🔐 **ENTER ACCESS TOKEN:**",
            parse_mode="Markdown",
            reply_markup=unittest.mock.ANY,
        )

    def test_start_authenticated_welcomes_user(self):
        self.state.set_user(10001, {"token": "tok", "id": "u1", "name": "Alice"})
        self.state.set_state(10001, S_MENU)

        msg = self._make_message("/start", 10001)
        self.bot.process_new_messages([msg])

        self.assertEqual(self.state.get_state(10001), S_MENU)
        args, kwargs = self.bot.send_message.call_args
        self.assertIn("Welcome back, **Alice**", args[1])

    def test_disconnect_button_purges_session(self):
        self.state.set_user(10001, {"token": "tok", "id": "u1", "name": "Alice"})
        self.state.set_state(10001, S_MENU)

        msg = self._make_message("🔌 DISCONNECT", 10001)
        self.bot.process_new_messages([msg])

        self.assertFalse(self.state.has_user(10001))
        self.assertEqual(self.state.get_state(10001), S_AUTH)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 2. Login & Token Validation
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_login_invalid_token_format(self):
        self.state.set_state(10002, S_AUTH)
        msg = self._make_message("short", 10002)
        self.bot.process_new_messages([msg])

        args, kwargs = self.bot.send_message.call_args
        self.assertIn("INVALID TOKEN FORMAT", args[1])
        self.assertEqual(self.state.get_state(10002), S_AUTH)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 3. Main Menu Buttons Authentication Guard
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_unauthenticated_buttons_require_login(self):
        # Without logging in:
        for btn_text in ["⚡ CONNECT GROUPS", "🛡️ APPROVE MEMBERS", "👑 MODERATOR APPROVAL"]:
            msg = self._make_message(btn_text, 10003)
            self.bot.process_new_messages([msg])
            self.bot.reply_to.assert_called_with(msg, "❌ **LOGIN FIRST!**", parse_mode="Markdown")

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 4. Moderator Approval Trace
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_moderator_approval_flow_text_and_empty_guard(self):
        chat_id = 10004
        self.state.set_user(chat_id, {"token": "tok", "id": "u4", "name": "Mod Admin"})
        self.state.set_state(chat_id, S_MENU)

        # 1. Click button
        msg = self._make_message("👑 MODERATOR APPROVAL", chat_id)
        self.bot.process_new_messages([msg])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_MOD_GROUPS)

        # 2. Send empty / whitespace input
        msg_empty = self._make_message("   \n\n  ", chat_id)
        self.bot.process_new_messages([msg_empty])
        self.bot.reply_to.assert_called_with(msg_empty, "❌ EMPTY LIST!")

        # 3. Send valid group IDs
        msg_groups = self._make_message("100001\n100002\n100003", chat_id)
        self.bot.process_new_messages([msg_groups])
        data = self.state.get_data(chat_id)
        self.assertEqual(data.get("mod_groups"), ["100001", "100002", "100003"])

    def test_moderator_approval_document_upload(self):
        chat_id = 10005
        self.state.set_user(chat_id, {"token": "tok", "id": "u5", "name": "Mod Admin"})
        self.state.set_state(chat_id, S_INPUT_MOD_GROUPS)

        doc = types.Document("doc_1", "file_uid_1", None, "groups.txt", "text/plain", 100)
        self.bot.get_file.return_value = types.File("doc_1", "file_uid_1", 100, "documents/groups.txt")
        self.bot.download_file.return_value = b"99901\n99902\n99903\n"

        msg_doc = self._make_message("", chat_id, document=doc)
        self.bot.process_new_messages([msg_doc])

        data = self.state.get_data(chat_id)
        self.assertEqual(data.get("mod_groups"), ["99901", "99902", "99903"])

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 5. Connect Groups Flow & Callbacks
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_connect_groups_source_selection_main_profile(self):
        chat_id = 10006
        self.state.set_user(chat_id, {"token": "u_tok", "id": "u_id", "name": "Profile Owner"})
        self.state.set_state(chat_id, S_MENU)

        # 1. Click CONNECT GROUPS
        msg = self._make_message("⚡ CONNECT GROUPS", chat_id)
        self.bot.process_new_messages([msg])

        # 2. Callback src_me
        cb = self._make_callback("src_me", chat_id)
        self.bot.process_new_callback_query([cb])

        self.assertEqual(self.state.get_state(chat_id), S_INPUT_JOIN)
        data = self.state.get_data(chat_id)
        self.assertEqual(data.get("op"), "join")
        self.assertEqual(len(data.get("actors", [])), 1)
        self.assertEqual(data["actors"][0]["id"], "u_id")

        # 3. Send target group IDs
        msg_targets = self._make_message("grp_alpha\ngrp_beta", chat_id)
        self.bot.process_new_messages([msg_targets])
        data = self.state.get_data(chat_id)
        self.assertEqual(data.get("targets"), ["grp_alpha", "grp_beta"])

    def test_pages_toggle_and_done_select_validation(self):
        chat_id = 10007
        self.state.set_user(chat_id, {"token": "u_tok", "id": "u_id", "name": "Page Owner"})
        pages = [
            {"id": "p1", "name": "Page 1", "token": "tok1"},
            {"id": "p2", "name": "Page 2", "token": "tok2"},
        ]
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "all_pages", pages)
        self.state.set_data(chat_id, "selected_pages", [])

        # 1. Click done_select with 0 pages selected -> guard alerts user
        cb_done_empty = self._make_callback("done_select", chat_id)
        self.bot.process_new_callback_query([cb_done_empty])
        self.bot.answer_callback_query.assert_called_with("cb_123", "SELECT AT LEAST ONE NODE!")

        # 2. Toggle page 1
        cb_toggle_p1 = self._make_callback("pg:p1", chat_id)
        self.bot.process_new_callback_query([cb_toggle_p1])
        self.assertEqual(self.state.get_data(chat_id)["selected_pages"], ["p1"])

        # 3. Toggle all
        cb_toggle_all = self._make_callback("toggle_all", chat_id)
        self.bot.process_new_callback_query([cb_toggle_all])
        self.assertEqual(self.state.get_data(chat_id)["selected_pages"], ["p1", "p2"])

        # 4. Done select with selected pages
        cb_done = self._make_callback("done_select", chat_id)
        self.bot.process_new_callback_query([cb_done])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_JOIN)
        actors = self.state.get_data(chat_id).get("actors", [])
        self.assertEqual(len(actors), 2)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 6. Approve Members Flow
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_approve_members_step_transitions(self):
        chat_id = 10008
        self.state.set_user(chat_id, {"token": "tok", "id": "u8", "name": "Approve Admin"})
        self.state.set_state(chat_id, S_MENU)

        # 1. Click APPROVE MEMBERS
        msg = self._make_message("🛡️ APPROVE MEMBERS", chat_id)
        self.bot.process_new_messages([msg])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_APP_GROUPS)

        # 2. Send Groups
        msg_grps = self._make_message("grp_1\ngrp_2", chat_id)
        self.bot.process_new_messages([msg_grps])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_APP_MEMBERS)
        self.assertEqual(self.state.get_data(chat_id)["app_groups"], ["grp_1", "grp_2"])

        # 3. Send Members
        msg_mems = self._make_message("mem_1\nmem_2\nmem_3", chat_id)
        self.bot.process_new_messages([msg_mems])
        self.assertEqual(self.state.get_data(chat_id)["app_members"], ["mem_1", "mem_2", "mem_3"])

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 7. Speed Briefing and Abort / Cancel Run
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_speed_briefing_and_cancel_run(self):
        chat_id = 10009
        self.state.set_user(chat_id, {"token": "tok", "id": "u9", "name": "User"})
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", ["g1", "g2"])

        # 1. Select speed 50
        cb_spd = self._make_callback("spd:50", chat_id)
        self.bot.process_new_callback_query([cb_spd])

        args, kwargs = self.bot.send_message.call_args
        self.assertIn("MISSION BRIEFING", args[1])
        self.assertIn("TOTAL OPS: `2`", args[1])
        self.assertIn("CONCURRENCY: `50 simultaneous`", args[1])

        # 2. Cancel run
        cb_cancel = self._make_callback("cancel_run", chat_id)
        self.bot.process_new_callback_query([cb_cancel])
        args, kwargs = self.bot.send_message.call_args
        self.assertIn("MISSION ABORTED", args[1])

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 8. System Info and Terminate Buttons
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_system_info_and_terminate(self):
        chat_id = 10010
        self.state.set_user(chat_id, {"token": "tok", "id": "u10", "name": "User Dashboard"})
        self.state.set_state(chat_id, S_MENU)

        # 1. System Info
        msg_info = self._make_message("📟 SYSTEM INFO", chat_id)
        self.bot.process_new_messages([msg_info])
        self.bot.reply_to.assert_called_with(msg_info, unittest.mock.ANY, parse_mode="Markdown")
        reply_text = self.bot.reply_to.call_args[0][1]
        self.assertIn("SYSTEM DASHBOARD", reply_text)
        self.assertIn("User Dashboard", reply_text)

        # 2. Terminate
        msg_term = self._make_message("🚫 TERMINATE", chat_id)
        self.bot.process_new_messages([msg_term])
        self.assertTrue(self.state.is_stopped(chat_id))
        self.bot.reply_to.assert_called_with(msg_term, "⚠️ **TERMINATION SIGNAL SENT**")
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 9. State Trap Immunity and Cross-Menu Navigation
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_moderator_approval_input_escape_to_ff_checker(self):
        """
        Regression test: When in S_INPUT_MOD_GROUPS, clicking '🔎 FF CHECKER'
        must switch to FF Checker without returning '❌ EMPTY LIST!' or trapping the user.
        """
        chat_id = 10011
        self.state.set_user(chat_id, {"token": "tok", "id": "u11", "name": "Mod Tester"})
        self.state.set_state(chat_id, S_MENU)

        # 1. Click MODERATOR APPROVAL -> state becomes S_INPUT_MOD_GROUPS
        msg_mod = self._make_message("👑 MODERATOR APPROVAL", chat_id)
        self.bot.process_new_messages([msg_mod])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_MOD_GROUPS)

        # 2. Click FF CHECKER -> must immediately route to FF Checker, clearing mod_groups
        msg_ff = self._make_message("🔎 FF CHECKER", chat_id)
        self.bot.reply_to.reset_mock()
        self.bot.send_message.reset_mock()
        self.bot.process_new_messages([msg_ff])

        # State must now be S_INPUT_FF_FILE
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_FF_FILE)
        # Verify reply_to was NOT called with EMPTY LIST
        for call_item in self.bot.reply_to.call_args_list:
            reply_text = call_item[0][1] if len(call_item[0]) > 1 else ""
            self.assertNotIn("EMPTY LIST", reply_text)

        # Verify FF Checker welcome message was sent
        sent_messages = [call_item[0][1] for call_item in self.bot.send_message.call_args_list]
        self.assertTrue(any("FF CHECKER" in m for m in sent_messages))

    def test_moderator_approval_input_escape_to_user_management(self):
        """
        Regression test: When in S_INPUT_MOD_GROUPS, clicking '👥 USER MANAGEMENT' / '👥 إدارة المستخدمين'
        must switch to User Management without returning '❌ EMPTY LIST!'.
        """
        chat_id = 10012
        # Make user an admin in access_mgr
        self.access_mgr.add_user(actor_id=self.access_mgr.owner_id, target_id=chat_id, role="admin")
        self.state.set_user(chat_id, {"token": "tok", "id": "u12", "name": "Admin Tester"})
        self.state.set_state(chat_id, S_INPUT_MOD_GROUPS)

        # Click User Management
        msg_um = self._make_message("👥 إدارة المستخدمين", chat_id)
        self.bot.reply_to.reset_mock()
        self.bot.send_message.reset_mock()
        self.bot.process_new_messages([msg_um])

        # Verify no EMPTY LIST
        for call_item in self.bot.reply_to.call_args_list:
            reply_text = call_item[0][1] if len(call_item[0]) > 1 else ""
            self.assertNotIn("EMPTY LIST", reply_text)

        sent_messages = [call_item[0][1] for call_item in self.bot.send_message.call_args_list]
        self.assertTrue(any("إدارة المستخدمين" in m for m in sent_messages))

    def test_moderator_approval_input_escape_to_stop_task(self):
        """
        Regression test: When in S_INPUT_MOD_GROUPS, clicking '⏹️ STOP TASK' or '🚫 TERMINATE'
        must trigger stop and reset state to S_MENU without returning '❌ EMPTY LIST!'.
        """
        chat_id = 10013
        self.state.set_user(chat_id, {"token": "tok", "id": "u13", "name": "Stop Tester"})
        self.state.set_state(chat_id, S_INPUT_MOD_GROUPS)

        msg_stop = self._make_message("⏹️ STOP TASK", chat_id)
        self.bot.reply_to.reset_mock()
        self.bot.process_new_messages([msg_stop])

        self.assertTrue(self.state.is_stopped(chat_id))
        self.assertEqual(self.state.get_state(chat_id), S_MENU)
        reply_text = self.bot.reply_to.call_args[0][1]
        self.assertIn("TERMINATION SIGNAL SENT", reply_text)

    def test_invalid_input_retries_and_then_escapes_cleanly(self):
        """
        When actual invalid data is sent in S_INPUT_MOD_GROUPS, user receives '❌ EMPTY LIST!'
        and stays in S_INPUT_MOD_GROUPS to retry, but navigation buttons escape immediately.
        """
        chat_id = 10014
        self.state.set_user(chat_id, {"token": "tok", "id": "u14", "name": "Retry Tester"})
        self.state.set_state(chat_id, S_INPUT_MOD_GROUPS)

        # 1. Invalid input: whitespace/blank
        msg_invalid = self._make_message("   ", chat_id)
        self.bot.process_new_messages([msg_invalid])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_MOD_GROUPS)
        self.bot.reply_to.assert_called_with(msg_invalid, "❌ EMPTY LIST!")

        # 2. Escape via FF CHECKER button
        msg_ff = self._make_message("🔎 FF CHECKER", chat_id)
        self.bot.process_new_messages([msg_ff])
        self.assertEqual(self.state.get_state(chat_id), S_INPUT_FF_FILE)

    def test_all_input_states_immune_to_navigation_capture(self):
        """
        Tests that navigation buttons escape cleanly from all input states:
        S_INPUT_JOIN, S_INPUT_APP_GROUPS, S_INPUT_APP_MEMBERS, S_INPUT_FF_FILE,
        S_ADMIN_ADD_ID, S_ADMIN_SEARCH, S_AUTH.
        """
        chat_id = 10015
        self.access_mgr.add_user(actor_id=self.access_mgr.owner_id, target_id=chat_id, role="admin")
        self.state.set_user(chat_id, {"token": "tok", "id": "u15", "name": "All States Tester"})

        input_states = [
            S_INPUT_JOIN,
            S_INPUT_APP_GROUPS,
            S_INPUT_APP_MEMBERS,
            S_INPUT_FF_FILE,
            S_ADMIN_ADD_ID,
            S_ADMIN_SEARCH,
            S_AUTH,
        ]

        for st in input_states:
            self.state.set_state(chat_id, st)
            # Pressing STOP TASK must always escape to S_MENU and never trigger input error
            msg_stop = self._make_message("⏹️ STOP TASK", chat_id)
            self.bot.reply_to.reset_mock()
            self.bot.process_new_messages([msg_stop])
            self.assertEqual(self.state.get_state(chat_id), S_MENU, f"Failed escaping from state {st}")
            self.assertTrue(self.state.is_stopped(chat_id))

    def test_ff_checker_accessible_without_facebook_login(self):
        """
        Authorized user with NO Facebook session can directly use FF CHECKER.
        """
        chat_id = 10016
        # Ensure user is registered in access_mgr, but has NO Facebook session in state
        self.access_mgr.add_user(actor_id=self.access_mgr.owner_id, target_id=chat_id, role="user")
        self.assertFalse(self.state.has_user(chat_id))

        # 1. Click FF CHECKER
        msg = self._make_message("🔎 FF CHECKER", chat_id)
        self.bot.process_new_messages([msg])

        self.assertEqual(self.state.get_state(chat_id), S_INPUT_FF_FILE)
        args, kwargs = self.bot.send_message.call_args
        self.assertIn("FF CHECKER", args[1])

        # 2. Upload cookie text
        msg_cookie = self._make_message("c_user=1000999888; xs=abc", chat_id)
        self.bot.process_new_messages([msg_cookie])
        self.assertEqual(self.state.get_data(chat_id).get("ff_ids"), ["1000999888"])

    def test_button_aliases_support(self):
        """
        Tests that both modern and legacy button aliases work interchangeably.
        """
        chat_id = 10017
        self.state.set_user(chat_id, {"token": "tok", "id": "u17", "name": "Alias Tester"})
        self.state.set_state(chat_id, S_MENU)

        # 1. '🔗 CONNECT GROUPS' and '⚡ CONNECT GROUPS'
        msg_join1 = self._make_message("🔗 CONNECT GROUPS", chat_id)
        self.bot.process_new_messages([msg_join1])
        self.assertIn("SELECT UPLINK SOURCE", self.bot.send_message.call_args[0][1])

        msg_join2 = self._make_message("⚡ CONNECT GROUPS", chat_id)
        self.bot.process_new_messages([msg_join2])
        self.assertIn("SELECT UPLINK SOURCE", self.bot.send_message.call_args[0][1])

        # 2. '📊 SYSTEM STATUS' and '📟 SYSTEM INFO'
        msg_sys1 = self._make_message("📊 SYSTEM STATUS", chat_id)
        self.bot.process_new_messages([msg_sys1])
        self.assertIn("SYSTEM DASHBOARD", self.bot.reply_to.call_args[0][1])

        msg_sys2 = self._make_message("📟 SYSTEM INFO", chat_id)
        self.bot.process_new_messages([msg_sys2])
        self.assertIn("SYSTEM DASHBOARD", self.bot.reply_to.call_args[0][1])

        # 3. '⏹️ STOP TASK' and '🚫 TERMINATE'
        msg_stop1 = self._make_message("⏹️ STOP TASK", chat_id)
        self.bot.process_new_messages([msg_stop1])
        self.assertTrue(self.state.is_stopped(chat_id))

        msg_stop2 = self._make_message("🚫 TERMINATE", chat_id)
        self.bot.process_new_messages([msg_stop2])
        self.assertTrue(self.state.is_stopped(chat_id))


if __name__ == "__main__":
    unittest.main()

"""
Unit and Integration Tests for System Resilience and Edge Cases.
Validates:
1. Double-click and concurrent run protection on confirmation buttons.
2. Immediate, safe stop/cancellation during worker execution with lock release.
3. Token expiration handling (HTTP 401 and GraphQL OAuth code 190).
4. Network failure handling (ConnectError, TimeoutException) with retry classification.
5. Unexpected GraphQL responses ({}, {"data": null}, malformed non-JSON).
6. Clear distinction between True Success and Assumed Success (already member).
7. Log sanitizer masking tokens and credentials.

ALL TESTS ARE 100% OFFLINE AND MOCKED. ZERO EXTERNAL NETWORK REQUESTS.
"""

import asyncio
import json
import logging
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import httpx
import telebot
from telebot import types

from access.testing import create_test_access_manager
from bot.handlers import register_handlers
from bot.state import S_MENU, StateManager
from facebook.client import FacebookClient, MockFacebookClient
from facebook.models import OperationStatus, TaskResult
from utils.logging import SafeFormatter, mask_sensitive
from workers.engine import WorkerEngine


class TestResilienceAndEdgeCases(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.bot = telebot.TeleBot("123456789:MOCK_TOKEN_FOR_TESTS", threaded=False)
        self.state = StateManager()
        self.mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        self.engine = WorkerEngine(bot=self.bot, fb_client=self.mock_fb, state=self.state)
        self.access_mgr = create_test_access_manager()
        register_handlers(
            bot=self.bot,
            engine=self.engine,
            state=self.state,
            fb_client=self.mock_fb,
            access_mgr=self.access_mgr,
        )

        # Mock telebot outbound methods
        self.bot.send_message = MagicMock(return_value=types.Message(1, None, None, None, "text", {}, ""))
        self.bot.edit_message_text = MagicMock(return_value=True)
        self.bot.edit_message_reply_markup = MagicMock(return_value=True)
        self.bot.delete_message = MagicMock(return_value=True)
        self.bot.answer_callback_query = MagicMock(return_value=True)

    def tearDown(self):
        if hasattr(self, "access_mgr") and self.access_mgr:
            self.access_mgr.cleanup()

    def _make_callback(self, data: str, chat_id: int = 50001, message_id: int = 50) -> types.CallbackQuery:
        cb = types.CallbackQuery(
            id="cb_test_id",
            from_user=types.User(chat_id, False, "TestUser"),
            data=data,
            chat_instance="ci_test",
            json_string="",
        )
        msg = types.Message(
            message_id=message_id,
            from_user=types.User(chat_id, False, "TestUser"),
            date=1700000000,
            chat=types.Chat(chat_id, "private"),
            content_type="text",
            options={},
            json_string="",
        )
        msg.text = ""
        cb.message = msg
        return cb

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1. Double Click / Concurrent Run Protection
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_double_click_protection_blocks_second_execution(self):
        """Verifies rapid double-click on confirmation button starts only one worker."""
        chat_id = 50001
        self.state.set_user(chat_id, {"token": "tok", "id": "u1", "name": "User 1"})
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", ["101"])
        self.state.set_data(chat_id, "actors", [{"id": "u1", "name": "User 1", "token": "tok"}])

        with patch.object(self.engine, "run_async") as mock_run_async:
            mock_run_async.side_effect = lambda coro, cid=None: coro.close()
            cb1 = self._make_callback("confirm:100", chat_id)
            cb2 = self._make_callback("confirm:100", chat_id)

            # Trigger first click
            self.bot.process_new_callback_query([cb1])
            self.assertEqual(mock_run_async.call_count, 1)
            self.assertTrue(self.state.is_task_running(chat_id))

            # Trigger second click while task lock is held
            self.bot.process_new_callback_query([cb2])
            # Call count should STILL be 1 (second was blocked)
            self.assertEqual(mock_run_async.call_count, 1)
            self.bot.answer_callback_query.assert_called_with(
                "cb_test_id",
                "⚠️ هناك عملية قيد التشغيل بالفعل! يرجى الانتظار أو الإيقاف أولاً.",
                show_alert=True,
            )

            # Release lock and ensure subsequent click is accepted
            self.state.release_task_lock(chat_id)
            self.assertFalse(self.state.is_task_running(chat_id))

            cb3 = self._make_callback("confirm:100", chat_id)
            self.bot.process_new_callback_query([cb3])
            self.assertEqual(mock_run_async.call_count, 2)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 2. Stop / Terminate During Execution
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_stop_button_cleans_resources_and_releases_lock(self):
        """Verifies stop button halts execution immediately and releases task lock."""
        chat_id = 50002
        self.state.set_user(chat_id, {"token": "tok", "id": "u2", "name": "User 2"})
        self.state.init_operation_data(chat_id, "moderator")
        self.state.set_data(chat_id, "mod_groups", [f"grp_{i}" for i in range(20)])

        mock_fb = MockFacebookClient(simulated_status=OperationStatus.SUCCESS)
        call_count = 0

        async def execute_and_stop(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                # User triggers termination signal during run
                self.state.set_stop_flag(chat_id, True)
            return TaskResult(success=True, status=OperationStatus.SUCCESS, is_retryable=False, status_code=200)

        mock_fb.execute_graphql_request = execute_and_stop
        engine = WorkerEngine(bot=self.bot, fb_client=mock_fb, state=self.state)

        await engine.process_async(chat_id, speed=1)

        # Verified: tasks were halted before completing all 20
        self.assertLess(call_count, 20)
        # State restored to menu
        self.assertEqual(self.state.get_state(chat_id), S_MENU)
        # Task lock must be released
        self.assertFalse(self.state.is_task_running(chat_id))

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 3. Token Expiration Handling
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_token_expiration_http_401(self):
        """Verifies HTTP 401 returns non-retryable AUTH_ERROR."""
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        mock_http = MagicMock(spec=httpx.AsyncClient)
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 401
        mock_resp.text = json.dumps({"error": {"message": "Invalid OAuth access token", "code": 190}})
        mock_resp.json.return_value = json.loads(mock_resp.text)
        mock_http.post = AsyncMock(return_value=mock_resp)

        result = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="expired_tok", op_type="join"
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.AUTH_ERROR)
        self.assertFalse(result.is_retryable)

    async def test_token_expiration_graphql_code_190(self):
        """Verifies 200 OK with GraphQL error code 190 is classified as AUTH_ERROR."""
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        mock_http = MagicMock(spec=httpx.AsyncClient)
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = json.dumps({
            "errors": [
                {
                    "message": "Error validating access token: Session has expired on Monday, 06-Oct-26 01:00:00 PDT.",
                    "code": 190,
                    "error_subcode": 463
                }
            ]
        })
        mock_resp.json.return_value = json.loads(mock_resp.text)
        mock_http.post = AsyncMock(return_value=mock_resp)

        result = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="expired_tok", op_type="join"
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.AUTH_ERROR)
        self.assertFalse(result.is_retryable)
        self.assertIn("expired", result.error_message.lower())

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 4. Network Failure & Timeout Handling
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_network_connect_error_and_timeout(self):
        """Verifies network connection error and timeouts are classified as retryable."""
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        mock_http = MagicMock(spec=httpx.AsyncClient)

        # Connect Error
        mock_http.post = AsyncMock(side_effect=httpx.ConnectError("Network unreachable"))
        result_conn = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="tok", op_type="join"
        )
        self.assertFalse(result_conn.success)
        self.assertEqual(result_conn.status, OperationStatus.CONNECTION_ERROR)
        self.assertTrue(result_conn.is_retryable)

        # Timeout Exception
        mock_http.post = AsyncMock(side_effect=httpx.TimeoutException("Read timed out after 5.0s"))
        result_time = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="tok", op_type="join"
        )
        self.assertFalse(result_time.success)
        self.assertEqual(result_time.status, OperationStatus.TIMEOUT)
        self.assertTrue(result_time.is_retryable)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 5. Unexpected GraphQL Responses
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_unexpected_empty_graphql_response(self):
        """Verifies empty JSON response without errors is classified as unexpected failure."""
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        mock_http = MagicMock(spec=httpx.AsyncClient)
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = "{}"
        mock_resp.json.return_value = {}
        mock_http.post = AsyncMock(return_value=mock_resp)

        result = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="tok", op_type="approve"
        )
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.CLIENT_ERROR)
        self.assertIn("Unexpected empty", result.error_message)

    async def test_unexpected_malformed_html_response(self):
        """Verifies HTML error page or non-JSON fallback handles gracefully."""
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        mock_http = MagicMock(spec=httpx.AsyncClient)
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.text = "<html><body>502 Bad Gateway Nginx</body></html>"
        mock_resp.json.side_effect = json.JSONDecodeError("Invalid JSON", mock_resp.text, 0)
        mock_http.post = AsyncMock(return_value=mock_resp)

        result = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="tok", op_type="moderator"
        )
        # Should not crash, returns CLIENT_ERROR
        self.assertFalse(result.success)
        self.assertEqual(result.status, OperationStatus.CLIENT_ERROR)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 6. True Success vs Assumed Success Distinction
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    async def test_distinction_true_success_vs_assumed_success(self):
        """Verifies clear flag separation between true mutation success and already-member assumed success."""
        client = FacebookClient(base_url="https://graph.facebook.com", timeout=5.0)
        mock_http = MagicMock(spec=httpx.AsyncClient)

        # 1. True Success: response contains valid data block
        resp_true = MagicMock(spec=httpx.Response)
        resp_true.status_code = 200
        resp_true.text = json.dumps({"data": {"group_join": {"status": "MEMBER"}}})
        resp_true.json.return_value = json.loads(resp_true.text)
        mock_http.post = AsyncMock(return_value=resp_true)

        res_true = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="tok", op_type="join"
        )
        self.assertTrue(res_true.success)
        self.assertFalse(res_true.is_assumed_success)  # TRUE SUCCESS

        # 2. Assumed Success: code 2422002 / already a member
        resp_assumed = MagicMock(spec=httpx.Response)
        resp_assumed.status_code = 200
        resp_assumed.text = json.dumps({"errors": [{"code": 2422002, "message": "You are already a member of this group"}]})
        resp_assumed.json.return_value = json.loads(resp_assumed.text)
        mock_http.post = AsyncMock(return_value=resp_assumed)

        res_assumed = await client.execute_graphql_request(
            client=mock_http, doc_id="123", variables={}, token="tok", op_type="join"
        )
        self.assertTrue(res_assumed.success)
        self.assertTrue(res_assumed.is_assumed_success)  # ASSUMED SUCCESS

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 7. Safe Logging Masking
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def test_log_sanitizer_masks_tokens_and_headers(self):
        """Verifies mask_sensitive actively strips tokens and Bearer headers."""
        raw_msg = (
            "User EAAD6V7os0gcBSrtFZANWdxAmIT5UlOwhR7Sawc logged in with Authorization: Bearer secret_12345 "
            "bot: 1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef123"
        )
        masked = mask_sensitive(raw_msg)

        self.assertNotIn("EAAD6V7os0gcBSrtFZANWdxAmIT5UlOwhR7Sawc", masked)
        self.assertNotIn("secret_12345", masked)
        self.assertNotIn("1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef123", masked)
        self.assertIn("[REDACTED_FB_TOKEN]", masked)
        self.assertIn("[REDACTED_TOKEN]", masked)
        self.assertIn("[REDACTED_TG_TOKEN]", masked)


if __name__ == "__main__":
    unittest.main()

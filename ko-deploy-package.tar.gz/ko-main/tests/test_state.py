"""
Tests for state management and disconnect cleanup.
"""

import unittest
from bot.state import S_AUTH, S_INPUT_JOIN, S_MENU, StateManager


class TestStateManager(unittest.TestCase):
    def setUp(self):
        self.state = StateManager()

    def test_user_session_flow(self):
        """Verifies session storage and retrieval."""
        chat_id = 998877
        self.assertFalse(self.state.has_user(chat_id))
        self.assertIsNone(self.state.get_user(chat_id))

        user_info = {"token": "secret_fb_token_123", "id": "10001", "name": "Test User"}
        self.state.set_user(chat_id, user_info)

        self.assertTrue(self.state.has_user(chat_id))
        retrieved = self.state.get_user(chat_id)
        self.assertEqual(retrieved["name"], "Test User")
        self.assertEqual(retrieved["id"], "10001")

    def test_state_transitions(self):
        """Verifies state updates."""
        chat_id = 12345
        self.state.set_state(chat_id, S_AUTH)
        self.assertEqual(self.state.get_state(chat_id), S_AUTH)

        self.state.set_state(chat_id, S_MENU)
        self.assertEqual(self.state.get_state(chat_id), S_MENU)

    def test_operation_data_and_stop_flag(self):
        """Verifies operation payload storage and stop signals."""
        chat_id = 555
        self.state.init_operation_data(chat_id, "join")
        self.state.set_data(chat_id, "targets", ["grp1", "grp2"])
        data = self.state.get_data(chat_id)
        self.assertEqual(data.get("op"), "join")
        self.assertEqual(data.get("targets"), ["grp1", "grp2"])

        self.assertFalse(self.state.is_stopped(chat_id))
        self.state.set_stop_flag(chat_id, True)
        self.assertTrue(self.state.is_stopped(chat_id))

    def test_disconnect_cleanup(self):
        """Verifies full purging of credentials and session on DISCONNECT."""
        chat_id = 777
        self.state.set_user(chat_id, {"token": "sensitive_fb_token", "id": "777", "name": "Node"})
        self.state.set_state(chat_id, S_INPUT_JOIN)
        self.state.set_data(chat_id, "targets", ["1", "2"])
        self.state.set_stop_flag(chat_id, True)

        # Trigger disconnect
        self.state.disconnect(chat_id)

        self.assertFalse(self.state.has_user(chat_id))
        self.assertIsNone(self.state.get_user(chat_id))
        self.assertEqual(self.state.get_data(chat_id), {})
        self.assertFalse(self.state.is_stopped(chat_id))
        self.assertEqual(self.state.get_state(chat_id), S_AUTH)


if __name__ == "__main__":
    unittest.main()

"""
Data models and structured results for Facebook API interactions.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class OperationStatus(str, Enum):
    SUCCESS = "SUCCESS"
    RATE_LIMIT = "RATE_LIMIT"
    AUTH_ERROR = "AUTH_ERROR"
    SERVER_ERROR = "SERVER_ERROR"
    CLIENT_ERROR = "CLIENT_ERROR"
    TIMEOUT = "TIMEOUT"
    CONNECTION_ERROR = "CONNECTION_ERROR"
    INCONCLUSIVE = "INCONCLUSIVE"


@dataclass
class FacebookUser:
    id: str
    name: str
    token: str


@dataclass
class FacebookPage:
    id: str
    name: str
    token: str


@dataclass
class TaskResult:
    success: bool
    status: OperationStatus
    is_retryable: bool
    status_code: int = 0
    error_message: str = ""
    is_assumed_success: bool = False
    data: Dict[str, Any] = field(default_factory=dict)

"""
Facebook Graph API Client and Mock Implementation.
Handles HTTP/2 requests, JSON parsing, structured status classification, and retry management.
"""

import json
from typing import Any, Dict, List, Optional
import httpx

from config import GRAPH_API_BASE_URL, REQUEST_TIMEOUT
from facebook.models import FacebookPage, FacebookUser, OperationStatus, TaskResult


class FacebookClient:
    """Production client for Facebook Graph API interactions."""

    def __init__(self, base_url: str = GRAPH_API_BASE_URL, timeout: float = REQUEST_TIMEOUT) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def verify_token(self, token: str) -> FacebookUser:
        """
        Verifies access token via /me endpoint.
        Passes token securely via Authorization header to prevent query parameter leaks.
        """
        url = f"{self.base_url}/me"
        headers = {"Authorization": f"Bearer {token}"}

        async with httpx.AsyncClient(http2=True) as client:
            resp = await client.get(url, headers=headers, timeout=self.timeout)
            if resp.status_code == 200:
                data = resp.json()
                return FacebookUser(id=str(data["id"]), name=str(data.get("name", "")), token=token)
            raise ValueError(f"Token verification failed with HTTP status {resp.status_code}")

    async def get_pages(self, token: str, limit: int = 500) -> List[FacebookPage]:
        """Fetches managed pages for the account, supporting cursor pagination."""
        all_pages: List[FacebookPage] = []
        url: Optional[str] = f"{self.base_url}/me/accounts?fields=name,access_token&limit={limit}"
        headers = {"Authorization": f"Bearer {token}"}

        async with httpx.AsyncClient(http2=True) as client:
            while url:
                resp = await client.get(url, headers=headers, timeout=15.0)
                if resp.status_code == 200:
                    data = resp.json()
                    pages_data = data.get("data", [])
                    for p in pages_data:
                        all_pages.append(
                            FacebookPage(
                                id=str(p["id"]),
                                name=str(p.get("name", "Unnamed Page")),
                                token=str(p.get("access_token", token)),
                            )
                        )
                    paging = data.get("paging", {})
                    url = paging.get("next") if len(all_pages) < 5000 else None
                else:
                    if not all_pages:
                        raise ValueError(f"Fetching accounts failed with HTTP status {resp.status_code}")
                    break
        return all_pages

    async def execute_graphql_request(
        self,
        client: httpx.AsyncClient,
        doc_id: str,
        variables: Dict[str, Any],
        token: str,
        op_type: str,
    ) -> TaskResult:
        """
        Executes a single GraphQL mutation with structured response parsing.
        """
        url = f"{self.base_url}/graphql"
        payload = {
            "access_token": token,
            "variables": json.dumps(variables),
            "doc_id": doc_id,
        }

        try:
            response = await client.post(url, data=payload, timeout=self.timeout)
            status_code = response.status_code
            raw_text = response.text

            # 1. Handle HTTP Status Codes
            if status_code == 429 or "rate limit" in raw_text.lower():
                return TaskResult(
                    success=False,
                    status=OperationStatus.RATE_LIMIT,
                    is_retryable=True,
                    status_code=status_code,
                    error_message="Rate limit reached"
                )

            if status_code in (401, 403):
                return TaskResult(
                    success=False,
                    status=OperationStatus.AUTH_ERROR,
                    is_retryable=False,
                    status_code=status_code,
                    error_message=f"Authentication or permission error ({status_code})"
                )

            if status_code >= 500:
                return TaskResult(
                    success=False,
                    status=OperationStatus.SERVER_ERROR,
                    is_retryable=True,
                    status_code=status_code,
                    error_message=f"Server error ({status_code})"
                )

            if status_code == 400:
                return TaskResult(
                    success=False,
                    status=OperationStatus.CLIENT_ERROR,
                    is_retryable=False,
                    status_code=status_code,
                    error_message=f"Bad request ({status_code})"
                )

            # 2. Parse JSON Response
            try:
                data = response.json()
            except Exception:
                # If JSON parsing fails, evaluate raw text with legacy heuristics
                return self._parse_text_fallback(raw_text, op_type, status_code)

            return self._parse_json_result(data, raw_text, op_type, status_code)

        except httpx.TimeoutException as exc:
            return TaskResult(
                success=False,
                status=OperationStatus.TIMEOUT,
                is_retryable=True,
                status_code=0,
                error_message=f"Timeout: {str(exc)[:100]}"
            )
        except (httpx.ConnectError, httpx.ReadError, httpx.WriteError, httpx.PoolTimeout) as exc:
            return TaskResult(
                success=False,
                status=OperationStatus.CONNECTION_ERROR,
                is_retryable=True,
                status_code=0,
                error_message=f"Connection error: {str(exc)[:100]}"
            )
        except Exception as exc:
            return TaskResult(
                success=False,
                status=OperationStatus.CLIENT_ERROR,
                is_retryable=False,
                status_code=0,
                error_message=f"Unexpected error: {str(exc)[:100]}"
            )

    def _parse_json_result(
        self, data: Dict[str, Any], raw_text: str, op_type: str, status_code: int
    ) -> TaskResult:
        """Extracts success or structured errors from parsed JSON response."""
        errors = data.get("errors")

        if errors:
            error_codes = []
            error_msgs = []
            for err in errors:
                if isinstance(err, dict):
                    if "code" in err:
                        error_codes.append(err["code"])
                    if "message" in err:
                        error_msgs.append(err["message"])

            # 1. Token expiration check in GraphQL errors
            is_token_expired = (
                190 in error_codes
                or 102 in error_codes
                or any(
                    "session has expired" in m.lower()
                    or "error validating access token" in m.lower()
                    or "token is invalid" in m.lower()
                    for m in error_msgs
                )
            )
            if is_token_expired:
                return TaskResult(
                    success=False,
                    status=OperationStatus.AUTH_ERROR,
                    is_retryable=False,
                    status_code=status_code,
                    error_message="Access token expired or revoked (OAuth 190)",
                    data=data,
                )

            # 2. Rate limit / Action block check in GraphQL errors
            is_rate_limit = (
                any(c in (4, 17, 341, 368) for c in error_codes)
                or any(
                    "rate limit" in m.lower()
                    or "action blocked" in m.lower()
                    or "too many requests" in m.lower()
                    for m in error_msgs
                )
            )
            if is_rate_limit:
                return TaskResult(
                    success=False,
                    status=OperationStatus.RATE_LIMIT,
                    is_retryable=True,
                    status_code=status_code,
                    error_message="Meta rate limit / action block triggered",
                    data=data,
                )

            # 3. Legacy compatibility: explicit code 1341004 / 2422002 or exact "already a member" phrase
            is_already_member = (
                1341004 in error_codes
                or 2422002 in error_codes
                or any(
                    "already a member" in m.lower()
                    or "is already a member" in m.lower()
                    or "already in the group" in m.lower()
                    for m in error_msgs
                )
                or "1341004" in raw_text
                or "2422002" in raw_text
                or "already a member" in raw_text.lower()
            )

            if (op_type in ("join", "approve")) and is_already_member:
                return TaskResult(
                    success=True,
                    status=OperationStatus.SUCCESS,
                    is_retryable=False,
                    status_code=status_code,
                    is_assumed_success=True,
                    error_message="Already a member (assumed success)",
                    data=data,
                )

            err_str = "; ".join(error_msgs) if error_msgs else "GraphQL error"
            return TaskResult(
                success=False,
                status=OperationStatus.CLIENT_ERROR,
                is_retryable=False,
                status_code=status_code,
                error_message=err_str,
                data=data,
            )

        # No errors: inspect data payload strictly
        if not isinstance(data, dict) or not data:
            return TaskResult(
                success=False,
                status=OperationStatus.CLIENT_ERROR,
                is_retryable=False,
                status_code=status_code,
                error_message="Unexpected empty GraphQL response",
                data=data if isinstance(data, dict) else {},
            )

        if "data" not in data:
            return TaskResult(
                success=False,
                status=OperationStatus.INCONCLUSIVE,
                is_retryable=False,
                status_code=status_code,
                error_message="Missing data field in GraphQL response",
                data=data,
            )

        payload_data = data.get("data")
        if payload_data is None:
            return TaskResult(
                success=False,
                status=OperationStatus.INCONCLUSIVE,
                is_retryable=False,
                status_code=status_code,
                error_message="GraphQL data payload is null",
                data=data,
            )

        if isinstance(payload_data, dict):
            if not payload_data:
                return TaskResult(
                    success=False,
                    status=OperationStatus.INCONCLUSIVE,
                    is_retryable=False,
                    status_code=status_code,
                    error_message="Unexpected empty GraphQL data object",
                    data=data,
                )
            # Check if all fields in data are null (e.g. {"group_approve_member": None})
            if all(val is None for val in payload_data.values()):
                return TaskResult(
                    success=False,
                    status=OperationStatus.CLIENT_ERROR,
                    is_retryable=False,
                    status_code=status_code,
                    error_message="GraphQL mutation returned null entity",
                    data=data,
                )

        return TaskResult(
            success=True,
            status=OperationStatus.SUCCESS,
            is_retryable=False,
            status_code=status_code,
            is_assumed_success=False,
            data=data,
        )

    def _parse_text_fallback(self, raw_text: str, op_type: str, status_code: int) -> TaskResult:
        """Legacy text heuristic fallback if JSON parsing fails."""
        # Non-JSON HTML error pages (e.g. Cloudflare / Nginx 502/503 HTML)
        stripped = raw_text.strip()
        if stripped.startswith("<") or "<html" in raw_text.lower():
            return TaskResult(
                success=False,
                status=OperationStatus.SERVER_ERROR if status_code >= 500 else OperationStatus.CLIENT_ERROR,
                is_retryable=status_code >= 500,
                status_code=status_code,
                is_assumed_success=False,
                error_message="Unexpected HTML response from gateway",
            )

        if op_type == "join" and ("MEMBER" in raw_text or "already a member" in raw_text.lower() or "1341004" in raw_text):
            return TaskResult(
                success=True,
                status=OperationStatus.SUCCESS,
                is_retryable=False,
                status_code=status_code,
                is_assumed_success=True,
                data={},
            )

        # Unconfirmed arbitrary non-JSON response is inconclusive
        return TaskResult(
            success=False,
            status=OperationStatus.INCONCLUSIVE,
            is_retryable=False,
            status_code=status_code,
            is_assumed_success=False,
            error_message="Unconfirmed non-JSON response",
            data={},
        )


class MockFacebookClient(FacebookClient):
    """
    Mock Facebook Client for safe offline testing without contacting real Facebook servers.
    Can be configured to simulate SUCCESS, RATE_LIMIT, AUTH_ERROR, SERVER_ERROR, or TIMEOUT.
    """

    def __init__(
        self,
        simulated_status: OperationStatus = OperationStatus.SUCCESS,
        should_succeed_after_retry: bool = False,
        is_assumed_success: bool = False,
        custom_task_result: Optional[TaskResult] = None,
    ) -> None:
        super().__init__()
        self.simulated_status = simulated_status
        self.should_succeed_after_retry = should_succeed_after_retry
        self.is_assumed_success = is_assumed_success
        self.custom_task_result = custom_task_result
        self.call_count = 0

    async def verify_token(self, token: str) -> FacebookUser:
        if token == "invalid_token":
            raise ValueError("Invalid access token")
        return FacebookUser(id="123456789", name="Mock Test Node", token=token)

    async def get_pages(self, token: str, limit: int = 500) -> List[FacebookPage]:
        return [
            FacebookPage(id="page_1", name="Test Page 1", token="page_tok_1"),
            FacebookPage(id="page_2", name="Test Page 2", token="page_tok_2"),
        ]

    async def execute_graphql_request(
        self,
        client: httpx.AsyncClient,
        doc_id: str,
        variables: Dict[str, Any],
        token: str,
        op_type: str,
    ) -> TaskResult:
        self.call_count += 1
        if self.custom_task_result is not None:
            return self.custom_task_result

        if self.should_succeed_after_retry and self.call_count > 1:
            return TaskResult(success=True, status=OperationStatus.SUCCESS, is_retryable=False, is_assumed_success=self.is_assumed_success, status_code=200)

        if self.simulated_status == OperationStatus.SUCCESS:
            return TaskResult(success=True, status=OperationStatus.SUCCESS, is_retryable=False, is_assumed_success=self.is_assumed_success, status_code=200)
        elif self.simulated_status == OperationStatus.RATE_LIMIT:
            return TaskResult(success=False, status=OperationStatus.RATE_LIMIT, is_retryable=True, status_code=429, error_message="Rate limit")
        elif self.simulated_status == OperationStatus.AUTH_ERROR:
            return TaskResult(success=False, status=OperationStatus.AUTH_ERROR, is_retryable=False, status_code=401, error_message="Unauthorized")
        elif self.simulated_status == OperationStatus.SERVER_ERROR:
            return TaskResult(success=False, status=OperationStatus.SERVER_ERROR, is_retryable=True, status_code=500, error_message="Internal Server Error")
        elif self.simulated_status == OperationStatus.TIMEOUT:
            return TaskResult(success=False, status=OperationStatus.TIMEOUT, is_retryable=True, status_code=0, error_message="Request timed out")
        else:
            return TaskResult(success=False, status=OperationStatus.CLIENT_ERROR, is_retryable=False, status_code=400, error_message="Client error")

"""
Independent Facebook Profile (FF) Picture & ID Checker Tool.
Extracted and decoupled from legacy ff.py script.
Does NOT use, require, or send any Facebook Access Token or Telegram Bot Token.
"""

from dataclasses import dataclass
from enum import Enum
import asyncio
import os
import re
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
import httpx
import telebot
from telebot import types

from bot.keyboards import get_main_menu
from bot.state import S_MENU, StateManager, state_manager
from utils.logging import log_safe_error


class FFStatus(str, Enum):
    CONFIRMED = "CONFIRMED"          # Graph API returned valid profile picture node with height
    INVALID = "INVALID"              # Graph API returned Code 803 (Alias/ID does not exist)
    UNKNOWN = "UNKNOWN"              # Ambiguous response, unexpected status, or unconfirmed
    NETWORK_ERROR = "NETWORK_ERROR"  # Timeout, DNS failure, or connection drop
    RATE_LIMITED = "RATE_LIMITED"    # Meta rate limit (HTTP 429)


@dataclass
class FFCheckResult:
    user_id: str
    status: FFStatus
    details: str = ""
    is_silhouette: bool = False


# Directory setup for isolated runs and checked records
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_BASE_DIR = os.path.join(PROJECT_ROOT, "data", "ff_checker")
DEFAULT_CHECKED_FILE = os.path.join(DEFAULT_BASE_DIR, "checked.txt")

try:
    from config import FF_CHECKER_CONCURRENCY
    DEFAULT_CONCURRENCY = FF_CHECKER_CONCURRENCY
except ImportError:
    DEFAULT_CONCURRENCY = int(os.environ.get("FF_CHECKER_CONCURRENCY", "5"))

_checked_file_lock = threading.Lock()


def extract_c_user_ids(content: str) -> Tuple[List[str], int]:
    """
    Extracts c_user values from raw text lines.
    Deduplicates IDs while strictly preserving original order of appearance.
    Returns (unique_user_ids, total_lines).
    """
    if not content:
        return [], 0

    lines = content.splitlines()
    total_lines = len(lines)
    extracted: List[str] = []
    seen: Set[str] = set()

    for line in lines:
        cleaned = line.strip()
        if not cleaned:
            continue
        match = re.search(r"c_user=(\d+)", cleaned)
        if match:
            uid = match.group(1)
            if uid not in seen:
                seen.add(uid)
                extracted.append(uid)
        elif cleaned.isdigit() and len(cleaned) >= 4:
            uid = cleaned
            if uid not in seen:
                seen.add(uid)
                extracted.append(uid)

    return extracted, total_lines


def load_checked_ids(file_path: Optional[str] = None) -> Set[str]:
    """Loads previously checked IDs from checked.txt in a thread-safe manner."""
    path = file_path or DEFAULT_CHECKED_FILE
    if not os.path.exists(path):
        return set()

    checked: Set[str] = set()
    with _checked_file_lock:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    stripped = line.strip()
                    if stripped.isdigit():
                        checked.add(stripped)
        except Exception:
            pass
    return checked


def record_checked_ids(user_ids: List[str], file_path: Optional[str] = None) -> None:
    """Appends checked IDs to checked.txt safely with mutex protection."""
    if not user_ids:
        return

    path = file_path or DEFAULT_CHECKED_FILE
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with _checked_file_lock:
        try:
            with open(path, "a", encoding="utf-8") as f:
                for uid in user_ids:
                    f.write(f"{uid}\n")
        except Exception as exc:
            log_safe_error("record_checked_ids", exc)


async def check_single_id(
    client: httpx.AsyncClient,
    user_id: str,
    timeout: float = 6.0,
) -> FFCheckResult:
    """
    Checks Facebook profile picture node existence via public Graph API picture endpoint.
    Sends zero access tokens and zero Telegram credentials.
    """
    url = f"https://graph.facebook.com/{user_id}/picture"
    params = {"redirect": "false"}
    headers = {
        "Accept": "*/*",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
    }

    try:
        resp = await client.get(url, params=params, headers=headers, timeout=timeout)

        if resp.status_code == 200:
            try:
                body = resp.json()
                data = body.get("data", {})
                if "height" in data and "url" in data:
                    is_silhouette = bool(data.get("is_silhouette", False))
                    return FFCheckResult(
                        user_id=user_id,
                        status=FFStatus.CONFIRMED,
                        is_silhouette=is_silhouette,
                        details=f"height={data.get('height')}, silhouette={is_silhouette}",
                    )
                return FFCheckResult(
                    user_id=user_id,
                    status=FFStatus.UNKNOWN,
                    details="HTTP 200 without picture dimensions",
                )
            except Exception:
                return FFCheckResult(
                    user_id=user_id,
                    status=FFStatus.UNKNOWN,
                    details="Unparseable JSON response",
                )

        if resp.status_code in (400, 404):
            try:
                body = resp.json()
                err = body.get("error", {})
                code = err.get("code")
                msg = err.get("message", "")
                if code == 803 or "does not exist" in msg.lower():
                    return FFCheckResult(
                        user_id=user_id,
                        status=FFStatus.INVALID,
                        details=f"Code 803: Non-existent ID",
                    )
            except Exception:
                pass
            return FFCheckResult(
                user_id=user_id,
                status=FFStatus.UNKNOWN,
                details=f"HTTP {resp.status_code}",
            )

        if resp.status_code == 429:
            return FFCheckResult(
                user_id=user_id,
                status=FFStatus.RATE_LIMITED,
                details="HTTP 429 Rate Limited",
            )

        return FFCheckResult(
            user_id=user_id,
            status=FFStatus.UNKNOWN,
            details=f"HTTP {resp.status_code}",
        )

    except httpx.TimeoutException:
        return FFCheckResult(
            user_id=user_id,
            status=FFStatus.NETWORK_ERROR,
            details="Request Timeout",
        )
    except (httpx.ConnectError, httpx.ReadError, httpx.WriteError):
        return FFCheckResult(
            user_id=user_id,
            status=FFStatus.NETWORK_ERROR,
            details="Connection Error",
        )
    except Exception as exc:
        return FFCheckResult(
            user_id=user_id,
            status=FFStatus.UNKNOWN,
            details=str(exc)[:50],
        )


class SharedConcurrencyLimiter:
    """
    Thread-safe and cross-task concurrency limiter.
    Ensures that total active requests across all concurrent tasks and users
    never exceed the configured limit.
    """

    def __init__(self, limit: int = 5) -> None:
        self._limit = max(1, int(limit))
        self._current = 0
        self._peak = 0
        self._lock = threading.Lock()

    @property
    def limit(self) -> int:
        with self._lock:
            return self._limit

    @limit.setter
    def limit(self, new_limit: int) -> None:
        with self._lock:
            self._limit = max(1, int(new_limit))

    @property
    def current(self) -> int:
        with self._lock:
            return self._current

    @property
    def peak(self) -> int:
        with self._lock:
            return self._peak

    async def acquire(self) -> None:
        while True:
            with self._lock:
                if self._current < self._limit:
                    self._current += 1
                    if self._current > self._peak:
                        self._peak = self._current
                    return
            await asyncio.sleep(0.002)

    def release(self) -> None:
        with self._lock:
            if self._current > 0:
                self._current -= 1

    async def __aenter__(self) -> "SharedConcurrencyLimiter":
        await self.acquire()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        self.release()


class FFCheckerEngine:
    """Manages asynchronous batch checking tasks with isolated per-user directories and live progress."""

    def __init__(
        self,
        bot: telebot.TeleBot,
        state: StateManager = state_manager,
        base_dir: str = DEFAULT_BASE_DIR,
        concurrency: int = DEFAULT_CONCURRENCY,
        http_client_factory: Optional[Callable[[], httpx.AsyncClient]] = None,
        shared_limiter: Optional[Any] = None,
        limiter: Optional[Any] = None,
    ) -> None:
        self.bot = bot
        self.state = state
        self.base_dir = base_dir
        self.concurrency = max(1, int(concurrency))
        self.http_client_factory = http_client_factory
        active_limiter = shared_limiter or limiter
        self.limiter = active_limiter or SharedConcurrencyLimiter(limit=self.concurrency)

    def set_concurrency(self, limit: int) -> None:
        """Dynamically adjusts the concurrency limit across all running and subsequent tasks."""
        self.concurrency = max(1, int(limit))
        if hasattr(self.limiter, "limit"):
            self.limiter.limit = self.concurrency

    def get_run_dir(self, chat_id: int) -> str:
        """Returns isolated workspace directory for a user run."""
        d = os.path.join(self.base_dir, "runs", str(chat_id))
        os.makedirs(d, exist_ok=True)
        return d

    async def execute_task(
        self,
        chat_id: int,
        ids_to_check: List[str],
        skipped_count: int,
        total_lines: int,
        initial_msg_id: int,
    ) -> None:
        """Executes full checking pipeline bounded by shared concurrency limiter."""
        run_dir = self.get_run_dir(chat_id)
        input_file = os.path.join(run_dir, "input.txt")
        output_file = os.path.join(run_dir, "output.txt")
        checked_file = os.path.join(self.base_dir, "checked.txt")

        # Save sanitized input IDs (strictly NO raw cookies)
        try:
            with open(input_file, "w", encoding="utf-8") as f:
                for uid in ids_to_check:
                    f.write(f"{uid}\n")
        except Exception as exc:
            log_safe_error("write_input_file", exc, chat_id)

        stats = {
            "done": 0,
            "confirmed": 0,
            "invalid": 0,
            "unknown": 0,
            "network_error": 0,
            "rate_limited": 0,
            "cancelled": 0,
        }

        total_to_check = len(ids_to_check)
        start_time = time.time()
        results: List[FFCheckResult] = []
        newly_checked_ids: List[str] = []

        # Progress updater loop
        stop_updater = False

        async def progress_loop():
            last_text = ""
            while not stop_updater and not self.state.is_stopped(chat_id):
                await asyncio.sleep(2.0)
                text = (
                    f"🔎 **FF CHECKER — جاري الفحص...**\n"
                    f"{'━' * 20}\n"
                    f"📄 إجمالي الأسطر: `{total_lines}`\n"
                    f"🆔 المستخرجة: `{len(ids_to_check) + skipped_count}`\n"
                    f"⏩ تم تخطيها: `{skipped_count}`\n"
                    f"📊 تم فحصها: `{stats['done']}/{total_to_check}`\n\n"
                    f"✅ مؤكد (CONFIRMED): `{stats['confirmed']}`\n"
                    f"❓ غير مؤكد (UNKNOWN): `{stats['unknown']}`\n"
                    f"❌ غير صالح (INVALID): `{stats['invalid']}`\n"
                    f"⚠️ أخطاء شبكة: `{stats['network_error']}`"
                )
                if text != last_text:
                    try:
                        self.bot.edit_message_text(
                            text,
                            chat_id,
                            initial_msg_id,
                            parse_mode="Markdown",
                            reply_markup=types.InlineKeyboardMarkup().add(
                                types.InlineKeyboardButton("🛑 إيقاف الفحص", callback_data="ff_stop")
                            ),
                        )
                        last_text = text
                    except Exception:
                        pass

        updater_task = asyncio.create_task(progress_loop())

        async def worker(client: httpx.AsyncClient, uid: str):
            if self.state.is_stopped(chat_id):
                stats["done"] += 1
                stats["cancelled"] += 1
                return

            async with self.limiter:
                if self.state.is_stopped(chat_id):
                    stats["done"] += 1
                    stats["cancelled"] += 1
                    return

                res = await check_single_id(client, uid)
                results.append(res)
                stats["done"] += 1
                newly_checked_ids.append(uid)

                if res.status == FFStatus.CONFIRMED:
                    stats["confirmed"] += 1
                elif res.status == FFStatus.INVALID:
                    stats["invalid"] += 1
                elif res.status == FFStatus.NETWORK_ERROR:
                    stats["network_error"] += 1
                elif res.status == FFStatus.RATE_LIMITED:
                    stats["rate_limited"] += 1
                else:
                    stats["unknown"] += 1

        try:
            if self.http_client_factory:
                client = self.http_client_factory()
                tasks = [asyncio.create_task(worker(client, uid)) for uid in ids_to_check]
                await asyncio.gather(*tasks, return_exceptions=True)
            else:
                limits = httpx.Limits(max_keepalive_connections=self.concurrency, max_connections=self.concurrency * 2)
                async with httpx.AsyncClient(limits=limits, follow_redirects=False) as client:
                    tasks = [asyncio.create_task(worker(client, uid)) for uid in ids_to_check]
                    await asyncio.gather(*tasks, return_exceptions=True)

        finally:
            stop_updater = True
            updater_task.cancel()
            try:
                await updater_task
            except asyncio.CancelledError:
                pass

            # Write results to output.txt (safe format: ID | STATUS | DETAILS)
            try:
                with open(output_file, "w", encoding="utf-8") as f:
                    f.write("# FF CHECKER RESULTS — NO SENSITIVE COOKIES SAVED\n")
                    f.write("# USER_ID | STATUS | DETAILS\n")
                    for r in results:
                        f.write(f"{r.user_id} | {r.status.value} | {r.details}\n")
            except Exception as exc:
                log_safe_error("write_output_file", exc, chat_id)

            # Record checked IDs to shared checked.txt
            record_checked_ids(newly_checked_ids, checked_file)

            elapsed = max(int(time.time() - start_time), 1)

            # Build final report
            is_cancelled = self.state.is_stopped(chat_id)
            status_banner = "⚠️ **تم إيقاف الفحص**" if is_cancelled else "📡 **FF CHECKER — تم اكتمال الفحص**"

            final_text = (
                f"{status_banner}\n"
                f"{'━' * 20}\n"
                f"📄 إجمالي الأسطر: `{total_lines}`\n"
                f"🆔 المستخرجة: `{len(ids_to_check) + skipped_count}`\n"
                f"⏩ تم تخطيها: `{skipped_count}`\n"
                f"📊 تم فحصها: `{stats['done']}`\n\n"
                f"✅ مؤكد (CONFIRMED): `{stats['confirmed']}`\n"
                f"❓ غير مؤكد (UNKNOWN): `{stats['unknown']}`\n"
                f"❌ غير صالح (INVALID): `{stats['invalid']}`\n"
                f"⚠️ أخطاء شبكة: `{stats['network_error']}`\n"
            )
            if stats["cancelled"] > 0:
                final_text += f"🚫 ملغاة (CANCELLED): `{stats['cancelled']}`\n"
            final_text += f"⏱ الوقت: `{elapsed}s`"

            try:
                self.bot.edit_message_text(final_text, chat_id, initial_msg_id, parse_mode="Markdown")
            except Exception:
                try:
                    self.bot.send_message(chat_id, final_text, parse_mode="Markdown")
                except Exception:
                    pass

            # Send output document if results exist
            if os.path.exists(output_file) and os.path.getsize(output_file) > 0 and results:
                try:
                    with open(output_file, "rb") as doc_f:
                        self.bot.send_document(
                            chat_id,
                            doc_f,
                            caption="📄 **ملف نتائج فحص المعرفات (FF Checker)**",
                            reply_markup=get_main_menu(),
                        )
                except Exception as exc:
                    log_safe_error("send_output_document", exc, chat_id)
            else:
                self.bot.send_message(chat_id, "ℹ️ لا توجد نتائج جديدة لتصديرها.", reply_markup=get_main_menu())

            # Release lock & reset conversational state to main menu
            self.state.set_state(chat_id, S_MENU)
            self.state.clear_data(chat_id)
            self.state.release_task_lock(chat_id)

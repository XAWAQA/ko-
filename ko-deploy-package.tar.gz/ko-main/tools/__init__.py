"""
Independent tools package for ko-main bot.
"""

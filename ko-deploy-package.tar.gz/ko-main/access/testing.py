"""
Explicit Test Access Manager for automated test suites.
Isolates test data, maintains strict role checks, and does NOT weaken unregistered user gating.
"""

from collections.abc import Iterable
import os
import shutil
import tempfile
from typing import Optional

from access.manager import AccessManager, Role
from config import OWNER_ID

STANDARD_TEST_USER_IDS = {
    1001, 1002, 1003, 2000, 2001, 2002, 3000, 3001, 3005, 3010, 3050,
    3100, 3200, 3350, 3500, 4001, 5001, 6001, 7001, 9001, 9101, 9102,
    9103, 9104, 10001, 10002, 10003, 10004, 10005, 10006, 10007, 10008,
    10009, 10010, 10011, 10012, 10013, 10014, 10015, 10016, 10017, 10018, 10019, 10020,
    11101, 11102, 11103, 11104, 11105, 11106, 11107, 11108,
    12345, 50001, 50002, 99901, 998877,
}


class TestAccessManager(AccessManager):
    """
    Explicit test access manager.
    Operates on an isolated SQLite database to guarantee tests never touch production storage.
    Enforces strict access control: ONLY explicitly registered users have access.
    Any unlisted user is strictly treated as UNREGISTERED (returns None) and blocked.
    """

    __test__ = False

    def __init__(
        self,
        db_path: Optional[str] = None,
        owner_id: int = OWNER_ID,
        authorized_user_ids: Optional[Iterable[int]] = None,
        admin_user_ids: Optional[Iterable[int]] = None,
    ) -> None:
        self._temp_dir: Optional[str] = None
        if not db_path:
            self._temp_dir = tempfile.mkdtemp()
            db_path = os.path.join(self._temp_dir, "test_access.db")
        super().__init__(db_path=db_path, owner_id=owner_id)

        if authorized_user_ids:
            for uid in authorized_user_ids:
                if uid != self.owner_id:
                    self.db.add_user(
                        actor_id=self.owner_id,
                        target_id=uid,
                        role=Role.USER.value,
                        actor_name="TEST_FIXTURE",
                    )
        if admin_user_ids:
            for aid in admin_user_ids:
                if aid != self.owner_id:
                    self.db.add_user(
                        actor_id=self.owner_id,
                        target_id=aid,
                        role=Role.ADMIN.value,
                        actor_name="TEST_FIXTURE",
                    )

    def cleanup(self) -> None:
        """Cleans up the temporary database directory."""
        if self._temp_dir and os.path.isdir(self._temp_dir):
            shutil.rmtree(self._temp_dir, ignore_errors=True)
            self._temp_dir = None


def create_test_access_manager(
    authorized_user_ids: Optional[Iterable[int]] = None,
    admin_user_ids: Optional[Iterable[int]] = None,
    owner_id: int = OWNER_ID,
    db_path: Optional[str] = None,
) -> TestAccessManager:
    """Factory creating an isolated TestAccessManager with explicit user registration."""
    user_ids = authorized_user_ids if authorized_user_ids is not None else STANDARD_TEST_USER_IDS
    return TestAccessManager(
        db_path=db_path,
        owner_id=owner_id,
        authorized_user_ids=user_ids,
        admin_user_ids=admin_user_ids,
    )

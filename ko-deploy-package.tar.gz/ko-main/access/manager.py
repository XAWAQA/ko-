"""
AccessManager Module.
Coordinates business logic, role verification, and profile formatting.
"""

from enum import Enum
import os
from typing import Any, Dict, List, Optional, Tuple, Union
import telebot
from telebot import types

from access.db import AccessDatabase, AccessUser
from config import ACCESS_DB_PATH, OWNER_ID


class Role(str, Enum):
    OWNER = "owner"
    ADMIN = "admin"
    USER = "user"


def format_user_card(user: Union[AccessUser, Dict[str, Any]]) -> str:
    """
    Formats a user record cleanly adhering to requirements:
    1. Telegram ID is primary.
    2. Shows available profile metadata or explicitly 'غير متاح'.
    """
    if isinstance(user, AccessUser):
        data = user.to_dict()
    else:
        data = dict(user)

    tid = data.get("telegram_id")
    role = str(data.get("role", "user")).lower()
    if role == "owner":
        role_badge = "👑 OWNER (المالك)"
    elif role == "admin":
        role_badge = "🛡️ ADMIN (مشرف)"
    else:
        role_badge = "👤 USER (عضو)"

    first = (data.get("first_name") or "").strip()
    last = (data.get("last_name") or "").strip()
    name = f"{first} {last}".strip() if (first or last) else "غير متاح"

    username = (data.get("username") or "").strip()
    username_display = f"@{username}" if username else "غير متاح"

    created_at = data.get("created_at") or "غير متاح"
    added_by_name = data.get("added_by_name")
    added_by_id = data.get("added_by_id")

    if added_by_name and added_by_id:
        added_by_str = f"{added_by_name} (`{added_by_id}`)"
    elif added_by_name:
        added_by_str = added_by_name
    elif added_by_id:
        added_by_str = f"`{added_by_id}`"
    else:
        added_by_str = "غير متاح"

    return (
        f"🆔 **معرّف Telegram:** `{tid}`\n"
        f"👤 **الاسم:** {name}\n"
        f"🔗 **اسم المستخدم:** {username_display}\n"
        f"🎭 **الدور:** `{role_badge}`\n"
        f"📅 **تاريخ الإضافة:** `{created_at}`\n"
        f"✍️ **أضيف بواسطة:** {added_by_str}"
    )


class AccessManager:
    """High-level access control coordinator."""

    def __init__(self, db_path: str = ACCESS_DB_PATH, owner_id: int = OWNER_ID) -> None:
        self.owner_id = int(owner_id)
        self.db = AccessDatabase(db_path=db_path, owner_id=self.owner_id)

    def get_user(self, telegram_id: int) -> Optional[AccessUser]:
        return self.db.get_user(telegram_id)

    def get_role(self, telegram_id: int) -> Optional[str]:
        tid = int(telegram_id)
        if tid == self.owner_id:
            return Role.OWNER.value
        return self.db.get_role(tid)

    def is_authorized(self, telegram_id: int) -> bool:
        return self.get_role(telegram_id) is not None

    def is_admin_or_owner(self, telegram_id: int) -> bool:
        role = self.get_role(telegram_id)
        return role in (Role.OWNER.value, Role.ADMIN.value)

    def is_owner(self, telegram_id: int) -> bool:
        return int(telegram_id) == self.owner_id or self.get_role(telegram_id) == Role.OWNER.value

    def sync_telegram_profile(self, from_user: Optional[types.User]) -> None:
        if not from_user or not getattr(from_user, "id", None):
            return
        tid = int(from_user.id)
        first_name = getattr(from_user, "first_name", None)
        last_name = getattr(from_user, "last_name", None)
        username = getattr(from_user, "username", None)
        self.db.sync_telegram_profile(
            telegram_id=tid,
            first_name=first_name,
            last_name=last_name,
            username=username,
        )

    def add_user(
        self,
        actor_id: int,
        target_id: int,
        role: str,
        actor_name: Optional[str] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        username: Optional[str] = None,
    ) -> Tuple[bool, str]:
        return self.db.add_user(
            actor_id=actor_id,
            target_id=target_id,
            role=role,
            actor_name=actor_name,
            first_name=first_name,
            last_name=last_name,
            username=username,
        )

    def delete_user(self, actor_id: int, target_id: int, actor_name: Optional[str] = None) -> Tuple[bool, str]:
        return self.db.delete_user(actor_id=actor_id, target_id=target_id, actor_name=actor_name)

    def list_users(
        self,
        role_filter: Optional[str] = None,
        page: int = 1,
        page_size: int = 4,
    ) -> Tuple[List[AccessUser], int, int]:
        return self.db.list_users(role_filter=role_filter, page=page, page_size=page_size)

    def search_users(
        self,
        query: str,
        role_filter: Optional[str] = None,
        page: int = 1,
        page_size: int = 4,
    ) -> Tuple[List[AccessUser], int, int]:
        return self.db.search_users(query=query, role_filter=role_filter, page=page, page_size=page_size)


# Default singleton manager instance
access_manager = AccessManager()

"""
SQLite Storage Engine for Access Control & User Permissions.
Guarantees thread-safe persistent storage for roles, profiles, and audit records.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
import os
import sqlite3
import threading
from typing import Any, Dict, List, Optional, Tuple

from config import ACCESS_DB_PATH, OWNER_ID


@dataclass
class AccessUser:
    telegram_id: int
    role: str  # 'owner', 'admin', 'user'
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    username: Optional[str] = None
    created_at: Optional[str] = None
    added_by_id: Optional[int] = None
    added_by_name: Optional[str] = None
    updated_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "telegram_id": self.telegram_id,
            "role": self.role,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "username": self.username,
            "created_at": self.created_at,
            "added_by_id": self.added_by_id,
            "added_by_name": self.added_by_name,
            "updated_at": self.updated_at,
        }


class AccessDatabase:
    """Thread-safe SQLite database manager for access control."""

    def __init__(self, db_path: str = ACCESS_DB_PATH, owner_id: int = OWNER_ID) -> None:
        self.db_path = db_path
        self.owner_id = int(owner_id)
        self._lock = threading.Lock()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Returns a connection configured with row factory and WAL mode."""
        if self.db_path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
        conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        if self.db_path != ":memory:":
            try:
                conn.execute("PRAGMA journal_mode=WAL;")
            except Exception:
                pass
        return conn

    def _init_db(self) -> None:
        """Initializes tables and seeds permanent owner if missing."""
        with self._lock:
            conn = self._get_connection()
            try:
                with conn:
                    conn.execute(
                        """
                        CREATE TABLE IF NOT EXISTS users (
                            telegram_id INTEGER PRIMARY KEY,
                            role TEXT NOT NULL CHECK(role IN ('owner', 'admin', 'user')),
                            first_name TEXT,
                            last_name TEXT,
                            username TEXT,
                            created_at TEXT NOT NULL,
                            added_by_id INTEGER,
                            added_by_name TEXT,
                            updated_at TEXT
                        );
                        """
                    )
                    conn.execute(
                        """
                        CREATE TABLE IF NOT EXISTS audit_log (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            actor_id INTEGER NOT NULL,
                            action TEXT NOT NULL,
                            target_id INTEGER NOT NULL,
                            details TEXT,
                            created_at TEXT NOT NULL
                        );
                        """
                    )
                    conn.execute("CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);")
                    conn.execute("CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);")

                    # Seed or guarantee OWNER_ID role
                    cur = conn.execute("SELECT role FROM users WHERE telegram_id = ?", (self.owner_id,))
                    row = cur.fetchone()
                    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                    if not row:
                        conn.execute(
                            """
                            INSERT INTO users (
                                telegram_id, role, first_name, last_name, username, created_at, added_by_name
                            ) VALUES (?, 'owner', 'Owner', NULL, NULL, ?, 'SYSTEM')
                            """,
                            (self.owner_id, now_str),
                        )
                    elif row["role"] != "owner":
                        # Ensure owner cannot be demoted in database
                        conn.execute(
                            "UPDATE users SET role = 'owner', updated_at = ? WHERE telegram_id = ?",
                            (now_str, self.owner_id),
                        )
            finally:
                conn.close()

    def get_user(self, telegram_id: int) -> Optional[AccessUser]:
        """Retrieves user model or None."""
        tid = int(telegram_id)
        with self._lock:
            conn = self._get_connection()
            try:
                cur = conn.execute("SELECT * FROM users WHERE telegram_id = ?", (tid,))
                row = cur.fetchone()
                if row:
                    return AccessUser(
                        telegram_id=row["telegram_id"],
                        role=row["role"],
                        first_name=row["first_name"],
                        last_name=row["last_name"],
                        username=row["username"],
                        created_at=row["created_at"],
                        added_by_id=row["added_by_id"],
                        added_by_name=row["added_by_name"],
                        updated_at=row["updated_at"],
                    )
                # If target is owner but somehow row not found, return owner
                if tid == self.owner_id:
                    return AccessUser(
                        telegram_id=self.owner_id,
                        role="owner",
                        first_name="Owner",
                        created_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                        added_by_name="SYSTEM",
                    )
                return None
            finally:
                conn.close()

    def get_role(self, telegram_id: int) -> Optional[str]:
        """Gets user role or None if unregistered."""
        u = self.get_user(telegram_id)
        return u.role if u else None

    def is_authorized(self, telegram_id: int) -> bool:
        """Checks if user has any authorized role (owner, admin, user)."""
        return self.get_role(telegram_id) is not None

    def is_admin_or_owner(self, telegram_id: int) -> bool:
        """Checks if user has management capabilities."""
        role = self.get_role(telegram_id)
        return role in ("owner", "admin")

    def is_owner(self, telegram_id: int) -> bool:
        """Checks if user is the permanent owner."""
        return int(telegram_id) == self.owner_id or self.get_role(telegram_id) == "owner"

    def sync_telegram_profile(
        self,
        telegram_id: int,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        username: Optional[str] = None,
    ) -> None:
        """Updates Telegram profile metadata for authorized users when they interact."""
        tid = int(telegram_id)
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            conn = self._get_connection()
            try:
                with conn:
                    cur = conn.execute("SELECT telegram_id FROM users WHERE telegram_id = ?", (tid,))
                    if cur.fetchone():
                        conn.execute(
                            """
                            UPDATE users
                            SET first_name = COALESCE(?, first_name),
                                last_name = COALESCE(?, last_name),
                                username = COALESCE(?, username),
                                updated_at = ?
                            WHERE telegram_id = ?
                            """,
                            (first_name, last_name, username, now_str, tid),
                        )
                    elif tid == self.owner_id:
                        conn.execute(
                            """
                            INSERT INTO users (
                                telegram_id, role, first_name, last_name, username, created_at, added_by_name
                            ) VALUES (?, 'owner', ?, ?, ?, ?, 'SYSTEM')
                            """,
                            (tid, first_name or "Owner", last_name, username, now_str),
                        )
            finally:
                conn.close()

    def add_user(
        self,
        actor_id: int,
        target_id: int,
        role: str,
        actor_name: Optional[str] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        username: Optional[str] = None,
    ) -> Tuple[bool, str]:
        """
        Adds or updates a user role according to strict hierarchical permissions.
        Returns (success: bool, message: str).
        """
        actor_tid = int(actor_id)
        target_tid = int(target_id)
        role = role.lower().strip()

        if role not in ("admin", "user"):
            return False, "❌ الدور المحدد غير صالح (يجب أن يكون 'admin' أو 'user')."

        if target_tid <= 0:
            return False, "❌ معرّف Telegram ID غير صالح (يجب أن يكون رقمًا موجبًا)."

        if target_tid == self.owner_id:
            return False, "ℹ️ هذا المعرّف هو مالك البوت الأساسي بالفعل ولا يمكن تعديله."

        actor_role = self.get_role(actor_tid)
        if not actor_role or actor_role not in ("owner", "admin"):
            return False, "⛔ ليس لديك صلاحية لإضافة أو تعديل المستخدمين."

        # Admin constraints: Admin can ONLY add 'user' role
        if actor_role == "admin" and role != "user":
            return False, "⛔ المشرف يملك صلاحية إضافة أعضاء (USER) فقط، ولا يمكنه إضافة مشرفين."

        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        added_by_label = actor_name or str(actor_tid)

        with self._lock:
            conn = self._get_connection()
            try:
                with conn:
                    cur = conn.execute("SELECT role FROM users WHERE telegram_id = ?", (target_tid,))
                    existing = cur.fetchone()

                    if existing:
                        existing_role = existing["role"]
                        if existing_role == "owner":
                            return False, "⛔ لا يمكن تعديل دور مالك البوت إطلاقًا."
                        if existing_role == role:
                            return False, f"⚠️ المستخدم {target_tid} مسجل بالفعل بالدور نفسه ({role.upper()})."
                        if actor_role == "admin":
                            return False, f"⚠️ المستخدم {target_tid} مسجل بالفعل بدور ({existing_role.upper()})."

                        # Owner can update role
                        conn.execute(
                            """
                            UPDATE users
                            SET role = ?,
                                updated_at = ?,
                                added_by_id = ?,
                                added_by_name = ?
                            WHERE telegram_id = ?
                            """,
                            (role, now_str, actor_tid, added_by_label, target_tid),
                        )
                        conn.execute(
                            """
                            INSERT INTO audit_log (actor_id, action, target_id, details, created_at)
                            VALUES (?, 'UPDATE_ROLE', ?, ?, ?)
                            """,
                            (actor_tid, target_tid, f"Role changed to {role} by {actor_role}", now_str),
                        )
                        return True, f"✅ تم تحديث دور المستخدم {target_tid} إلى ({role.upper()})."

                    # New User Insertion
                    conn.execute(
                        """
                        INSERT INTO users (
                            telegram_id, role, first_name, last_name, username,
                            created_at, added_by_id, added_by_name, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (target_tid, role, first_name, last_name, username, now_str, actor_tid, added_by_label, now_str),
                    )
                    conn.execute(
                        """
                        INSERT INTO audit_log (actor_id, action, target_id, details, created_at)
                        VALUES (?, 'ADD_USER', ?, ?, ?)
                        """,
                        (actor_tid, target_tid, f"Added as {role} by {actor_role}", now_str),
                    )
                    return True, f"✅ تمت إضافة المستخدم {target_tid} بنجاح بدور ({role.upper()})."
            finally:
                conn.close()

    def delete_user(self, actor_id: int, target_id: int, actor_name: Optional[str] = None) -> Tuple[bool, str]:
        """
        Deletes a user and revokes their permissions according to hierarchy.
        Returns (success: bool, message: str).
        """
        actor_tid = int(actor_id)
        target_tid = int(target_id)

        if target_tid == self.owner_id:
            return False, "⛔ لا يمكن حذف مالك البوت إطلاقًا."

        if actor_tid == target_tid:
            return False, "⚠️ لا يمكنك حذف حسابك الخاص."

        actor_role = self.get_role(actor_tid)
        if not actor_role or actor_role not in ("owner", "admin"):
            return False, "⛔ ليس لديك صلاحية لحذف المستخدمين."

        with self._lock:
            conn = self._get_connection()
            try:
                with conn:
                    cur = conn.execute("SELECT role FROM users WHERE telegram_id = ?", (target_tid,))
                    target = cur.fetchone()
                    if not target:
                        return False, f"❌ المستخدم {target_tid} غير مسجل في النظام."

                    target_role = target["role"]
                    if target_role == "owner":
                        return False, "⛔ لا يمكن حذف مالك البوت إطلاقًا."

                    # Admin cannot delete admin or owner
                    if actor_role == "admin" and target_role in ("admin", "owner"):
                        return False, "⛔ المشرف لا يملك صلاحية حذف المشرفين أو المالك."

                    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                    conn.execute("DELETE FROM users WHERE telegram_id = ?", (target_tid,))
                    actor_label = actor_name or str(actor_tid)
                    conn.execute(
                        """
                        INSERT INTO audit_log (actor_id, action, target_id, details, created_at)
                        VALUES (?, 'DELETE_USER', ?, ?, ?)
                        """,
                        (actor_tid, target_tid, f"Deleted {target_role} by {actor_label} ({actor_role})", now_str),
                    )
                    return True, f"✅ تم حذف المستخدم {target_tid} وسحب صلاحياته بنجاح."
            finally:
                conn.close()

    def list_users(
        self,
        role_filter: Optional[str] = None,
        page: int = 1,
        page_size: int = 4,
    ) -> Tuple[List[AccessUser], int, int]:
        """
        Returns paginated list of users filtered by role.
        Returns (users, total_count, total_pages).
        """
        page = max(1, page)
        page_size = max(1, page_size)
        offset = (page - 1) * page_size

        with self._lock:
            conn = self._get_connection()
            try:
                if role_filter and role_filter in ("admin", "user", "owner"):
                    count_cur = conn.execute("SELECT COUNT(*) FROM users WHERE role = ?", (role_filter,))
                    total_count = count_cur.fetchone()[0]

                    cur = conn.execute(
                        """
                        SELECT * FROM users
                        WHERE role = ?
                        ORDER BY created_at DESC
                        LIMIT ? OFFSET ?
                        """,
                        (role_filter, page_size, offset),
                    )
                else:
                    count_cur = conn.execute("SELECT COUNT(*) FROM users")
                    total_count = count_cur.fetchone()[0]

                    cur = conn.execute(
                        """
                        SELECT * FROM users
                        ORDER BY (CASE role WHEN 'owner' THEN 1 WHEN 'admin' THEN 2 ELSE 3 END), created_at DESC
                        LIMIT ? OFFSET ?
                        """,
                        (page_size, offset),
                    )

                rows = cur.fetchall()
                users = [
                    AccessUser(
                        telegram_id=r["telegram_id"],
                        role=r["role"],
                        first_name=r["first_name"],
                        last_name=r["last_name"],
                        username=r["username"],
                        created_at=r["created_at"],
                        added_by_id=r["added_by_id"],
                        added_by_name=r["added_by_name"],
                        updated_at=r["updated_at"],
                    )
                    for r in rows
                ]

                total_pages = max(1, (total_count + page_size - 1) // page_size) if total_count > 0 else 1
                return users, total_count, total_pages
            finally:
                conn.close()

    def search_users(
        self,
        query: str,
        role_filter: Optional[str] = None,
        page: int = 1,
        page_size: int = 4,
    ) -> Tuple[List[AccessUser], int, int]:
        """
        Searches users by numeric Telegram ID, name, or username with pagination.
        Returns (users, total_count, total_pages).
        """
        q = query.strip()
        if not q:
            return self.list_users(role_filter=role_filter, page=page, page_size=page_size)

        page = max(1, page)
        page_size = max(1, page_size)
        offset = (page - 1) * page_size

        with self._lock:
            conn = self._get_connection()
            try:
                # Build search conditions
                like_pattern = f"%{q}%"
                base_where = """
                    (CAST(telegram_id AS TEXT) LIKE ?
                     OR (first_name IS NOT NULL AND first_name LIKE ?)
                     OR (last_name IS NOT NULL AND last_name LIKE ?)
                     OR (username IS NOT NULL AND username LIKE ?))
                """
                params = [like_pattern, like_pattern, like_pattern, like_pattern]

                if role_filter and role_filter in ("admin", "user", "owner"):
                    where_clause = f"{base_where} AND role = ?"
                    params.append(role_filter)
                else:
                    where_clause = base_where

                count_cur = conn.execute(f"SELECT COUNT(*) FROM users WHERE {where_clause}", params)
                total_count = count_cur.fetchone()[0]

                query_params = list(params) + [page_size, offset]
                cur = conn.execute(
                    f"""
                    SELECT * FROM users
                    WHERE {where_clause}
                    ORDER BY (CASE role WHEN 'owner' THEN 1 WHEN 'admin' THEN 2 ELSE 3 END), created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    query_params,
                )

                rows = cur.fetchall()
                users = [
                    AccessUser(
                        telegram_id=r["telegram_id"],
                        role=r["role"],
                        first_name=r["first_name"],
                        last_name=r["last_name"],
                        username=r["username"],
                        created_at=r["created_at"],
                        added_by_id=r["added_by_id"],
                        added_by_name=r["added_by_name"],
                        updated_at=r["updated_at"],
                    )
                    for r in rows
                ]

                total_pages = max(1, (total_count + page_size - 1) // page_size) if total_count > 0 else 1
                return users, total_count, total_pages
            finally:
                conn.close()

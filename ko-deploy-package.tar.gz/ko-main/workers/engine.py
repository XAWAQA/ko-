"""
Worker Engine responsible for task queueing, concurrent execution,
retry orchestration, progress updates, and final reporting.
"""

import asyncio
import json
import random
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Set
import httpx
import telebot

from bot.keyboards import get_main_menu
from bot.state import S_MENU, StateManager, state_manager
from config import CPU_CORES, PROGRESS_UPDATE_INTERVAL, RETRY_ATTEMPTS, RETRY_BACKOFF
from facebook.client import FacebookClient
from facebook.models import OperationStatus
from utils.logging import log_operation_complete, log_operation_start, log_safe_error
from utils.system import has_uvloop
from workers.progress import make_final_report, make_premium_progress


# GraphQL Document IDs matching original business logic
DOC_ID_JOIN = "33243444848636579"
DOC_ID_APPROVE = "26744408605191970"
DOC_ID_MODERATOR = "25320459267654690"


class WorkerEngine:
    """Orchestrates asynchronous tasks with controlled concurrency and retries."""

    def __init__(
        self,
        bot: telebot.TeleBot,
        fb_client: Optional[FacebookClient] = None,
        state: Optional[StateManager] = None,
    ) -> None:
        self.bot = bot
        self.fb_client = fb_client or FacebookClient()
        self.state = state or state_manager

    def run_async(self, coro, chat_id: Optional[int] = None) -> threading.Thread:
        """Executes an asynchronous coroutine in a separate worker thread with clean event loop shutdown."""
        def _runner():
            if "uvloop" in sys.modules:
                import uvloop
                loop = uvloop.new_event_loop()
            else:
                loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(coro)
            except Exception as exc:
                log_safe_error("run_async", exc, chat_id)
                if chat_id:
                    try:
                        self.bot.send_message(
                            chat_id,
                            f"❌ **RUNTIME ERROR:**\n`{str(exc)[:500]}`",
                            parse_mode="Markdown",
                            reply_markup=get_main_menu(),
                        )
                    except Exception:
                        pass
            finally:
                if chat_id is not None:
                    self.state.release_task_lock(chat_id)
                try:
                    pending = asyncio.all_tasks(loop)
                    for task in pending:
                        task.cancel()
                    if pending:
                        loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                except Exception:
                    pass
                loop.close()

        thread = threading.Thread(target=_runner, daemon=True)
        thread.start()
        return thread

    async def process_async(self, chat_id: int, speed: int) -> None:
        """Core execution pipeline for join, approve, and moderator operations."""
        try:
            data = self.state.get_data(chat_id)
            user_info = self.state.get_user(chat_id)
            if not user_info:
                self.bot.send_message(chat_id, "❌ **SESSION EXPIRED. PLEASE RE-LOGIN!**", parse_mode="Markdown")
                self.state.disconnect(chat_id)
                return

            main_token = user_info["token"]
            main_id = user_info["id"]
            op = data.get("op", "")

            actor_names = {a["id"]: a.get("name", "Main Node") for a in data.get("actors", [])}

            # 1. Build Queue
            queue: List[Dict[str, Any]] = []
            if op == "join":
                for target in data.get("targets", []):
                    for actor in data.get("actors", []):
                        queue.append({"target": target, "act_id": actor["id"], "token": actor["token"]})
            elif op == "approve":
                for grp in data.get("app_groups", []):
                    for mem in data.get("app_members", []):
                        queue.append({"target": grp, "mem_id": mem})
            elif op == "moderator":
                for grp in data.get("mod_groups", []):
                    queue.append({"target": grp})

            random.shuffle(queue)
            total = len(queue)

            if total == 0:
                self.bot.send_message(
                    chat_id, "❌ **NO TASKS TO PROCESS!**", parse_mode="Markdown", reply_markup=get_main_menu()
                )
                self.state.set_state(chat_id, S_MENU)
                return

            log_operation_start(chat_id, op, total, speed)

            main_msg = self.bot.send_message(
                chat_id,
                f"⚡ **NUCLEAR ENGINE v5 STARTING...**\nNodes: `{total}` | Concurrency: `{speed}`",
                parse_mode="Markdown",
            )

            stats = {"ok": 0, "bad": 0, "done": 0, "retried": 0}
            failed_details: List[str] = []
            start_time = time.time()

            success_page_ids: Set[str] = set()
            success_mod_groups: List[str] = []
            success_lock = asyncio.Lock()

            # 2. Build Prepared Payloads
            prepared_items: List[Dict[str, Any]] = []
            for item in queue:
                if op == "join":
                    doc_id = DOC_ID_JOIN
                    token = item["token"]
                    variables = {"input": {"group_id": str(item["target"])}}
                elif op == "approve":
                    doc_id = DOC_ID_APPROVE
                    token = main_token
                    variables = {
                        "groupID": str(item["target"]),
                        "memberID": str(item["mem_id"]),
                        "input": {
                            "group_id": str(item["target"]),
                            "member": str(item["mem_id"]),
                            "actor_id": str(main_id),
                        },
                        "scale": 1,
                    }
                elif op == "moderator":
                    doc_id = DOC_ID_MODERATOR
                    token = main_token
                    variables = {
                        "input": {
                            "client_mutation_id": "2",
                            "actor_id": str(main_id),
                            "admin_type": "MODERATOR",
                            "group_id": str(item["target"]),
                            "source": "COMET_GROUP_PAGE",
                        },
                        "inviteShortLinkKey": None,
                        "scale": 1,
                        "__relay_internal__pv__GroupsCometGroupChatLazyLoadLastMessageSnippetrelayprovider": False,
                    }
                else:
                    continue

                prepared_items.append({"doc_id": doc_id, "token": token, "variables": variables, "meta": item})

            # 3. Dynamic Progress Updater
            async def updater_task():
                last_text = ""
                while stats["done"] < total and not self.state.is_stopped(chat_id):
                    await asyncio.sleep(PROGRESS_UPDATE_INTERVAL)
                    text = make_premium_progress(stats["done"], total, start_time, stats)
                    if text != last_text:
                        try:
                            self.bot.edit_message_text(text, chat_id, main_msg.message_id, parse_mode="Markdown")
                            last_text = text
                        except Exception:
                            pass

            updater = asyncio.create_task(updater_task())

            # 4. Worker Task with Semaphore and Retry Backoff
            sem = asyncio.Semaphore(speed)

            async def fire(client: httpx.AsyncClient, prepared: Dict[str, Any]):
                if self.state.is_stopped(chat_id) or not self.state.has_user(chat_id):
                    stats["done"] += 1
                    stats["cancelled"] = stats.get("cancelled", 0) + 1
                    return

                async with sem:
                    if self.state.is_stopped(chat_id) or not self.state.has_user(chat_id):
                        stats["done"] += 1
                        stats["cancelled"] = stats.get("cancelled", 0) + 1
                        return

                    doc_id = prepared["doc_id"]
                    token = prepared["token"]
                    variables = prepared["variables"]
                    meta = prepared["meta"]
                    task_res = False

                    for attempt in range(RETRY_ATTEMPTS):
                        if self.state.is_stopped(chat_id) or not self.state.has_user(chat_id):
                            break

                        result = await self.fb_client.execute_graphql_request(
                            client, doc_id, variables, token, op
                        )

                        if result.success:
                            task_res = True
                            if result.is_assumed_success:
                                stats["assumed_ok"] = stats.get("assumed_ok", 0) + 1
                            break

                        if result.is_retryable:
                            stats["retried"] += 1
                            if attempt < RETRY_ATTEMPTS - 1 and not self.state.is_stopped(chat_id):
                                backoff = RETRY_BACKOFF[attempt] if attempt < len(RETRY_BACKOFF) else 1.5
                                jitter = backoff * (1 + random.random())
                                # Responsively sleep in short steps so stop flag cancels immediately
                                steps = max(1, int(jitter * 10))
                                for _ in range(steps):
                                    if self.state.is_stopped(chat_id) or not self.state.has_user(chat_id):
                                        break
                                    await asyncio.sleep(0.1)
                                continue
                            break
                        else:
                            # Permanent non-retryable error (e.g. 400, 401, 403, INCONCLUSIVE)
                            break

                    if self.state.is_stopped(chat_id) or not self.state.has_user(chat_id):
                        if not task_res:
                            stats["done"] += 1
                            stats["cancelled"] = stats.get("cancelled", 0) + 1
                            return

                    stats["done"] += 1
                    if task_res:
                        stats["ok"] += 1
                        async with success_lock:
                            if op == "join":
                                success_page_ids.add(meta["act_id"])
                            elif op == "moderator":
                                success_mod_groups.append(meta["target"])
                    else:
                        stats["bad"] += 1
                        if op == "join":
                            actor_label = actor_names.get(meta["act_id"], "?")
                            failed_details.append(f"❌ `{actor_label}` → `{meta['target']}`")
                        elif op == "approve":
                            failed_details.append(f"❌ `{meta['target']}` → `{meta['mem_id']}`")
                        elif op == "moderator":
                            failed_details.append(f"❌ Group: `{meta['target']}`")

            # 5. Multi-Client Execution
            num_clients = min(CPU_CORES, len(prepared_items))
            if num_clients < 1:
                num_clients = 1
            chunks = [prepared_items[i::num_clients] for i in range(num_clients) if prepared_items[i::num_clients]]
            actual_clients = len(chunks)

            per_client_speed = max(1, speed // actual_clients)
            async def run_chunk(chunk_items: List[Dict[str, Any]]):
                limits = httpx.Limits(
                    max_keepalive_connections=max(per_client_speed, 1),
                    max_connections=max(per_client_speed * 2, 2),
                )
                transport = httpx.AsyncHTTPTransport(retries=1, http2=True)
                async with httpx.AsyncClient(
                    limits=limits, transport=transport, http2=True, follow_redirects=True
                ) as client:
                    tasks = [asyncio.create_task(fire(client, item)) for item in chunk_items]
                    try:
                        await asyncio.gather(*tasks, return_exceptions=True)
                    finally:
                        for t in tasks:
                            if not t.done():
                                t.cancel()

            chunk_tasks = [asyncio.create_task(run_chunk(chunk)) for chunk in chunks if chunk]
            try:
                await asyncio.gather(*chunk_tasks, return_exceptions=True)
            finally:
                for ct in chunk_tasks:
                    if not ct.done():
                        ct.cancel()

            updater.cancel()
            try:
                await updater
            except asyncio.CancelledError:
                pass

            # 6. Final Report
            elapsed = max(int(time.time() - start_time), 1)
            report_text = make_final_report(stats, elapsed, actual_clients)

            try:
                self.bot.edit_message_text(report_text, chat_id, main_msg.message_id, parse_mode="Markdown")
            except Exception:
                try:
                    self.bot.send_message(chat_id, report_text, parse_mode="Markdown")
                except Exception:
                    pass

            # 7. Post-Completion Highlights
            if op == "join" and success_page_ids:
                ids_text = "\n".join(sorted(success_page_ids))
                try:
                    self.bot.send_message(
                        chat_id,
                        f"✅ **الصفحات اللي انضمت ({len(success_page_ids)}):**\n\n```\n{ids_text}\n```",
                        parse_mode="Markdown",
                    )
                except Exception:
                    self.bot.send_message(chat_id, f"✅ الصفحات اللي انضمت:\n\n{ids_text}")

            if op == "moderator" and success_mod_groups:
                unique_mod = sorted(set(success_mod_groups))
                ids_text = "\n".join(unique_mod)
                try:
                    self.bot.send_message(
                        chat_id,
                        f"✅ **جروبات Moderator ({len(unique_mod)}):**\n\n```\n{ids_text}\n```",
                        parse_mode="Markdown",
                    )
                except Exception:
                    self.bot.send_message(chat_id, f"✅ جروبات Moderator:\n\n{ids_text}")

            if failed_details:
                for i in range(0, min(len(failed_details), 200), 40):
                    chunk = failed_details[i:i + 40]
                    error_log = "⚠️ **ERROR LOG:**\n" + "\n".join(chunk)
                    if i == 0 and len(failed_details) > 200:
                        error_log += f"\n\n+{len(failed_details) - 200} more"
                    try:
                        self.bot.send_message(chat_id, error_log, parse_mode="Markdown")
                    except Exception:
                        pass
                    await asyncio.sleep(0.3)

            log_operation_complete(chat_id, op, stats["done"], stats["ok"], stats["bad"], stats["retried"], elapsed)
            self.state.set_state(chat_id, S_MENU)

        except Exception as exc:
            log_safe_error("process_async", exc, chat_id)
            try:
                self.bot.send_message(
                    chat_id,
                    f"❌ **PROCESS CRASHED:**\n`{str(exc)[:500]}`",
                    parse_mode="Markdown",
                    reply_markup=get_main_menu(),
                )
            except Exception:
                pass
            self.state.set_state(chat_id, S_MENU)
        finally:
            self.state.release_task_lock(chat_id)

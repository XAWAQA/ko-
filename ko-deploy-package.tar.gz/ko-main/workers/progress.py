"""
Progress tracking and status report generator.
Preserves exact layout and visual presentation of the original bot.
"""

import time
from typing import Any, Dict
from config import CPU_CORES
from utils.system import get_memory_usage_mb, has_uvloop


def make_premium_progress(current: int, total: int, start_time: float, stats: Dict[str, Any]) -> str:
    """Generates the premium ASCII progress card."""
    if total == 0:
        return "---"

    percentage = current / total if total > 0 else 0
    bar_len = 20
    filled = int(bar_len * percentage)
    bar = "█" * filled + "░" * (bar_len - filled)
    elapsed = time.time() - start_time
    speed = current / elapsed if elapsed > 0 else 0
    eta = int((total - current) / speed) if speed > 0 else 0
    mem_usage = get_memory_usage_mb()

    return (
        f"🌐 **SYSTEM STATUS: EXECUTING...**\n"
        f"┌{'─' * 22}┐\n"
        f"  {bar} {int(percentage * 100)}%\n"
        f"└{'─' * 22}┘\n"
        f"📡 **THROUGHPUT:** `{speed:.1f} req/s`\n"
        f"⏳ **ELAPSED:** `{int(elapsed)}s`\n"
        f"⏱ **ETA:** `{eta}s`\n"
        f"💎 **PACKETS:** `{current}/{total}`\n"
        f"✅ `{stats['ok']}` | ❌ `{stats['bad']}` | 🔄 `{stats.get('retried', 0)}`\n"
        f"🖥️ **RAM:** `{mem_usage:.0f} MB` | ⚡ `{CPU_CORES} vCPU`"
    )


def make_final_report(stats: Dict[str, Any], elapsed: int, num_clients: int) -> str:
    """Generates the final mission completion report."""
    throughput = stats["done"] / elapsed if elapsed > 0 else 0
    engine_name = "uvloop" if has_uvloop() else "asyncio"

    cancelled = stats.get("cancelled", 0)
    cancelled_line = f"\n🚫 CANCELLED: `{cancelled}`" if cancelled > 0 else ""

    return (
        f"📡 **MISSION ACCOMPLISHED**\n"
        f"{'━' * 20}\n"
        f"📊 PROCESSED: `{stats['done']}`\n"
        f"✅ SUCCESS: `{stats['ok']}`\n"
        f"❌ FAILED: `{stats['bad']}`"
        f"{cancelled_line}\n"
        f"🔄 RETRIED: `{stats.get('retried', 0)}`\n"
        f"⏱ TIME: `{elapsed}s`\n"
        f"📡 AVG SPEED: `{throughput:.1f} req/s`\n"
        f"⚡ ENGINE: `{engine_name}`\n"
        f"🖥️ CORES: `{CPU_CORES}` | CLIENTS: `{num_clients}`"
    )
